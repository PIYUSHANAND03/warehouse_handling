# 🚀 Quick Start Guide

Get your warehouse management system up and running in 5 minutes!

## Prerequisites

Before you begin, ensure you have:
- ✅ Node.js 18+ installed
- ✅ pnpm installed (`npm install -g pnpm`)
- ✅ MySQL 8+ running

## Step 1: Clone and Install (1 minute)

```bash
# Clone the repository
git clone <your-repo-url>
cd "WAREHOUSE MANAGEMENT"

# Install dependencies
pnpm install
```

## Step 2: Configure Database (2 minutes)

### Option A: Use Docker (Recommended)

```bash
# Start MySQL with Docker
pnpm db:up

# Wait for MySQL to be ready (about 30 seconds)
```

Your database will be available at:
- Host: `localhost`
- Port: `3306`
- User: `root`
- Password: `rootpassword`
- Database: `warehouse_db`

### Option B: Use Existing MySQL

If you have MySQL already installed:

1. Create a database:
```sql
CREATE DATABASE warehouse_db;
```

2. Update `.env` file with your credentials:
```env
DATABASE_URL="mysql://your_user:your_password@localhost:3306/warehouse_db"
```

## Step 3: Set Up Database Schema (1 minute)

```bash
# Generate Prisma client
pnpm prisma:generate

# Run migrations
pnpm prisma:migrate

# Seed with sample data (optional but recommended)
pnpm prisma:seed
```

## Step 4: Start Development Server (1 minute)

```bash
# Start the application
pnpm dev
```

The application will start at: **http://localhost:8080**

## 🎉 You're Done!

Open your browser and navigate to `http://localhost:8080`

### What's Included

The seeded database includes:
- 📦 **50+ Products** across multiple categories
- 👥 **20+ Customers** (business and individual)
- 📋 **30+ Orders** in various statuses
- 🚚 **15+ Shipments** being tracked
- 👷 **10+ Workers** across departments
- 📥 **Inbound shipments** for receiving

## Quick Tour

### 1. Dashboard (Home)
- View real-time warehouse statistics
- Monitor low stock alerts
- Track recent activities
- Check shipping status

### 2. Inventory Management
Navigate to **Inventory** to:
- View all products
- Add new products
- Adjust stock levels
- Filter and search

### 3. Order Processing
Navigate to **Orders** to:
- Create new orders
- Update order status
- View order details
- Track fulfillment

### 4. Customer Management
Navigate to **Customers** to:
- View customer list
- Add new customers
- Track order history

### 5. Shipping & Receiving
- **Shipping**: Track outbound shipments
- **Receiving**: Manage inbound deliveries

## Common Tasks

### Add a New Product

1. Go to **Inventory**
2. Click **Add Product** button
3. Fill in product details
4. Click **Save**

### Create an Order

1. Go to **Orders**
2. Click **New Order** button
3. Select customer
4. Add products and quantities
5. Set delivery details
6. Click **Create Order**

### Adjust Stock

1. Go to **Inventory**
2. Find the product
3. Click the **Adjust Stock** button
4. Enter new quantity
5. Add reason (optional)
6. Click **Update**

### Generate Reports

1. Go to **Reports**
2. Select report type
3. Choose date range
4. Click **Generate**
5. Export or print

## Keyboard Shortcuts

- `Ctrl+K` or `Cmd+K` - Open command palette
- `Ctrl+/` - Toggle sidebar
- `Esc` - Close dialogs

## Troubleshooting

### Port Already in Use

If port 8080 is already in use:

```bash
# Change port in vite.config.ts or use:
PORT=3001 pnpm dev
```

### Database Connection Error

1. Verify MySQL is running:
```bash
# For Docker
docker ps

# For local MySQL
sudo systemctl status mysql
```

2. Check your `.env` file has correct credentials

3. Test connection:
```bash
mysql -u root -p -h localhost
```

### Prisma Migration Error

Reset the database:
```bash
pnpm prisma:migrate reset
```

### Module Not Found

Reinstall dependencies:
```bash
rm -rf node_modules
pnpm install
```

## Next Steps

Now that you're up and running:

1. 📖 Read the full [README.md](./README.md)
2. 🎨 Customize themes in Settings
3. 📊 Explore the reporting features
4. 🔧 Configure for your needs
5. 🚀 Deploy to production (see [DEPLOYMENT.md](./DEPLOYMENT.md))

## Need Help?

- 📚 Check the [full documentation](./README.md)
- 🐛 Report issues on GitHub
- 💬 Join our community chat
- 📧 Contact support

## Development Tips

### Hot Reload

The development server supports hot reload:
- Frontend changes reload instantly
- Backend changes restart the server automatically

### View Database

Open Prisma Studio to view/edit data:
```bash
npx prisma studio
```

Access at: `http://localhost:5555`

### Check Logs

View server logs in the terminal where you ran `pnpm dev`

### Type Checking

Run TypeScript type checking:
```bash
pnpm typecheck
```

### Run Tests

```bash
pnpm test
```

## Configuration

### Change Theme

1. Go to **Settings**
2. Select theme (Light, Dark, System)
3. Choose accent color
4. Changes apply instantly

### Customize Data

Edit seed data in `prisma/seed.ts` and run:
```bash
pnpm prisma:seed
```

## Production Build

When ready for production:

```bash
# Build the application
pnpm build

# Start production server
pnpm start
```

---

**Happy warehouse managing! 📦✨**

For detailed information, see the [complete README](./README.md)
