# 🤝 Contributing to invenTREE

Thank you for your interest in contributing to invenTREE! This document provides guidelines and instructions for contributing.

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Workflow](#development-workflow)
- [Coding Standards](#coding-standards)
- [Commit Guidelines](#commit-guidelines)
- [Pull Request Process](#pull-request-process)
- [Testing](#testing)
- [Documentation](#documentation)

## 📜 Code of Conduct

### Our Pledge

We are committed to providing a welcoming and inclusive environment for all contributors.

### Expected Behavior

- Be respectful and considerate
- Welcome newcomers and help them get started
- Focus on constructive feedback
- Accept responsibility for mistakes

### Unacceptable Behavior

- Harassment or discrimination
- Trolling or insulting comments
- Publishing private information
- Any unprofessional conduct

## 🚀 Getting Started

### Prerequisites

- Node.js 18+
- pnpm 8+
- MySQL 8+
- Git
- Code editor (VS Code recommended)

### Fork and Clone

1. Fork the repository on GitHub
2. Clone your fork:

```bash
git clone https://github.com/YOUR_USERNAME/warehouse-management.git
cd warehouse-management
```

3. Add upstream remote:

```bash
git remote add upstream https://github.com/ORIGINAL_OWNER/warehouse-management.git
```

### Install Dependencies

```bash
pnpm install
```

### Set Up Environment

```bash
cp .env.example .env
# Edit .env with your local configuration
```

### Start Development Server

```bash
pnpm dev
```

## 🔄 Development Workflow

### 1. Create a Branch

```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/your-bug-fix
```

Branch naming conventions:
- `feature/` - New features
- `fix/` - Bug fixes
- `docs/` - Documentation changes
- `refactor/` - Code refactoring
- `test/` - Test additions or changes
- `chore/` - Maintenance tasks

### 2. Make Changes

- Write clean, readable code
- Follow existing code style
- Add comments for complex logic
- Update documentation as needed

### 3. Test Your Changes

```bash
# Run tests
pnpm test

# Type checking
pnpm typecheck

# Build to ensure no errors
pnpm build
```

### 4. Commit Changes

```bash
git add .
git commit -m "feat: add new feature"
```

### 5. Keep Your Branch Updated

```bash
git fetch upstream
git rebase upstream/main
```

### 6. Push Changes

```bash
git push origin feature/your-feature-name
```

## 💻 Coding Standards

### TypeScript

- Use TypeScript for all new code
- Define proper types and interfaces
- Avoid `any` type unless absolutely necessary
- Use type inference when possible

```typescript
// Good
interface Product {
  id: string;
  name: string;
  price: number;
}

function getProduct(id: string): Product {
  // implementation
}

// Avoid
function getProduct(id: any): any {
  // implementation
}
```

### React Components

- Use functional components with hooks
- Keep components small and focused
- Extract reusable logic into custom hooks
- Use proper prop types

```tsx
// Good
interface ButtonProps {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary';
}

export function Button({ label, onClick, variant = 'primary' }: ButtonProps) {
  return (
    <button onClick={onClick} className={variant}>
      {label}
    </button>
  );
}
```

### File Organization

```
client/
├── components/
│   ├── ui/              # Base UI components
│   ├── Layout.tsx       # Layout components
│   └── FeatureComponent.tsx
├── hooks/               # Custom hooks
├── lib/                 # Utilities and helpers
├── pages/               # Page components
└── contexts/            # React contexts
```

### Naming Conventions

- **Components**: PascalCase (`UserProfile.tsx`)
- **Hooks**: camelCase with 'use' prefix (`useAuth.ts`)
- **Utilities**: camelCase (`formatDate.ts`)
- **Constants**: UPPER_SNAKE_CASE (`MAX_ITEMS`)
- **Types/Interfaces**: PascalCase (`UserData`)

### CSS/Styling

- Use TailwindCSS utility classes
- Follow existing design patterns
- Keep styles consistent
- Use CSS variables for theming

```tsx
// Good
<div className="flex items-center gap-4 p-4 bg-card rounded-lg">
  <span className="text-lg font-semibold">Title</span>
</div>
```

## 📝 Commit Guidelines

### Commit Message Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `test`: Test additions or changes
- `chore`: Maintenance tasks

### Examples

```bash
feat(inventory): add bulk delete functionality

Added ability to delete multiple products at once.
Includes confirmation dialog and success notification.

Closes #123

---

fix(orders): correct total calculation

Fixed bug where order total was not including tax.

Fixes #456

---

docs(readme): update installation instructions

Added detailed steps for MySQL setup.
```

### Commit Best Practices

- Write clear, concise commit messages
- Use present tense ("add feature" not "added feature")
- Reference issues and PRs when applicable
- Keep commits atomic (one logical change per commit)
- Don't commit commented-out code
- Don't commit console.logs or debug code

## 🔀 Pull Request Process

### Before Submitting

- [ ] Code follows project style guidelines
- [ ] All tests pass
- [ ] Type checking passes
- [ ] Documentation updated
- [ ] Commit messages follow guidelines
- [ ] Branch is up to date with main

### Creating a Pull Request

1. Push your branch to your fork
2. Go to the original repository
3. Click "New Pull Request"
4. Select your branch
5. Fill out the PR template

### PR Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
How has this been tested?

## Screenshots (if applicable)
Add screenshots here

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Comments added for complex code
- [ ] Documentation updated
- [ ] No new warnings generated
- [ ] Tests added/updated
- [ ] All tests passing
```

### Review Process

1. Maintainers will review your PR
2. Address any requested changes
3. Once approved, your PR will be merged
4. Your contribution will be credited

### After Merge

```bash
# Update your local main branch
git checkout main
git pull upstream main

# Delete your feature branch
git branch -d feature/your-feature-name
git push origin --delete feature/your-feature-name
```

## 🧪 Testing

### Running Tests

```bash
# Run all tests
pnpm test

# Run tests in watch mode
pnpm test:watch

# Run tests with coverage
pnpm test:coverage
```

### Writing Tests

- Write tests for new features
- Update tests for bug fixes
- Aim for high code coverage
- Test edge cases

```typescript
// Example test
import { describe, it, expect } from 'vitest';
import { calculateTotal } from './helpers';

describe('calculateTotal', () => {
  it('should calculate correct total', () => {
    const items = [
      { quantity: 2, price: 100 },
      { quantity: 1, price: 50 }
    ];
    expect(calculateTotal(items)).toBe(250);
  });

  it('should handle empty array', () => {
    expect(calculateTotal([])).toBe(0);
  });
});
```

## 📚 Documentation

### Code Documentation

- Add JSDoc comments for functions
- Document complex logic
- Include examples when helpful

```typescript
/**
 * Calculates the total price of order items
 * @param items - Array of order items with quantity and price
 * @returns Total price as a number
 * @example
 * const total = calculateTotal([
 *   { quantity: 2, price: 100 },
 *   { quantity: 1, price: 50 }
 * ]); // Returns 250
 */
export function calculateTotal(items: OrderItem[]): number {
  return items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
}
```

### README Updates

- Update README for new features
- Add examples and usage instructions
- Keep documentation current

### API Documentation

- Document new API endpoints
- Include request/response examples
- Note any breaking changes

## 🐛 Reporting Bugs

### Before Reporting

- Check existing issues
- Verify it's reproducible
- Test on latest version

### Bug Report Template

```markdown
## Bug Description
Clear description of the bug

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. See error

## Expected Behavior
What should happen

## Actual Behavior
What actually happens

## Screenshots
If applicable

## Environment
- OS: [e.g., Windows 10]
- Browser: [e.g., Chrome 96]
- Version: [e.g., 1.0.0]

## Additional Context
Any other relevant information
```

## 💡 Feature Requests

### Feature Request Template

```markdown
## Feature Description
Clear description of the feature

## Problem It Solves
What problem does this solve?

## Proposed Solution
How should it work?

## Alternatives Considered
Other solutions you've thought about

## Additional Context
Any other relevant information
```

## 🎯 Areas for Contribution

### Good First Issues

Look for issues labeled `good first issue` - these are great for newcomers!

### High Priority Areas

- Performance optimizations
- Test coverage improvements
- Documentation enhancements
- Accessibility improvements
- Bug fixes

### Feature Ideas

- Advanced reporting features
- Mobile app integration
- Barcode scanning
- Email notifications
- Multi-warehouse support
- Advanced analytics

## 📞 Getting Help

- **Questions**: Open a discussion on GitHub
- **Bugs**: Open an issue
- **Security**: Email security@example.com
- **Chat**: Join our Discord/Slack

## 🏆 Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Credited in release notes
- Mentioned in documentation

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to invenTREE! 🎉
