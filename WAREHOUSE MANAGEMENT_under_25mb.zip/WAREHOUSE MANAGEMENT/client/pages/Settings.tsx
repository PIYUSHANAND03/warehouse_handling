import { useEffect, useRef, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "@/hooks/use-toast";

export default function Settings() {
  const navigate = useNavigate();
  const location = useLocation();
  const profileRef = useRef<HTMLDivElement | null>(null);

  // Theme mode: "light" | "dark" | "system"
  const [theme, setTheme] = useState<"light" | "dark" | "system">(() => {
    const stored = localStorage.getItem("theme") as "light" | "dark" | "system" | null;
    return stored ?? "dark";
  });

  // Accent color (HSL string)
  const [accent, setAccent] = useState<string>(() => localStorage.getItem("accent") || "217 91% 60%");

  // Notifications
  const [emailNotif, setEmailNotif] = useState<boolean>(() => (localStorage.getItem("notif:email") ?? "on") !== "off");
  const [pushNotif, setPushNotif] = useState<boolean>(() => (localStorage.getItem("notif:push") ?? "on") !== "off");

  // Language
  const [language, setLanguage] = useState<string>(() => localStorage.getItem("lang") || "en");

  // Apply theme changes
  useEffect(() => {
    localStorage.setItem("theme", theme);
    const root = document.documentElement;
    const w = window as any;
    // remove previous system listener if present
    if (w.__themeMql && w.__themeListener) {
      w.__themeMql.removeEventListener?.("change", w.__themeListener);
      w.__themeMql = null;
      w.__themeListener = null;
    }
    if (theme === "system") {
      const mql = window.matchMedia("(prefers-color-scheme: dark)");
      const set = () => root.classList.toggle("dark", mql.matches);
      set();
      mql.addEventListener("change", set);
      w.__themeMql = mql;
      w.__themeListener = set;
    } else {
      root.classList.toggle("dark", theme === "dark");
    }
  }, [theme]);

  // Apply accent color
  useEffect(() => {
    document.documentElement.style.setProperty("--primary", accent);
    localStorage.setItem("accent", accent);
  }, [accent]);

  // Persist notification and language preferences
  useEffect(() => {
    localStorage.setItem("notif:email", emailNotif ? "on" : "off");
  }, [emailNotif]);
  useEffect(() => {
    localStorage.setItem("notif:push", pushNotif ? "on" : "off");
  }, [pushNotif]);
  useEffect(() => {
    localStorage.setItem("lang", language);
  }, [language]);

  const accentOptions = [
    { name: "Blue", value: "217 91% 60%" },
    { name: "Purple", value: "259 94% 61%" },
    { name: "Emerald", value: "142 76% 36%" },
    { name: "Orange", value: "27 96% 61%" },
  ];

  // Profile state (local overrides for demo)
  const [name, setName] = useState<string>(() => {
    try {
      const o = JSON.parse(localStorage.getItem('profile:overrides')||'{}');
      return o.name || '';
    } catch { return ''; }
  });
  const [email, setEmail] = useState<string>(() => {
    try {
      const o = JSON.parse(localStorage.getItem('profile:overrides')||'{}');
      return o.email || '';
    } catch { return ''; }
  });
  const [avatarUrl, setAvatarUrl] = useState<string>(() => {
    try {
      const o = JSON.parse(localStorage.getItem('profile:overrides')||'{}');
      return o.avatarUrl || '';
    } catch { return ''; }
  });

  const saveProfile = () => {
    const overrides: any = {};
    if (name) overrides.name = name;
    if (email) overrides.email = email;
    if (avatarUrl) overrides.avatarUrl = avatarUrl;
    localStorage.setItem('profile:overrides', JSON.stringify(overrides));
    toast({ title: 'Profile saved', description: 'Local profile overrides updated.'});
  };

  const resetProfile = () => {
    localStorage.removeItem('profile:overrides');
    setName('');
    setEmail('');
    setAvatarUrl('');
    toast({ title: 'Profile reset', description: 'Reverted to server profile.'});
  };

  // If opened with tab=profile, scroll to the profile section
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('tab') === 'profile') {
      setTimeout(() => profileRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    }
  }, [location.search]);

  return (
    <div data-zone="settings" className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-10 w-full border-b border-border bg-card/70 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-primary p-2 text-primary-foreground">
              <i className="fas fa-gear"></i>
            </div>
            <h1 className="text-2xl font-bold">Settings</h1>
          </div>
          <Button variant="outline" onClick={() => navigate("/")}> 
            <i className="fas fa-arrow-left mr-2"></i>
            Back to Dashboard
          </Button>
        </div>
      </header>

      <main className="mx-auto grid max-w-5xl gap-6 p-6">
        {/* Profile */}
        <Card ref={profileRef as any}>
          <CardHeader>
            <CardTitle>Profile</CardTitle>
            <CardDescription>Update your personal information. Changes are stored locally for this demo.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={avatarUrl || undefined} alt={name || 'User'} />
                <AvatarFallback>{(name || 'User').split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="text-sm text-muted-foreground">Avatar URL is used for your profile picture.</div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Full name</Label>
                <Input id="name" value={name} onChange={(e)=>setName(e.target.value)} placeholder="Alex Johnson" />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="alex.johnson@example.com" />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="avatar">Avatar URL</Label>
                <Input id="avatar" value={avatarUrl} onChange={(e)=>setAvatarUrl(e.target.value)} placeholder="https://..." />
              </div>
            </div>
            <div className="flex gap-3">
              <Button onClick={saveProfile}>
                <i className="fas fa-save mr-2" /> Save changes
              </Button>
              <Button variant="outline" onClick={resetProfile}>
                <i className="fas fa-rotate-left mr-2" /> Reset to server profile
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Appearance */}
        <Card>
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Theme, accent color, and display preferences.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label className="text-base">Theme Mode</Label>
              <RadioGroup value={theme} onValueChange={(v) => setTheme(v as any)} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="flex items-center gap-3 rounded-md border border-border bg-card p-3">
                  <RadioGroupItem id="theme-light" value="light" />
                  <Label htmlFor="theme-light">Light</Label>
                </div>
                <div className="flex items-center gap-3 rounded-md border border-border bg-card p-3">
                  <RadioGroupItem id="theme-dark" value="dark" />
                  <Label htmlFor="theme-dark">Dark</Label>
                </div>
                <div className="flex items-center gap-3 rounded-md border border-border bg-card p-3">
                  <RadioGroupItem id="theme-system" value="system" />
                  <Label htmlFor="theme-system">System</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-3">
              <Label className="text-base">Accent Color</Label>
              <div className="flex flex-wrap gap-3">
                {accentOptions.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setAccent(opt.value)}
                    className={`h-10 w-10 rounded-full border-2 ${accent === opt.value ? "border-primary ring-2 ring-primary/40" : "border-border"}`}
                    style={{ backgroundColor: `hsl(${opt.value})` }}
                    aria-label={opt.name}
                  />
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>Choose how you want to be notified.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-md border border-border bg-card p-4">
              <div>
                <Label htmlFor="emailNotif" className="text-base">Email notifications</Label>
                <p className="text-sm text-muted-foreground">Receive order updates by email.</p>
              </div>
              <Switch id="emailNotif" checked={emailNotif} onCheckedChange={setEmailNotif} />
            </div>
            <div className="flex items-center justify-between rounded-md border border-border bg-card p-4">
              <div>
                <Label htmlFor="pushNotif" className="text-base">Push notifications</Label>
                <p className="text-sm text-muted-foreground">Allow in-app alerts and sounds.</p>
              </div>
              <Switch id="pushNotif" checked={pushNotif} onCheckedChange={setPushNotif} />
            </div>
          </CardContent>
        </Card>

        {/* Language */}
        <Card>
          <CardHeader>
            <CardTitle>Language</CardTitle>
            <CardDescription>Set your preferred language.</CardDescription>
          </CardHeader>
          <CardContent className="max-w-sm">
            <Label className="mb-2 block" htmlFor="language">Interface language</Label>
            <select
              id="language"
              className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
            >
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
              <option value="de">Deutsch</option>
            </select>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
