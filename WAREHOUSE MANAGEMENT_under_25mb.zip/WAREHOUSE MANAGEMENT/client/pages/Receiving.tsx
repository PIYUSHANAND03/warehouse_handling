import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { api } from "@/lib/api";

export default function Receiving() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Inbound shipments from backend
  const [inbound, setInbound] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      const res = await api.inbound.getAll();
      if (mounted && res.success && res.data) setInbound(res.data as any[]);
      setLoading(false);
    })();
    return () => { mounted = false };
  }, []);

  const filtered = inbound.filter((x) => {
    const s = searchTerm.toLowerCase();
    const matches =
      x.id.toLowerCase().includes(s) ||
      x.vendor.toLowerCase().includes(s) ||
      x.location.toLowerCase().includes(s);
    const statusOk = statusFilter === "all" || x.status === statusFilter;
    return matches && statusOk;
  });

  const stats = {
    incoming: inbound.length,
    arrived: inbound.filter((x) => x.status === "arrived").length,
    inProgress: inbound.filter((x) => x.status === "in-progress").length,
    qcHold: inbound.filter((x) => x.status === "qc-hold").length,
    received: inbound.filter((x) => x.status === "received").length,
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  const statusColor = (status: string) => {
    switch (status) {
      case "arrived":
        return "#22c55e";
      case "in-progress":
        return "#3b82f6";
      case "qc-hold":
        return "#f59e0b";
      case "received":
        return "#8b5cf6";
      default:
        return "#6b7280";
    }
  };

  const handle = async (action: string, id: string) => {
    try {
      if (action === 'View') {
        toast({ title: 'View', description: `Viewing ${id}` });
        return;
      }
      if (action === 'Check-in') {
        const res = await api.inbound.updateStatus(id, 'in-progress');
        if (!res.success) throw new Error(res.error || 'Failed to update');
        toast({ title: 'Checked-in', description: `${id} marked in-progress` });
      } else if (action === 'Report Issue') {
        const res = await api.inbound.updateStatus(id, 'qc-hold');
        if (!res.success) throw new Error(res.error || 'Failed to update');
        toast({ title: 'Issue Reported', description: `${id} put on QC hold` });
      } else if (action === 'Mark Received') {
        const res = await api.inbound.updateStatus(id, 'received');
        if (!res.success) throw new Error(res.error || 'Failed to update');
        toast({ title: 'Received', description: `${id} marked received` });
      }
      // Refresh list after any mutation
      const updated = await api.inbound.getAll();
      if (updated.success && updated.data) setInbound(updated.data as any[]);
    } catch (err: any) {
      toast({ title: 'Action failed', description: String(err?.message || err) });
    }
  };

  return (
    <div data-zone="receiving" className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/70 backdrop-blur border-b border-border sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate("/")}
                className="flex items-center px-4 py-2 rounded-lg border border-border bg-card hover:bg-secondary transition-colors"
              >
                <i className="fas fa-arrow-left mr-2"></i>
                Back to Dashboard
              </button>
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-lg bg-primary text-primary-foreground">
                  <i className="fas fa-dolly"></i>
                </div>
                <h1 className="text-2xl font-bold">Receiving</h1>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"></i>
                <input
                  placeholder="Search inbound shipments..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-80 bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                />
              </div>
              <button
                onClick={() => handle("Create ASN", "NEW")}
                className="flex items-center px-4 py-2 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors"
              >
                <i className="fas fa-file-invoice mr-2"></i>
                Create ASN
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-blue-100">Incoming</h3>
              <i className="fas fa-inbox text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats.incoming}</div>
            <div className="text-sm text-blue-100">Total shipments</div>
          </div>
          <div className="bg-gradient-to-br from-green-500 to-emerald-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-green-100">Arrived</h3>
              <i className="fas fa-check-circle text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats.arrived}</div>
            <div className="text-sm text-green-100">At dock</div>
          </div>
          <div className="bg-gradient-to-br from-indigo-500 to-blue-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-indigo-100">In Progress</h3>
              <i className="fas fa-spinner text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats.inProgress}</div>
            <div className="text-sm text-indigo-100">Unloading/QC</div>
          </div>
          <div className="bg-gradient-to-br from-orange-500 to-yellow-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-orange-100">QC Hold</h3>
              <i className="fas fa-triangle-exclamation text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats.qcHold}</div>
            <div className="text-sm text-orange-100">Issues found</div>
          </div>
          <div className="bg-gradient-to-br from-purple-500 to-violet-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-purple-100">Received</h3>
              <i className="fas fa-boxes-stacked text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats.received}</div>
            <div className="text-sm text-purple-100">Putaway pending</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center px-3 py-1 rounded-lg border border-border bg-card text-sm">
              <span className="text-muted-foreground">{filtered.length} records</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="fas fa-filter text-muted-foreground"></i>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-card border border-border rounded-lg px-3 py-1 text-sm text-foreground focus:outline-none focus:border-primary"
              >
                <option value="all">All Status</option>
                <option value="arrived">Arrived</option>
                <option value="in-progress">In Progress</option>
                <option value="qc-hold">QC Hold</option>
                <option value="received">Received</option>
              </select>
            </div>
          </div>
        </div>

        {/* Inbound list */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {filtered.map((s) => (
            <div key={s.id} className="bg-card border border-border rounded-xl p-6 hover:border-primary transition-all duration-200">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <div className="px-2 py-1 rounded text-xs text-white font-medium" style={{ backgroundColor: statusColor(s.status) }}>
                    {s.status}
                  </div>
                </div>
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: statusColor(s.status) }}></div>
              </div>

              <h3 className="text-xl font-semibold mb-1">{s.id}</h3>
              <p className="text-sm text-muted-foreground mb-3">Vendor: {s.vendor}</p>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">ETA</div>
                  <div className="font-medium flex items-center gap-2"><i className="fas fa-clock text-muted-foreground"></i>{s.eta}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Dock</div>
                  <div className="font-medium flex items-center gap-2"><i className="fas fa-warehouse text-muted-foreground"></i>{s.location}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Cartons</div>
                  <div className="font-medium">{s.cartons}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Items</div>
                  <div className="font-medium">{s.items}</div>
                </div>
              </div>

              <div className="mt-3 text-sm text-muted-foreground">{s.notes}</div>

              <div className="flex items-center justify-between pt-3">
                <div className="text-xs text-muted-foreground">Ready for processing</div>
                <div className="flex items-center gap-2">
                  <button onClick={() => handle("View", s.id)} className="p-2 text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-secondary">
                    <i className="fas fa-eye"></i>
                  </button>
                  <button onClick={() => handle("Check-in", s.id)} className="p-2 text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-secondary">
                    <i className="fas fa-check"></i>
                  </button>
                  <button onClick={() => handle("Report Issue", s.id)} className="p-2 text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-secondary">
                    <i className="fas fa-triangle-exclamation"></i>
                  </button>
                  <button onClick={() => handle("Mark Received", s.id)} className="p-2 text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-secondary">
                    <i className="fas fa-box"></i>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
