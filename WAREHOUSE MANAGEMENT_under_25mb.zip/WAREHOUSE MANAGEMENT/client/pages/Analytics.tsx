import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { DemandForecast } from "../components/analytics/DemandForecast";
import { StorageOptimization } from "../components/analytics/StorageOptimization";
import { RobotPathOptimization } from "../components/analytics/RobotPathOptimization";

export default function Analytics() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Warehouse Analytics</h1>
      
      <Tabs defaultValue="demand" className="space-y-4">
        <TabsList>
          <TabsTrigger value="demand">Demand Forecast</TabsTrigger>
          <TabsTrigger value="storage">Storage Optimization</TabsTrigger>
          <TabsTrigger value="robot">Robot Paths</TabsTrigger>
        </TabsList>
        
        <TabsContent value="demand">
          <Card>
            <CardHeader>
              <CardTitle>Demand Forecasting</CardTitle>
            </CardHeader>
            <CardContent>
              <DemandForecast />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="storage">
          <Card>
            <CardHeader>
              <CardTitle>Storage Optimization</CardTitle>
            </CardHeader>
            <CardContent>
              <StorageOptimization />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="robot">
          <Card>
            <CardHeader>
              <CardTitle>Robot Path Optimization</CardTitle>
            </CardHeader>
            <CardContent>
              <RobotPathOptimization />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
