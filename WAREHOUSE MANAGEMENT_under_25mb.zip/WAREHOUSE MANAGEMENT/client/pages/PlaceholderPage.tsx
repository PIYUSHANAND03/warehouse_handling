import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Warehouse, ArrowLeft } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

interface PlaceholderPageProps {
  title?: string;
  description?: string;
}

export default function PlaceholderPage({ 
  title = "Page Coming Soon", 
  description = "This page is currently under development. Check back soon for new features!" 
}: PlaceholderPageProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const getPageTitle = () => {
    const path = location.pathname;
    if (path.includes('stock')) return 'Stock Management';
    if (path.includes('orders')) return 'Order Management';
    if (path.includes('sellers')) return 'Seller Management';
    if (path.includes('reports')) return 'Reports & Analytics';
    if (path.includes('settings')) return 'Settings';
    return title;
  };

  const getPageDescription = () => {
    const path = location.pathname;
    if (path.includes('stock')) return 'Comprehensive stock tracking and management tools';
    if (path.includes('orders')) return 'Complete order processing and fulfillment system';
    if (path.includes('sellers')) return 'Seller onboarding and management platform';
    if (path.includes('reports')) return 'Advanced analytics and reporting dashboard';
    if (path.includes('settings')) return 'System configuration and user preferences';
    return description;
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/70 backdrop-blur border-b border-border sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Warehouse className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-slate-900">invenTREE</h1>
              </div>
            </div>
            
            <Button variant="outline" onClick={() => navigate('/')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="text-center">
            <CardHeader className="pb-8">
              <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <Warehouse className="h-8 w-8 text-blue-600" />
              </div>
              <CardTitle className="text-2xl">{getPageTitle()}</CardTitle>
              <CardDescription className="text-lg mt-2">
                {getPageDescription()}
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-8">
              <div className="space-y-4">
                <p className="text-slate-600">
                  We're working hard to bring you this feature. In the meantime, 
                  you can continue using the main dashboard to manage your warehouse operations.
                </p>
                <div className="flex justify-center space-x-4">
                  <Button onClick={() => navigate('/')}>
                    Return to Dashboard
                  </Button>
                  <Button variant="outline" onClick={() => window.location.reload()}>
                    Check for Updates
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Additional Information */}
          <div className="mt-8 text-center text-sm text-slate-500">
            <p>
              Need immediate assistance? Contact our support team or continue prompting 
              to help us build this page according to your specific requirements.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
