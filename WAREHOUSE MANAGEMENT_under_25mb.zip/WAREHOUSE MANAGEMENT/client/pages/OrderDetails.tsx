import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { api, Order, Invoice } from "@/lib/api";
import { useApi, useUpdateOrder, useUpdateOrderStatus } from "@/hooks/useApi";

export default function OrderDetails() {
  const navigate = useNavigate();
  const { id } = useParams();

  const { data: order, loading, error, refetch } = useApi<Order>(
    () => api.orders.getById(id || ""),
    [id]
  );
  const { data: invoice, loading: invoiceLoading } = useApi<Invoice>(
    () => api.orders.getInvoice(id || ""),
    [id]
  );

  const { updateOrder, loading: updating } = useUpdateOrder();
  const { updateStatus, loading: updatingStatus } = useUpdateOrderStatus();

  const [local, setLocal] = useState<{
    priority?: Order["priority"]; 
    deliveryDate?: string; 
    trackingNumber?: string; 
    notes?: string;
  }>({});

  const displayOrder = useMemo(() => order, [order]);

  const handleSave = async () => {
    if (!id) return;
    try {
      await updateOrder(id, {
        priority: local.priority || displayOrder?.priority,
        deliveryDate: local.deliveryDate || displayOrder?.deliveryDate,
        trackingNumber: local.trackingNumber || displayOrder?.trackingNumber,
        notes: local.notes ?? displayOrder?.notes,
      });
      toast({ title: "Order updated" });
      setLocal({});
      refetch();
    } catch (e: any) {
      toast({ title: "Failed to update", description: e?.message || String(e), variant: "destructive" });
    }
  };

  const handleStatusChange = async (status: Order["status"]) => {
    if (!id) return;
    try {
      await updateStatus(id, status);
      toast({ title: `Status set to ${status}` });
      refetch();
    } catch (e: any) {
      toast({ title: "Failed to update status", description: e?.message || String(e), variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground p-6">Loading...</div>
    );
  }

  if (error || !displayOrder) {
    return (
      <div className="min-h-screen bg-background text-foreground p-6">
        <div className="mb-4">
          <Button variant="outline" onClick={() => navigate(-1)}>Back</Button>
        </div>
        <div className="text-red-500">Failed to load order.</div>
      </div>
    );
  }

  const o = displayOrder;
  const formatCurrency = (n: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(n);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="bg-card/70 backdrop-blur border-b border-border sticky top-0 z-50">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button variant="outline" onClick={() => navigate("/orders")}>Back to Orders</Button>
            <h1 className="text-2xl font-bold">Order {o.id}</h1>
          </div>
          <div className="flex items-center space-x-3">
            <Select value={o.status} onValueChange={(v) => handleStatusChange(v as Order["status"]) }>
              <SelectTrigger className="w-[180px]"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                {(["pending","processing","shipped","completed","cancelled"] as const).map(s => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={handleSave} disabled={updating || updatingStatus}>Save Changes</Button>
          </div>
        </div>
      </header>

      <main className="px-6 py-8 space-y-8 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Items ({o.totalItems})</CardTitle>
              <CardDescription>Total value {formatCurrency(o.totalValue)}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="text-left text-sm text-muted-foreground">
                    <tr>
                      <th className="p-2">Product</th>
                      <th className="p-2">Qty</th>
                      <th className="p-2">Unit Price</th>
                      <th className="p-2">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {o.items.map((it) => (
                      <tr key={`${it.productId}`} className="border-b border-border">
                        <td className="p-2">{it.productName}</td>
                        <td className="p-2">{it.quantity}</td>
                        <td className="p-2">{formatCurrency(it.unitPrice)}</td>
                        <td className="p-2 font-medium">{formatCurrency(it.totalPrice)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Customer</CardTitle>
              <CardDescription>Contact and address</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="font-medium">{o.customer.name}</div>
              <div className="text-sm text-muted-foreground">{o.customer.email}</div>
              <div className="text-sm text-muted-foreground">{o.customer.phone}</div>
              <div className="text-sm">
                {o.shippingAddress.street}, {o.shippingAddress.city}, {o.shippingAddress.state} {o.shippingAddress.pincode}, {o.shippingAddress.country}
              </div>
              <div className="text-xs text-muted-foreground">Delivery: {new Date(o.deliveryDate).toLocaleDateString()}</div>
            </CardContent>
          </Card>
        </div>

        {/* Invoice */}
        <Card>
          <CardHeader>
            <CardTitle>Invoice</CardTitle>
            <CardDescription>Generated automatically</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {invoiceLoading && (
              <div className="text-sm text-muted-foreground">Generating invoice...</div>
            )}
            {!invoiceLoading && invoice && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Invoice ID</div>
                  <div className="font-medium">{invoice.id}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Invoice Date</div>
                  <div className="font-medium">{new Date(invoice.invoiceDate).toLocaleDateString()}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Due Date</div>
                  <div className="font-medium">{new Date(invoice.dueDate).toLocaleDateString()}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Total</div>
                  <div className="font-medium">{formatCurrency(invoice.total)}</div>
                </div>
              </div>
            )}
            {!invoiceLoading && !invoice && (
              <div className="text-sm text-muted-foreground">Invoice unavailable.</div>
            )}
            <div>
              <Button
                variant="outline"
                disabled={invoiceLoading}
                onClick={async () => {
                  try {
                    await api.orders.downloadInvoice(o.id, 'pdf');
                  } catch (e: any) {
                    toast({ title: "Download failed", description: e?.message || "Unable to download invoice", variant: "destructive" });
                  }
                }}
              >
                Download PDF
              </Button>
            </div>
          </CardContent>
        </Card>

        {o.status === 'shipped' && o.shipments && o.shipments.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Shipment</CardTitle>
              <CardDescription>Shipment details</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Status: {o.shipments[0].status}</p>
              <p>Carrier: {o.shipments[0].carrier}</p>
              <p>Tracking #: {o.shipments[0].trackingNumber}</p>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Edit Details</CardTitle>
            <CardDescription>Priority, delivery, tracking, and notes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Priority</Label>
                <Select
                  value={local.priority ?? o.priority}
                  onValueChange={(v) => setLocal((p) => ({ ...p, priority: v as Order["priority"] }))}
                >
                  <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
                  <SelectContent>
                    {(['low','medium','high'] as const).map(p => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Delivery Date</Label>
                <Input
                  type="date"
                  value={(local.deliveryDate ?? o.deliveryDate).slice(0,10)}
                  onChange={(e) => setLocal((p) => ({ ...p, deliveryDate: e.target.value }))}
                />
              </div>
              <div>
                <Label>Tracking Number</Label>
                <Input
                  value={local.trackingNumber ?? (o.trackingNumber || "")}
                  onChange={(e) => setLocal((p) => ({ ...p, trackingNumber: e.target.value }))}
                  placeholder="Enter tracking number"
                />
              </div>
            </div>
            <div>
              <Label>Notes</Label>
              <Textarea
                value={local.notes ?? (o.notes || "")}
                onChange={(e) => setLocal((p) => ({ ...p, notes: e.target.value }))}
                rows={3}
                placeholder="Additional notes..."
              />
            </div>
            <div className="flex justify-end">
              <Button onClick={handleSave} disabled={updating || updatingStatus}>Save Changes</Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}