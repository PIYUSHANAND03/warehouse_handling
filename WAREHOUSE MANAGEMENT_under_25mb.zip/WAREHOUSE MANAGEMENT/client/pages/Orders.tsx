import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { api } from "@/lib/api";
import { useOrders, useOrderStats, useUpdateOrderStatus } from "@/hooks/useApi";
import { useWebSocket } from "@/hooks/useWebSocket";
import { format } from "date-fns";

export default function Orders() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");

  const { data: orders, loading, error, refetch } = useOrders({
    status: selectedStatus === "all" ? undefined : selectedStatus,
    search: searchTerm || undefined,
    limit: 50,
  });
  const { data: stats, refetch: refetchStats } = useOrderStats();
  const { updateStatus, loading: updating } = useUpdateOrderStatus();
  const { orderUpdates } = useWebSocket();

  // Live-refetch when order events arrive (creation or status changes)
  useEffect(() => {
    if (!orderUpdates.length) return;
    refetch();
    refetchStats();
  }, [orderUpdates, refetch, refetchStats]);

  const ordersData = useMemo(() => orders || [], [orders]);

  const formatCurrency = (n: number) =>
    new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(n);

  const handleProcess = async (orderId: string, currentStatus: string) => {
    if (updating) return;
    const flow: Record<string, string | null> = {
      pending: "processing",
      processing: "shipped",
      shipped: "completed",
      completed: null,
      cancelled: null,
    };
    const next = flow[currentStatus] ?? null;
    if (!next) {
      toast({ title: "No further action", description: `Order is ${currentStatus}.` });
      return;
    }
    try {
      await updateStatus(orderId, next as any);
      toast({ title: `Order moved to ${next}` });
      refetch();
    } catch (e: any) {
      toast({ title: "Failed to update", description: e?.message || String(e), variant: "destructive" });
    }
  };

  const handleNewOrder = () => {
    navigate('/new-order');
  };

  const handleDownloadPdf = async () => {
    try {
      // Get current date for filename
      const dateStr = format(new Date(), 'yyyy-MM-dd');
      const filename = `orders-report-${dateStr}.pdf`;
      
      // First get the orders data with current filters
      const response = await api.orders.getAll({
        status: selectedStatus === 'all' ? undefined : selectedStatus,
        search: searchTerm || undefined,
        limit: 1000 // Get all matching orders
      });

      if (!response.data || response.data.length === 0) {
        toast({
          title: "No orders found",
          description: "There are no orders to generate a report for with the current filters.",
          variant: "destructive"
        });
        return;
      }

      // Trigger download for the first order (as a workaround since we don't have a bulk download endpoint)
      // In a real app, you would want to implement a proper report generation endpoint
      await api.orders.downloadInvoice(response.data[0].id, 'pdf');
      
      toast({
        title: "Download started",
        description: `Generating report for ${response.data.length} orders...`
      });
    } catch (error) {
      console.error('Failed to download PDF:', error);
      toast({
        title: "Download failed",
        description: "Could not generate the orders report. Please try again.",
        variant: "destructive"
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "#22c55e";
      case "processing":
        return "#3b82f6";
      case "pending":
        return "#f59e0b";
      case "shipped":
        return "#8b5cf6";
      case "cancelled":
        return "#ef4444";
      default:
        return "#6b7280";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "#ef4444";
      case "medium":
        return "#f59e0b";
      case "low":
        return "#3b82f6";
      default:
        return "#6b7280";
    }
  };

  return (
    <div data-zone="orders" className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/70 backdrop-blur border-b border-border sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="flex items-center px-4 py-2 rounded-lg border border-border bg-card hover:bg-secondary transition-colors"
              >
                <i className="fas fa-arrow-left mr-2"></i>
                Back to Dashboard
              </button>
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-lg bg-primary text-primary-foreground">
                  <i className="fas fa-clipboard-list text-white"></i>
                </div>
                <h1 className="text-2xl font-bold">
                  Orders
                </h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"></i>
                <input
                  placeholder="Search orders..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-80 bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                />
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={handleDownloadPdf}
                  className="flex items-center px-4 py-2 rounded-lg border border-border bg-card hover:bg-secondary transition-colors"
                >
                  <i className="fas fa-file-pdf mr-2 text-red-500"></i>
                  Download PDF
                </button>
                <button 
                  onClick={handleNewOrder} 
                  className="flex items-center px-4 py-2 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors"
                >
                  <i className="fas fa-plus mr-2"></i>
                  New Order
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-blue-100">Total Orders</h3>
              <i className="fas fa-shopping-cart text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats?.totalOrders ?? 0}</div>
            <div className="text-sm text-blue-100">All time</div>
          </div>

          <div className="bg-gradient-to-br from-green-500 to-emerald-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-green-100">Completed</h3>
              <i className="fas fa-check-circle text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats?.completed ?? 0}</div>
            <div className="text-sm text-green-100">Delivered</div>
          </div>

          <div className="bg-gradient-to-br from-indigo-500 to-blue-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-indigo-100">Processing</h3>
              <i className="fas fa-spinner text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats?.processing ?? 0}</div>
            <div className="text-sm text-indigo-100">In progress</div>
          </div>

          <div className="bg-gradient-to-br from-orange-500 to-yellow-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-orange-100">Pending</h3>
              <i className="fas fa-clock text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats?.pending ?? 0}</div>
            <div className="text-sm text-orange-100">Awaiting</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-violet-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-purple-100">Shipped</h3>
              <i className="fas fa-truck text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats?.shipped ?? 0}</div>
            <div className="text-sm text-purple-100">En route</div>
          </div>

          <div className="bg-gradient-to-br from-teal-500 to-cyan-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-teal-100">Total Value</h3>
              <i className="fas fa-rupee-sign text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats ? formatCurrency(stats.totalValue) : '₹0'}</div>
            <div className="text-sm text-teal-100">Revenue</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center px-3 py-1 bg-card border border-border rounded-lg text-sm">
              <span className="text-muted-foreground">{ordersData.length} orders found</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="fas fa-filter text-muted-foreground"></i>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-card border border-border rounded-lg px-3 py-1 text-sm text-[#e0e0e0] focus:outline-none focus:border-[#4f46e5]"
              >
                <option value="all">All Status</option>
                <option value="completed">Completed</option>
                <option value="processing">Processing</option>
                <option value="pending">Pending</option>
                <option value="shipped">Shipped</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>
        </div>

        {/* Orders List */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-secondary border-b border-border">
                <tr>
                  <th className="text-left p-4 font-medium text-muted-foreground">Order</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Customer</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Items</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Value</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Priority</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Invoice</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Date</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr><td className="p-4" colSpan={8}>Loading...</td></tr>
                )}
                {error && !loading && (
                  <tr><td className="p-4 text-red-500" colSpan={8}>Failed to load orders.</td></tr>
                )}
                {!loading && !error && ordersData.map((order) => (
                  <tr key={order.id} className="border-b border-border hover:bg-secondary transition-colors">
                    <td className="p-4">
                      <div>
                        <div className="font-medium">{order.id}</div>
                        <div className="text-sm text-muted-foreground">{order.customer?.email}</div>
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <div className="font-medium">{order.customer?.name}</div>
                        <div className="text-sm text-muted-foreground">{order.customer?.phone}</div>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="font-medium">{order.totalItems} items</div>
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-lg">{formatCurrency(order.totalValue)}</div>
                    </td>
                    <td className="p-4">
                      <div 
                        className="px-2 py-1 rounded text-xs text-white font-medium inline-flex items-center"
                        style={{ backgroundColor: getStatusColor(order.status) }}
                      >
                        <div 
                          className="w-2 h-2 rounded-full mr-2"
                          style={{ backgroundColor: "rgba(255,255,255,0.8)" }}
                        ></div>
                        {order.status}
                      </div>
                    </td>
                    <td className="p-4">
                      <div 
                        className="px-2 py-1 rounded text-xs text-white font-medium inline-block"
                        style={{ backgroundColor: getPriorityColor(order.priority) }}
                      >
                        {order.priority}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">PDF</div>
                        <button
                          onClick={async () => {
                            try {
                              await api.orders.downloadInvoice(order.id, 'pdf');
                            } catch (e: any) {
                              toast({ title: "Download failed", description: e?.message || "Unable to download invoice", variant: "destructive" });
                            }
                          }}
                          className="px-2 py-1 border rounded text-sm hover:bg-secondary"
                        >
                          Download PDF
                        </button>
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <div className="font-medium">{new Date(order.orderDate).toLocaleDateString()}</div>
                        <div className="text-sm text-muted-foreground">Due: {new Date(order.deliveryDate).toLocaleDateString()}</div>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => navigate(`/orders/${order.id}`)}
                          className="p-1 text-muted-foreground hover:text-[#e0e0e0] transition-colors"
                        >
                          <i className="fas fa-eye"></i>
                        </button>
                        <button 
                          onClick={() => navigate(`/orders/${order.id}`)}
                          className="p-1 text-muted-foreground hover:text-[#e0e0e0] transition-colors"
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        <button 
                          onClick={() => handleProcess(order.id, order.status)}
                          className="p-1 text-muted-foreground hover:text-[#22c55e] transition-colors"
                        >
                          <i className="fas fa-check"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {!loading && !error && ordersData.length === 0 && (
                  <tr><td className="p-4" colSpan={8}>No orders found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
