import { useState, useEffect, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { useProducts, useBulkOperations } from "@/hooks/useApi";
import { Product } from "@/lib/api";
import { EditProductDialog } from "@/components/EditProductDialog";
import { DeleteConfirmationDialog } from "@/components/DeleteConfirmationDialog";
import { StockAdjustmentDialog } from "@/components/StockAdjustmentDialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Stock() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Dialog states
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [deleteProduct, setDeleteProduct] = useState<Product | null>(null);
  const [adjustStockProduct, setAdjustStockProduct] = useState<Product | null>(null);
  
  // Sync initial search from URL (?search=...)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const q = params.get("search") || "";
    setSearchTerm(q);
  }, [location.search]);

  // Create filters object for API call
  const filters = {
    search: searchTerm || undefined,
    category: categoryFilter || undefined,
    status: statusFilter || undefined,
  };
  
  // Fetch real data from API with filters
  const { data: products, loading, error, refetch } = useProducts(filters);
  const { bulkDelete, bulkUpdate, loading: bulkLoading } = useBulkOperations();
  const stockItems: Product[] = products || [];


  const filteredItems = useMemo(() => stockItems, [stockItems]); // API handles filtering now

  const totalItems = stockItems.length;
  const lowStockItems = stockItems.filter((item) => item.status === "low-stock").length;
  const totalValue = stockItems.reduce((sum, item) => sum + (item.price * item.stock), 0);
  const categories = Array.from(new Set(stockItems.map(item => item.category))).sort();

  // Selection handlers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedItems(filteredItems.map(item => item.id));
    } else {
      setSelectedItems([]);
    }
  };

  const handleSelectItem = (itemId: string, checked: boolean) => {
    if (checked) {
      setSelectedItems(prev => [...prev, itemId]);
    } else {
      setSelectedItems(prev => prev.filter(id => id !== itemId));
    }
  };

  // Action handlers
  const handleEditProduct = (product: Product) => {
    setEditProduct(product);
  };

  const handleDeleteProduct = (product: Product) => {
    setDeleteProduct(product);
  };

  const handleAdjustStock = (product: Product) => {
    setAdjustStockProduct(product);
  };

  const handleBulkDelete = async () => {
    if (selectedItems.length === 0) return;
    
    try {
      const result = await bulkDelete(selectedItems);
      toast({
        title: "Bulk Delete Successful",
        description: `${result?.deleted || selectedItems.length} products deleted successfully.`,
      });
      setSelectedItems([]);
      refetch();
    } catch (error) {
      toast({
        title: "Bulk Delete Failed",
        description: "Some products could not be deleted. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleBulkCategoryUpdate = async (newCategory: string) => {
    if (selectedItems.length === 0) return;
    
    const updates = selectedItems.map(id => ({
      id,
      changes: { category: newCategory }
    }));
    
    try {
      const result = await bulkUpdate(updates);
      toast({
        title: "Bulk Update Successful",
        description: `${result?.updated || selectedItems.length} products updated successfully.`,
      });
      setSelectedItems([]);
      refetch();
    } catch (error) {
      toast({
        title: "Bulk Update Failed",
        description: "Some products could not be updated. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleRefresh = () => {
    refetch();
    toast({
      title: "Data Refreshed",
      description: "Inventory data has been updated.",
    });
  };

  const clearFilters = () => {
    setSearchTerm("");
    setCategoryFilter("");
    setStatusFilter("");
    setSelectedItems([]);
  };

  const handleAddItem = () => {
    navigate("/add-product");
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "in-stock":
        return "#22c55e";
      case "low-stock":
        return "#f59e0b";
      case "out-of-stock":
        return "#ef4444";
      default:
        return "#6b7280";
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      Clothes: "#ec4899",
      Electronics: "#3b82f6",
      Accessories: "#8b5cf6",
      Sports: "#f97316",
      Beauty: "#06b6d4",
      "Home Decor": "#10b981",
    };
    return colors[category] || "#6b7280";
  };

  return (
    <div data-zone="inventory" className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/70 backdrop-blur border-b border-border sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate("/")}
                className="flex items-center px-4 py-2 rounded-lg border border-border bg-card hover:bg-secondary transition-colors"
              >
                <i className="fas fa-arrow-left mr-2"></i>
                Back to Dashboard
              </button>
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-lg bg-primary text-primary-foreground">
                  <i className="fas fa-warehouse"></i>
                </div>
                <h1 className="text-2xl font-bold">Stock Management</h1>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"></i>
                <input
                  placeholder="Search items..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-80 bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                />
              </div>
              <button
                onClick={handleAddItem}
                className="flex items-center px-4 py-2 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors"
              >
                <i className="fas fa-plus mr-2"></i>
                Add Item
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-blue-100">Total Items</h3>
              <i className="fas fa-box text-white"></i>
            </div>
            <div className="text-3xl font-bold">{totalItems}</div>
            <div className="text-sm text-blue-100">Active stock</div>
          </div>

          <div className="bg-gradient-to-br from-orange-500 to-yellow-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-orange-100">Low Stock</h3>
              <i className="fas fa-exclamation-triangle text-white"></i>
            </div>
            <div className="text-3xl font-bold">{lowStockItems}</div>
            <div className="text-sm text-orange-100">Need restocking</div>
          </div>

          <div className="bg-gradient-to-br from-teal-500 to-cyan-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-teal-100">Total Value</h3>
              <i className="fas fa-rupee-sign text-white"></i>
            </div>
            <div className="text-3xl font-bold">₹{totalValue.toLocaleString()}</div>
            <div className="text-sm text-teal-100">Stock worth</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-violet-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-purple-100">Categories</h3>
              <i className="fas fa-tags text-white"></i>
            </div>
            <div className="text-3xl font-bold">{Array.from(new Set(stockItems.map((item) => item.category))).length}</div>
            <div className="text-sm text-purple-100">Product types</div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-col space-y-4 mb-6">
          {/* Top row - Selection and bulk actions */}
          {selectedItems.length > 0 && (
            <div className="flex items-center justify-between p-3 bg-primary/10 border border-primary/20 rounded-lg">
              <div className="flex items-center space-x-4">
                <span className="text-sm font-medium">
                  {selectedItems.length} item{selectedItems.length !== 1 ? 's' : ''} selected
                </span>
                <Button variant="outline" size="sm" onClick={() => setSelectedItems([])}>
                  Clear Selection
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      <i className="fas fa-edit mr-2"></i>
                      Bulk Actions
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={handleBulkDelete} className="text-destructive">
                      <i className="fas fa-trash mr-2"></i>
                      Delete Selected
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    {categories.map((category) => (
                      <DropdownMenuItem 
                        key={category} 
                        onClick={() => handleBulkCategoryUpdate(category)}
                      >
                        Set Category: {category}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          )}

          {/* Main controls row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center px-3 py-1 rounded-lg border border-border bg-card text-sm">
                <span className="text-muted-foreground">{filteredItems.length} items found</span>
              </div>
              
              {/* Enhanced Filter Button */}
              <DropdownMenu open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <i className="fas fa-filter mr-2"></i>
                    Filters
                    {(categoryFilter || statusFilter) && (
                      <span className="ml-1 w-2 h-2 bg-primary rounded-full"></span>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-64 p-4">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium">Category</Label>
                      <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="All categories" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All Categories</SelectItem>
                          {categories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium">Stock Status</Label>
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="All statuses" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All Statuses</SelectItem>
                          <SelectItem value="in-stock">In Stock</SelectItem>
                          <SelectItem value="low-stock">Low Stock</SelectItem>
                          <SelectItem value="out-of-stock">Out of Stock</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" onClick={clearFilters} className="flex-1">
                        Clear
                      </Button>
                      <Button size="sm" onClick={() => setIsFilterOpen(false)} className="flex-1">
                        Apply
                      </Button>
                    </div>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button variant="outline" size="sm" onClick={handleRefresh} disabled={loading}>
                <i className={`fas fa-sync-alt mr-2 ${loading ? 'animate-spin' : ''}`}></i>
                Refresh
              </Button>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg border transition-colors ${
                  viewMode === "grid"
                    ? "bg-primary border-primary text-primary-foreground"
                    : "bg-card border-border text-muted-foreground hover:bg-secondary"
                }`}
              >
                <i className="fas fa-th"></i>
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-lg border transition-colors ${
                  viewMode === "list"
                    ? "bg-primary border-primary text-primary-foreground"
                    : "bg-card border-border text-muted-foreground hover:bg-secondary"
                }`}
              >
                <i className="fas fa-list"></i>
              </button>
            </div>
          </div>
        </div>

        {/* Stock Items */}
        {viewMode === "grid" ? (
          <div className="space-y-4">
            {/* Select All for Grid View */}
            <div className="flex items-center space-x-2">
              <Checkbox 
                checked={selectedItems.length === filteredItems.length && filteredItems.length > 0}
                onCheckedChange={handleSelectAll}
              />
              <span className="text-sm text-muted-foreground">
                Select all ({filteredItems.length} items)
              </span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredItems.map((item) => (
                <div key={item.id} className={`bg-card border rounded-xl p-6 transition-all duration-200 ${
                  selectedItems.includes(item.id) 
                    ? 'border-primary ring-2 ring-primary/30 bg-primary/5' 
                    : 'border-border hover:border-primary'
                }`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        checked={selectedItems.includes(item.id)}
                        onCheckedChange={(checked) => handleSelectItem(item.id, !!checked)}
                      />
                      <div
                        className="px-2 py-1 rounded text-xs text-white font-medium"
                        style={{ backgroundColor: getCategoryColor(item.category) }}
                      >
                        {item.category}
                      </div>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <i className="fas fa-ellipsis-v text-sm"></i>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEditProduct(item)}>
                          <i className="fas fa-edit mr-2"></i>
                          Edit Product
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleAdjustStock(item)}>
                          <i className="fas fa-warehouse mr-2"></i>
                          Adjust Stock
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={() => handleDeleteProduct(item)}
                          className="text-destructive"
                        >
                          <i className="fas fa-trash mr-2"></i>
                          Delete Product
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <h3 className="text-lg font-semibold mb-1">{item.name}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{item.sku || item.id}</p>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Stock:</span>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{item.stock}</span>
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: getStatusColor(item.status) }}></div>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Price:</span>
                      <span className="font-bold text-lg">₹{item.price.toLocaleString()}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Location:</span>
                      <span className="text-sm font-medium">{item.location}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Supplier:</span>
                      <span className="text-sm">{item.supplier}</span>
                    </div>

                    <div className="pt-2 flex items-center justify-between">
                      <div
                        className="px-2 py-1 rounded text-xs text-white font-medium inline-block"
                        style={{ backgroundColor: getStatusColor(item.status) }}
                      >
                        {item.status === "low-stock" ? "Low Stock" : item.status === "out-of-stock" ? "Out of Stock" : "In Stock"}
                      </div>
                      
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleAdjustStock(item)}
                      >
                        <i className="fas fa-plus mr-1"></i>
                        Adjust
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-secondary border-b border-border">
                  <tr>
                    <th className="text-left p-4 font-medium text-muted-foreground w-12">
                      <Checkbox 
                        checked={selectedItems.length === filteredItems.length && filteredItems.length > 0}
                        onCheckedChange={handleSelectAll}
                      />
                    </th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Item</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Category</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">SKU</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Stock</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Price</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Location</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Supplier</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                    <th className="text-left p-4 font-medium text-muted-foreground w-32">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredItems.map((item) => (
                    <tr 
                      key={item.id} 
                      className={`border-b border-border transition-colors ${
                        selectedItems.includes(item.id) 
                          ? 'bg-primary/5 hover:bg-primary/10' 
                          : 'hover:bg-secondary'
                      }`}
                    >
                      <td className="p-4">
                        <Checkbox 
                          checked={selectedItems.includes(item.id)}
                          onCheckedChange={(checked) => handleSelectItem(item.id, !!checked)}
                        />
                      </td>
                      <td className="p-4">
                        <div>
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-muted-foreground">{item.id}</div>
                        </div>
                      </td>
                      <td className="p-4">
                        <div
                          className="px-2 py-1 rounded text-xs text-white font-medium inline-block"
                          style={{ backgroundColor: getCategoryColor(item.category) }}
                        >
                          {item.category}
                        </div>
                      </td>
                      <td className="p-4 text-sm font-mono">
                        {item.sku || '-'}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">{item.stock}</span>
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: getStatusColor(item.status) }}></div>
                          {item.minStock && item.stock <= item.minStock && (
                            <i className="fas fa-exclamation-triangle text-amber-500 text-xs" title="Below minimum stock"></i>
                          )}
                        </div>
                      </td>
                      <td className="p-4 font-medium">₹{item.price.toLocaleString()}</td>
                      <td className="p-4 text-sm">{item.location}</td>
                      <td className="p-4 text-sm">{item.supplier}</td>
                      <td className="p-4">
                        <div
                          className="px-2 py-1 rounded text-xs text-white font-medium inline-block"
                          style={{ backgroundColor: getStatusColor(item.status) }}
                        >
                          {item.status === "low-stock" ? "Low Stock" : item.status === "out-of-stock" ? "Out of Stock" : "In Stock"}
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center space-x-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditProduct(item)}
                            className="h-8 w-8 p-0"
                          >
                            <i className="fas fa-edit text-xs"></i>
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleAdjustStock(item)}
                            className="h-8 w-8 p-0"
                          >
                            <i className="fas fa-warehouse text-xs"></i>
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteProduct(item)}
                            className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                          >
                            <i className="fas fa-trash text-xs"></i>
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {/* Loading and Error States */}
        {loading && (
          <div className="space-y-6">
            {/* Loading skeletons for stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-card border border-border rounded-xl p-6 animate-pulse">
                  <div className="flex items-center justify-between mb-2">
                    <div className="h-4 bg-gray-300 rounded w-20"></div>
                    <div className="w-6 h-6 bg-gray-300 rounded"></div>
                  </div>
                  <div className="h-8 bg-gray-300 rounded w-16 mb-2"></div>
                  <div className="h-3 bg-gray-300 rounded w-24"></div>
                </div>
              ))}
            </div>
            
            {/* Loading skeletons for grid view */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className="bg-card border border-border rounded-xl p-6 animate-pulse">
                  <div className="flex items-center justify-between mb-3">
                    <div className="h-4 w-4 bg-gray-300 rounded"></div>
                    <div className="h-6 bg-gray-300 rounded w-16"></div>
                  </div>
                  <div className="h-6 bg-gray-300 rounded w-32 mb-1"></div>
                  <div className="h-4 bg-gray-300 rounded w-20 mb-3"></div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <div className="h-4 bg-gray-300 rounded w-12"></div>
                      <div className="h-4 bg-gray-300 rounded w-8"></div>
                    </div>
                    <div className="flex justify-between">
                      <div className="h-4 bg-gray-300 rounded w-10"></div>
                      <div className="h-4 bg-gray-300 rounded w-16"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {error && (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <i className="fas fa-exclamation-triangle text-destructive text-4xl mb-4"></i>
              <p className="text-destructive font-medium mb-2">Error loading inventory data</p>
              <p className="text-muted-foreground text-sm mb-4">{error}</p>
              <Button onClick={refetch} variant="outline">
                <i className="fas fa-retry mr-2"></i>
                Retry
              </Button>
            </div>
          </div>
        )}
        
        {!loading && !error && filteredItems.length === 0 && (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <i className="fas fa-box-open text-muted-foreground text-4xl mb-4"></i>
              <p className="text-foreground font-medium mb-2">No products found</p>
              <p className="text-muted-foreground text-sm mb-4">
                {searchTerm || categoryFilter || statusFilter 
                  ? "Try adjusting your filters or search term"
                  : "Add your first product to get started"
                }
              </p>
              {!searchTerm && !categoryFilter && !statusFilter && (
                <Button onClick={handleAddItem}>
                  <i className="fas fa-plus mr-2"></i>
                  Add Product
                </Button>
              )}
            </div>
          </div>
        )}
      </main>
      
      {/* Dialogs */}
      <EditProductDialog 
        product={editProduct}
        open={!!editProduct}
        onOpenChange={(open) => !open && setEditProduct(null)}
        onSuccess={() => {
          refetch();
          setEditProduct(null);
        }}
      />
      
      <DeleteConfirmationDialog 
        product={deleteProduct}
        open={!!deleteProduct}
        onOpenChange={(open) => !open && setDeleteProduct(null)}
        onSuccess={() => {
          refetch();
          setDeleteProduct(null);
          setSelectedItems(prev => prev.filter(id => id !== deleteProduct?.id));
        }}
      />
      
      <StockAdjustmentDialog 
        product={adjustStockProduct}
        open={!!adjustStockProduct}
        onOpenChange={(open) => !open && setAdjustStockProduct(null)}
        onSuccess={() => {
          refetch();
          setAdjustStockProduct(null);
        }}
      />
    </div>
  );
}
