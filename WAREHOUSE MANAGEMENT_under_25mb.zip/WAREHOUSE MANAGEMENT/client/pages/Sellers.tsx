import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Warehouse, 
  Search, 
  ArrowLeft, 
  Users, 
  Star, 
  Phone, 
  Mail,
  MapPin,
  Package,
  TrendingUp,
  Calendar,
  Filter,
  Plus,
  Eye,
  Edit,
  CheckCircle,
  AlertTriangle,
  Clock
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { useCustomers } from "@/hooks/useApi";

export default function Sellers() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Sellers mapped to Customers API
  // Treat customers as sellers (quick mapping)
  // Status is derived: lastOrderDate -> active, missing -> inactive; random few pending for variety
  // Category mapped from customer.type (business/individual)
  // totalValue, totalOrders from customers
  const { data: customers } = useCustomers();
  const sellersData = (customers || []).map((c, idx) => ({
    id: c.id,
    name: c.name,
    email: c.email,
    phone: c.phone,
    address: `${c.address.street}, ${c.address.city}, ${c.address.state}`,
    category: c.type === 'business' ? 'Business' : 'Individual',
    rating: 4 + ((idx % 10) / 10),
    status: c.lastOrderDate ? (idx % 11 === 0 ? 'pending' : 'active') : 'inactive',
    joinDate: c.registrationDate,
    totalOrders: c.totalOrders,
    totalValue: `₹${c.totalValue.toLocaleString()}`,
    categoryColor: c.type === 'business'
      ? 'bg-gradient-to-r from-blue-500 to-cyan-500'
      : 'bg-gradient-to-r from-teal-500 to-emerald-500',
    products: [],
    performance: {
      deliveryTime: 90,
      qualityScore: 90,
      reliability: 90,
    }
  }));

  const filteredSellers = sellersData.filter(seller => {
    const matchesSearch = seller.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         seller.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         seller.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || seller.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const sellerStats = {
    total: sellersData.length,
    active: sellersData.filter(s => s.status === "active").length,
    pending: sellersData.filter(s => s.status === "pending").length,
    inactive: sellersData.filter(s => s.status === "inactive").length,
    totalValue: sellersData.reduce((sum, seller) => sum + parseInt(seller.totalValue.replace('₹', '').replace(',', '')), 0),
    avgRating: (sellersData.reduce((sum, seller) => sum + seller.rating, 0) / sellersData.length).toFixed(1)
  };

  const handleSellerAction = (action: string, sellerId: string) => {
    toast({
      title: `${action} Seller`,
      description: `${action} action performed on ${sellerId}`,
    });
  };

  const handleAddSeller = () => {
    toast({
      title: "Add New Seller",
      description: "Opening seller registration form...",
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "pending":
        return <Clock className="h-4 w-4 text-orange-500" />;
      case "inactive":
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default:
        return <Users className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "active":
        return "bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0";
      case "pending":
        return "bg-gradient-to-r from-orange-500 to-yellow-500 text-white border-0";
      case "inactive":
        return "bg-gradient-to-r from-red-500 to-pink-500 text-white border-0";
      default:
        return "bg-muted-foreground text-background border-0";
    }
  };

  const renderStarRating = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < Math.floor(rating) 
            ? "text-yellow-500 fill-yellow-500" 
            : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/90 backdrop-blur-xl border-b border-border sticky top-0 z-50 shadow-lg shadow-slate-200/20">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => navigate('/')}
                className="hover:bg-slate-100"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
                  <Warehouse className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    Sellers
                  </h1>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <Input
                  placeholder="Search sellers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-80"
                />
              </div>
              <Button onClick={handleAddSeller} className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white">
                <Plus className="h-4 w-4 mr-2" />
                Add Seller
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-blue-100">Total Sellers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{sellerStats.total}</div>
              <div className="text-sm text-blue-100">Registered</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-emerald-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-green-100">Active</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{sellerStats.active}</div>
              <div className="text-sm text-green-100">Supplying</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-yellow-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-orange-100">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{sellerStats.pending}</div>
              <div className="text-sm text-orange-100">Verification</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-violet-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-purple-100">Avg Rating</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{sellerStats.avgRating}</div>
              <div className="text-sm text-purple-100">Out of 5.0</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-500 to-teal-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-cyan-100">Total Value</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">₹{sellerStats.totalValue.toLocaleString()}</div>
              <div className="text-sm text-cyan-100">Business</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <Badge variant="outline" className="text-slate-600">
              {filteredSellers.length} sellers found
            </Badge>
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-slate-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="text-sm border border-slate-200 rounded-md px-3 py-1"
              >
                <option value="all">All Categories</option>
                <option value="Clothes">Clothes</option>
                <option value="Electronics">Electronics</option>
                <option value="Accessories">Accessories</option>
                <option value="Sports">Sports</option>
                <option value="Beauty">Beauty</option>
                <option value="Home Decor">Home Decor</option>
              </select>
            </div>
          </div>
        </div>

        {/* Sellers Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredSellers.map((seller) => (
            <Card key={seller.id} className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between mb-2">
                  <Badge className={`text-xs ${seller.categoryColor} text-white border-0`}>
                    {seller.category}
                  </Badge>
                  <div className="flex items-center space-x-1">
                    {getStatusIcon(seller.status)}
                    <Badge className={`text-xs ${getStatusBadgeClass(seller.status)}`}>
                      {seller.status}
                    </Badge>
                  </div>
                </div>
                <CardTitle className="text-xl">{seller.name}</CardTitle>
                <CardDescription className="text-sm text-slate-500">{seller.id}</CardDescription>
                <div className="flex items-center space-x-1 mt-2">
                  {renderStarRating(seller.rating)}
                  <span className="text-sm font-medium ml-2">{seller.rating}</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-slate-600">Orders</div>
                      <div className="font-semibold">{seller.totalOrders}</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Value</div>
                      <div className="font-semibold">{seller.totalValue}</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm text-slate-600">Performance</div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Delivery Time</span>
                        <span>{seller.performance.deliveryTime}%</span>
                      </div>
                      <Progress value={seller.performance.deliveryTime} className="h-1" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Quality Score</span>
                        <span>{seller.performance.qualityScore}%</span>
                      </div>
                      <Progress value={seller.performance.qualityScore} className="h-1" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center space-x-2 text-xs text-slate-500">
                      <Calendar className="h-3 w-3" />
                      <span>Since {seller.joinDate}</span>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Seller Details - {seller.name}</DialogTitle>
                            <DialogDescription>
                              Complete information about this seller
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-6 py-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <h4 className="font-medium text-slate-700 mb-2">Contact Information</h4>
                                <div className="space-y-2 text-sm">
                                  <div className="flex items-center space-x-2">
                                    <Mail className="h-4 w-4 text-slate-400" />
                                    <span>{seller.email}</span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <Phone className="h-4 w-4 text-slate-400" />
                                    <span>{seller.phone}</span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <MapPin className="h-4 w-4 text-slate-400" />
                                    <span>{seller.address}</span>
                                  </div>
                                </div>
                              </div>
                              <div>
                                <h4 className="font-medium text-slate-700 mb-2">Business Metrics</h4>
                                <div className="space-y-1 text-sm">
                                  <p><strong>Total Orders:</strong> {seller.totalOrders}</p>
                                  <p><strong>Total Value:</strong> {seller.totalValue}</p>
                                  <p><strong>Rating:</strong> {seller.rating}/5.0</p>
                                  <p><strong>Status:</strong> 
                                    <Badge className={`ml-2 text-xs ${getStatusBadgeClass(seller.status)}`}>
                                      {seller.status}
                                    </Badge>
                                  </p>
                                </div>
                              </div>
                            </div>
                            <div>
                              <h4 className="font-medium text-slate-700 mb-2">Products Supplied</h4>
                              <div className="space-y-2">
                                {seller.products.map((product, index) => (
                                  <div key={index} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                                    <div>
                                      <p className="font-medium">{product.name}</p>
                                      <p className="text-sm text-slate-600">Stock: {product.stock}</p>
                                    </div>
                                    <p className="font-medium">{product.price}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                      
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleSellerAction("Edit", seller.id)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}
