import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { BarcodeScanner } from "@/components/BarcodeScanner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Warehouse,
  ArrowLeft,
  Package,
  Upload,
  Save,
  Camera,
  Plus,
  X,
  Check,
  Barcode
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { useCreateProduct } from "@/hooks/useApi";

export default function AddProduct() {
  const navigate = useNavigate();
  const { createProduct, loading, error } = useCreateProduct();
  const [formData, setFormData] = useState({
    name: "Wireless Bluetooth Headphones",
    description: "High-quality wireless headphones with noise cancellation",
    category: "Electronics",
    sku: "",
    price: "129.99",
    costPrice: "79.99",
    quantity: "50",
    minStock: "5",
    maxStock: "100",
    weight: "0.25",
    dimensions: "18 x 16 x 8 cm",
    supplier: "TechWorld Suppliers",
    location: "Zone A-1",
    barcode: "",
    tags: ["wireless", "audio", "electronics"] as string[],
  });

  const [newTag, setNewTag] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [showScanner, setShowScanner] = useState(false);

  const handleBarcodeScan = (barcode: string) => {
    setFormData(prev => ({
      ...prev,
      barcode: barcode
    }));
    setShowScanner(false);
    toast({
      title: "Barcode Scanned",
      description: `Barcode ${barcode} has been scanned and added.`,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const quantity = parseInt(formData.quantity) || 0;
      const minStock = parseInt(formData.minStock) || 0;
      
      const getProductStatus = (qty: number, min: number): 'in-stock' | 'low-stock' | 'out-of-stock' => {
        if (qty > min) return 'in-stock';
        if (qty > 0) return 'low-stock';
        return 'out-of-stock';
      };

      const productData = {
        ...formData,
        price: parseFloat(formData.price) || 0,
        costPrice: parseFloat(formData.costPrice) || 0,
        quantity,
        minStock,
        maxStock: parseInt(formData.maxStock) || 0,
        weight: parseFloat(formData.weight) || 0,
        images,
        stock: quantity,
        status: getProductStatus(quantity, minStock),
      };

      await createProduct(productData);
      
      toast({
        title: "Success",
        description: "Product added successfully!",
        variant: "default",
      });
      
      // Navigate back to products page after successful submission
      navigate('/products');
    } catch (error) {
      console.error('Error creating product:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add product",
        variant: "destructive",
      });
    }
  };

  const categories = [
    "Clothes",
    "Electronics",
    "Accessories",
    "Home Decor",
    "Sports",
    "Beauty",
    "Books",
    "Hardware",
    "Safety",
    "Other"
  ];

  const suppliers = [
    "Fashion Fabrics Ltd",
    "TechWorld Suppliers",
    "Luxury Leather Co",
    "FitLife Equipment",
    "Beauty Essentials",
    "Home Craft Studios",
    "Global Electronics Inc",
    "Premium Fabrics Co"
  ];

  const locations = [
    "Zone A-1",
    "Zone A-2",
    "Zone A-3",
    "Zone B-1",
    "Zone B-2",
    "Zone B-3",
    "Zone C-1",
    "Zone C-2",
    "Zone D-1",
    "Zone D-2"
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag("");
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleImageUpload = () => {
    // Simulate image upload
    const newImageUrl = `https://images.unsplash.com/photo-${Date.now()}?w=300&h=300&fit=crop`;
    setImages(prev => [...prev, newImageUrl]);
    toast({
      title: "Image Uploaded",
      description: "Product image has been uploaded successfully.",
    });
  };

  const handleSaveProduct = async () => {
    if (!formData.name || !formData.category || !formData.price || !formData.quantity || !formData.supplier || !formData.location) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields (Name, Category, Price, Quantity, Supplier, Location).",
        variant: "destructive"
      });
      return;
    }

    try {
      // Convert string values to numbers where needed
      const productData = {
        ...formData,
        price: parseFloat(formData.price) || 0,
        costPrice: parseFloat(formData.costPrice) || 0,
        quantity: parseInt(formData.quantity) || 0,
        minStock: parseInt(formData.minStock) || 0,
        maxStock: parseInt(formData.maxStock) || 0,
        weight: formData.weight ? parseFloat(formData.weight) : 0,
      };

      await createProduct(productData);
      
      toast({
        title: "Success!",
        description: "Product added successfully.",
        variant: "default",
      });
      
      // Reset form
      setFormData({
        name: "",
        description: "",
        category: "",
        sku: "",
        price: "",
        costPrice: "",
        quantity: "",
        minStock: "",
        maxStock: "",
        weight: "",
        dimensions: "",
        supplier: "",
        location: "",
        barcode: "",
        tags: [],
      });
      setImages([]);
    } catch (err) {
      console.error("Error adding product:", err);
      toast({
        title: "Error",
        description: error || "Failed to add product. Please try again.",
        variant: "destructive",
      });
    }
  };

  const generateSKU = () => {
    const category = formData.category.substring(0, 3).toUpperCase();
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    const sku = `${category}-${random}`;
    handleInputChange('sku', sku);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/70 backdrop-blur border-b border-border sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => navigate('/')}
                className="hover:bg-slate-100"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-gradient-to-br from-emerald-500 to-green-600 rounded-lg">
                  <Package className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  Add New Product
                </h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowScanner(true)}
                className="flex items-center gap-2"
              >
                <Barcode className="h-4 w-4" />
                Scan Barcode
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  setFormData({
                    name: "",
                    description: "",
                    category: "",
                    sku: "",
                    price: "",
                    costPrice: "",
                    quantity: "",
                    minStock: "",
                    maxStock: "",
                    weight: "",
                    dimensions: "",
                    supplier: "",
                    location: "",
                    barcode: "",
                    tags: [],
                  });
                  setImages([]);
                }}
              >
                Clear Form
              </Button>
              <Button 
                onClick={handleSubmit}
                disabled={loading}
                className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white"
              >
                <Save className="h-4 w-4 mr-2" />
                {loading ? "Saving..." : "Save Product"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Barcode Scanner Modal */}
      {showScanner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="w-full max-w-md rounded-lg bg-card p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold">Scan Barcode</h2>
              <button
                onClick={() => setShowScanner(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <BarcodeScanner
              onScan={handleBarcodeScan}
              onClose={() => setShowScanner(false)}
            />
          </div>
        </div>
      )}

      <main className="px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>
                    Enter the basic details of the product
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Product Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Enter product name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="category">Category *</Label>
                      <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      placeholder="Enter product description"
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="sku">SKU</Label>
                      <div className="flex space-x-2">
                        <Input
                          id="sku"
                          value={formData.sku}
                          onChange={(e) => handleInputChange('sku', e.target.value)}
                          placeholder="Product SKU"
                        />
                        <Button type="button" onClick={generateSKU} variant="outline">
                          Generate
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="barcode">Barcode</Label>
                      <div className="flex gap-2">
                        <Input
                          id="barcode"
                          placeholder="Enter barcode"
                          value={formData.barcode}
                          onChange={(e) => handleInputChange("barcode", e.target.value)}
                          className="flex-1"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => setShowScanner(true)}
                          title="Scan Barcode"
                        >
                          <Barcode className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Pricing & Inventory */}
              <Card>
                <CardHeader>
                  <CardTitle>Pricing & Inventory</CardTitle>
                  <CardDescription>
                    Set pricing and stock information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="price">Selling Price *</Label>
                      <Input
                        id="price"
                        type="number"
                        value={formData.price}
                        onChange={(e) => handleInputChange('price', e.target.value)}
                        placeholder="0.00"
                      />
                    </div>
                    <div>
                      <Label htmlFor="costPrice">Cost Price</Label>
                      <Input
                        id="costPrice"
                        type="number"
                        value={formData.costPrice}
                        onChange={(e) => handleInputChange('costPrice', e.target.value)}
                        placeholder="0.00"
                      />
                    </div>
                    <div>
                      <Label htmlFor="quantity">Initial Quantity *</Label>
                      <Input
                        id="quantity"
                        type="number"
                        value={formData.quantity}
                        onChange={(e) => handleInputChange('quantity', e.target.value)}
                        placeholder="0"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="minStock">Minimum Stock</Label>
                      <Input
                        id="minStock"
                        type="number"
                        value={formData.minStock}
                        onChange={(e) => handleInputChange('minStock', e.target.value)}
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <Label htmlFor="maxStock">Maximum Stock</Label>
                      <Input
                        id="maxStock"
                        type="number"
                        value={formData.maxStock}
                        onChange={(e) => handleInputChange('maxStock', e.target.value)}
                        placeholder="0"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Physical Details */}
              <Card>
                <CardHeader>
                  <CardTitle>Physical Details</CardTitle>
                  <CardDescription>
                    Product dimensions and physical attributes
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="weight">Weight (kg)</Label>
                      <Input
                        id="weight"
                        value={formData.weight}
                        onChange={(e) => handleInputChange('weight', e.target.value)}
                        placeholder="0.0"
                      />
                    </div>
                    <div>
                      <Label htmlFor="dimensions">Dimensions (L x W x H)</Label>
                      <Input
                        id="dimensions"
                        value={formData.dimensions}
                        onChange={(e) => handleInputChange('dimensions', e.target.value)}
                        placeholder="0 x 0 x 0 cm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="supplier">Supplier</Label>
                      <Select value={formData.supplier} onValueChange={(value) => handleInputChange('supplier', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select supplier" />
                        </SelectTrigger>
                        <SelectContent>
                          {suppliers.map((supplier) => (
                            <SelectItem key={supplier} value={supplier}>
                              {supplier}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="location">Storage Location</Label>
                      <Select value={formData.location} onValueChange={(value) => handleInputChange('location', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select location" />
                        </SelectTrigger>
                        <SelectContent>
                          {locations.map((location) => (
                            <SelectItem key={location} value={location}>
                              {location}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Product Images */}
              <Card>
                <CardHeader>
                  <CardTitle>Product Images</CardTitle>
                  <CardDescription>
                    Upload product photos
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Button
                      onClick={handleImageUpload}
                      variant="outline"
                      className="w-full h-32 border-2 border-dashed border-slate-300 hover:border-slate-400"
                    >
                      <div className="text-center">
                        <Camera className="h-8 w-8 mx-auto mb-2 text-slate-400" />
                        <p className="text-sm text-slate-600">Click to upload image</p>
                      </div>
                    </Button>
                    
                    {images.length > 0 && (
                      <div className="grid grid-cols-2 gap-2">
                        {images.map((image, index) => (
                          <div key={index} className="relative group">
                            <img
                              src={image}
                              alt={`Product ${index + 1}`}
                              className="w-full h-20 object-cover rounded border"
                            />
                            <Button
                              size="sm"
                              variant="destructive"
                              className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => setImages(prev => prev.filter((_, i) => i !== index))}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Tags */}
              <Card>
                <CardHeader>
                  <CardTitle>Tags</CardTitle>
                  <CardDescription>
                    Add tags for better organization
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex space-x-2">
                      <Input
                        value={newTag}
                        onChange={(e) => setNewTag(e.target.value)}
                        placeholder="Add a tag"
                        onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                      />
                      <Button size="sm" onClick={handleAddTag}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    {formData.tags.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {formData.tags.map((tag, index) => (
                          <Badge
                            key={index}
                            variant="secondary"
                            className="cursor-pointer hover:bg-red-100"
                            onClick={() => handleRemoveTag(tag)}
                          >
                            {tag}
                            <X className="h-3 w-3 ml-1" />
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Form Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Form Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      {formData.name ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-red-500" />}
                      <span className={`text-sm ${formData.name ? 'text-green-700' : 'text-red-700'}`}>
                        Product Name
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      {formData.category ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-red-500" />}
                      <span className={`text-sm ${formData.category ? 'text-green-700' : 'text-red-700'}`}>
                        Category
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      {formData.price ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-red-500" />}
                      <span className={`text-sm ${formData.price ? 'text-green-700' : 'text-red-700'}`}>
                        Price
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      {formData.quantity ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-red-500" />}
                      <span className={`text-sm ${formData.quantity ? 'text-green-700' : 'text-red-700'}`}>
                        Quantity
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
