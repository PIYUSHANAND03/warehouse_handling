import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  Users,
  Search,
  ArrowLeft,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  DollarSign,
  Filter,
  Plus,
  Eye,
  Edit,
  Trash2,
  CheckCircle,
  AlertTriangle,
  Clock,
  Building,
  Star
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Worker } from "@shared/api";

export default function Workers() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [selectedRole, setSelectedRole] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  // Add worker dialog & view worker dialog state
  const [addOpen, setAddOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [selectedWorker, setSelectedWorker] = useState<Worker | null>(null);
  const [newWorker, setNewWorker] = useState<Omit<Worker, 'id'>>({
    name: "",
    email: "",
    phone: "",
    role: "worker",
    department: "receiving",
    status: "active",
    hireDate: new Date().toISOString(),
    shift: "morning",
    hourlyRate: 0,
    address: { street: "", city: "", state: "", pincode: "", country: "" },
    emergencyContact: undefined,
    skills: [],
    performanceRating: 0,
    lastActive: new Date().toISOString(),
  });

  // Minimal client-side validation for required fields
  const isNewWorkerValid = (() => {
    const w = newWorker;
    const requiredFilled =
      w.name.trim() &&
      w.email.trim() &&
      w.phone.trim() &&
      w.address.street.trim() &&
      w.address.city.trim() &&
      w.address.state.trim() &&
      w.address.pincode.trim() &&
      w.address.country.trim();
    const rateValid = typeof w.hourlyRate === 'number' && w.hourlyRate >= 0;
    return Boolean(requiredFilled && rateValid);
  })();

  // Load workers from backend with filters
  const queryClient = useQueryClient();
  const { data: workers = [], isLoading } = useQuery({
    queryKey: ['workers', selectedDepartment, selectedRole, selectedStatus, searchTerm],
    queryFn: async () => {
      const res = await (await import("@/lib/api")).api.workers.getAll({
        department: selectedDepartment === 'all' ? undefined as any : (selectedDepartment as any),
        role: selectedRole === 'all' ? undefined as any : (selectedRole as any),
        status: selectedStatus === 'all' ? undefined as any : (selectedStatus as any),
        search: searchTerm || undefined
      });
      if (res.success && res.data) return res.data as Worker[];
      return [] as Worker[];
    }
  });

  // Inline status update
  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: 'active' | 'inactive' | 'on-leave' }) => {
      const { api } = await import("@/lib/api");
      const res = await api.workers.updateStatus(id, status);
      if (!res.success) throw new Error(res.error || 'Failed to update status');
      return res.data as Worker;
    },
    onSuccess: () => {
      toast({ title: 'Status updated', description: 'Worker status changed successfully.' });
      queryClient.invalidateQueries({ queryKey: ['workers'] });
    },
    onError: (err: any) => toast({ title: 'Update failed', description: String(err?.message || err) })
  });

  const filteredWorkers = workers.filter(worker => {
    const matchesSearch = worker.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         worker.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         worker.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = selectedDepartment === "all" || worker.department === selectedDepartment;
    const matchesRole = selectedRole === "all" || worker.role === selectedRole;
    const matchesStatus = selectedStatus === "all" || worker.status === selectedStatus;
    return matchesSearch && matchesDepartment && matchesRole && matchesStatus;
  });

  const workerStats = {
    total: workers.length,
    active: workers.filter(w => w.status === "active").length,
    onLeave: workers.filter(w => w.status === "on-leave").length,
    inactive: workers.filter(w => w.status === "inactive").length,
    avgRating: workers.length > 0 ? (workers.reduce((sum, w) => sum + (w.performanceRating || 0), 0) / workers.length).toFixed(1) : "0",
    totalHourlyCost: workers.reduce((sum, w) => sum + w.hourlyRate, 0)
  };

  const handleWorkerAction = (action: string, workerId: string) => {
    const worker = workers.find(w => w.id === workerId) || null;
    setSelectedWorker(worker);
    if (action === 'View') setViewOpen(true);
    if (action === 'Edit') setAddOpen(true);
    toast({ title: `${action} Worker`, description: `${action} action performed on ${workerId}` });
  };

  const handleAddWorker = () => {
    setAddOpen(true);
  };

  const createWorkerMutation = useMutation({
    mutationFn: async (payload: Omit<Worker, 'id'>) => {
      const { api } = await import("@/lib/api");
      const res = await api.workers.create(payload);
      if (!res.success || !res.data) throw new Error(res.error || 'Failed to create worker');
      return res.data as Worker;
    },
    onSuccess: () => {
      toast({ title: 'Worker created', description: 'New worker added successfully.' });
      queryClient.invalidateQueries({ queryKey: ['workers'] });
      setAddOpen(false);
    },
    onError: (err: any) => toast({ title: 'Create failed', description: String(err?.message || err) })
  });

  const updateWorkerMutation = useMutation({
    mutationFn: async ({ id, changes }: { id: string; changes: Partial<Worker>; }) => {
      const { api } = await import("@/lib/api");
      const res = await api.workers.update(id, changes);
      if (!res.success || !res.data) throw new Error(res.error || 'Failed to update worker');
      return res.data as Worker;
    },
    onSuccess: () => {
      toast({ title: 'Worker updated', description: 'Worker details saved.' });
      queryClient.invalidateQueries({ queryKey: ['workers'] });
      setAddOpen(false);
    },
    onError: (err: any) => toast({ title: 'Update failed', description: String(err?.message || err) })
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "on-leave":
        return <Clock className="h-4 w-4 text-orange-500" />;
      case "inactive":
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default:
        return <User className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "active":
        return "bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0";
      case "on-leave":
        return "bg-gradient-to-r from-orange-500 to-yellow-500 text-white border-0";
      case "inactive":
        return "bg-gradient-to-r from-red-500 to-pink-500 text-white border-0";
      default:
        return "bg-muted-foreground text-background border-0";
    }
  };

  const getRoleDisplayName = (role: string) => {
    return role.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  const getDepartmentDisplayName = (department: string) => {
    return department.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  const renderStarRating = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < Math.floor(rating)
            ? "text-yellow-500 fill-yellow-500"
            : "text-gray-300"
        }`}
      />
    ));
  };

  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>;
  }

  return (
    <div data-zone="workers" className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/90 backdrop-blur-xl border-b border-border sticky top-0 z-50 shadow-lg shadow-slate-200/20">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => navigate('/')}
                className="hover:bg-slate-100"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    Workers Management
                  </h1>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <Input
                  placeholder="Search workers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-80"
                />
              </div>
              <Dialog open={addOpen} onOpenChange={setAddOpen}>
                <DialogTrigger asChild>
                  <Button onClick={handleAddWorker} className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Worker
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>{selectedWorker ? 'Edit Worker' : 'Add Worker'}</DialogTitle>
                    <DialogDescription>
                      {selectedWorker ? 'Update worker details' : 'Fill in details to add a new worker'}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm">Name</label>
                      <Input
                        value={selectedWorker ? selectedWorker.name : newWorker.name}
                        onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker, name: e.target.value }) : setNewWorker({ ...newWorker, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="text-sm">Email</label>
                      <Input
                        value={selectedWorker ? selectedWorker.email : newWorker.email}
                        onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker, email: e.target.value }) : setNewWorker({ ...newWorker, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="text-sm">Phone</label>
                      <Input
                        value={selectedWorker ? selectedWorker.phone : newWorker.phone}
                        onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker, phone: e.target.value }) : setNewWorker({ ...newWorker, phone: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="text-sm">Role</label>
                      <Select
                        value={(selectedWorker ? selectedWorker.role : newWorker.role) as any}
                        onValueChange={(v) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, role: v as any }) : setNewWorker({ ...newWorker, role: v as any })}
                      >
                        <SelectTrigger><SelectValue placeholder="Role" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="manager">Manager</SelectItem>
                          <SelectItem value="supervisor">Supervisor</SelectItem>
                          <SelectItem value="worker">Worker</SelectItem>
                          <SelectItem value="picker">Picker</SelectItem>
                          <SelectItem value="packer">Packer</SelectItem>
                          <SelectItem value="loader">Loader</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm">Department</label>
                      <Select
                        value={(selectedWorker ? selectedWorker.department : newWorker.department) as any}
                        onValueChange={(v) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, department: v as any }) : setNewWorker({ ...newWorker, department: v as any })}
                      >
                        <SelectTrigger><SelectValue placeholder="Department" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="receiving">Receiving</SelectItem>
                          <SelectItem value="picking">Picking</SelectItem>
                          <SelectItem value="packing">Packing</SelectItem>
                          <SelectItem value="shipping">Shipping</SelectItem>
                          <SelectItem value="inventory">Inventory</SelectItem>
                          <SelectItem value="administration">Administration</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm">Status</label>
                      <Select
                        value={(selectedWorker ? selectedWorker.status : newWorker.status) as any}
                        onValueChange={(v) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, status: v as any }) : setNewWorker({ ...newWorker, status: v as any })}
                      >
                        <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="on-leave">On Leave</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm">Shift</label>
                      <Select
                        value={(selectedWorker ? selectedWorker.shift : newWorker.shift) as any}
                        onValueChange={(v) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, shift: v as any }) : setNewWorker({ ...newWorker, shift: v as any })}
                      >
                        <SelectTrigger><SelectValue placeholder="Shift" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="morning">Morning</SelectItem>
                          <SelectItem value="afternoon">Afternoon</SelectItem>
                          <SelectItem value="night">Night</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm">Hourly Rate</label>
                      <Input
                        type="number"
                        value={selectedWorker ? selectedWorker.hourlyRate : newWorker.hourlyRate}
                        onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, hourlyRate: Number(e.target.value) }) : setNewWorker({ ...newWorker, hourlyRate: Number(e.target.value) })}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="text-sm">Address</label>
                      <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                        <Input placeholder="Street" value={selectedWorker ? selectedWorker.address.street : newWorker.address.street} onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, address: { ...selectedWorker.address, street: e.target.value } }) : setNewWorker({ ...newWorker, address: { ...newWorker.address, street: e.target.value } })} />
                        <Input placeholder="City" value={selectedWorker ? selectedWorker.address.city : newWorker.address.city} onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, address: { ...selectedWorker.address, city: e.target.value } }) : setNewWorker({ ...newWorker, address: { ...newWorker.address, city: e.target.value } })} />
                        <Input placeholder="State" value={selectedWorker ? selectedWorker.address.state : newWorker.address.state} onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, address: { ...selectedWorker.address, state: e.target.value } }) : setNewWorker({ ...newWorker, address: { ...newWorker.address, state: e.target.value } })} />
                        <Input placeholder="Pincode" value={selectedWorker ? selectedWorker.address.pincode : newWorker.address.pincode} onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, address: { ...selectedWorker.address, pincode: e.target.value } }) : setNewWorker({ ...newWorker, address: { ...newWorker.address, pincode: e.target.value } })} />
                        <Input placeholder="Country" value={selectedWorker ? selectedWorker.address.country : newWorker.address.country} onChange={(e) => selectedWorker ? setSelectedWorker({ ...selectedWorker!, address: { ...selectedWorker.address, country: e.target.value } }) : setNewWorker({ ...newWorker, address: { ...newWorker.address, country: e.target.value } })} />
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    {selectedWorker ? (
                      <Button onClick={() => updateWorkerMutation.mutate({ id: selectedWorker.id, changes: selectedWorker })}>
                        Save Changes
                      </Button>
                    ) : (
                      <Button disabled={!isNewWorkerValid} onClick={() => createWorkerMutation.mutate(newWorker)}>
                        Create Worker
                      </Button>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-blue-100">Total Workers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{workerStats.total}</div>
              <div className="text-sm text-blue-100">Employed</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-emerald-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-green-100">Active</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{workerStats.active}</div>
              <div className="text-sm text-green-100">Working</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-yellow-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-orange-100">On Leave</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{workerStats.onLeave}</div>
              <div className="text-sm text-orange-100">Absent</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-violet-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-purple-100">Avg Rating</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <div className="text-3xl font-bold">{workerStats.avgRating}</div>
                <div className="flex">{renderStarRating(parseFloat(workerStats.avgRating))}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-teal-500 to-cyan-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-teal-100">Total Cost</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">₹{workerStats.totalHourlyCost}</div>
              <div className="text-sm text-teal-100">Hourly Rate</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-pink-500 to-rose-500 text-white border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-pink-100">Inactive</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{workerStats.inactive}</div>
              <div className="text-sm text-pink-100">Not Working</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Filter className="h-5 w-5 mr-2" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm font-medium mb-2 block">Department</label>
                <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Departments" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    <SelectItem value="receiving">Receiving</SelectItem>
                    <SelectItem value="picking">Picking</SelectItem>
                    <SelectItem value="packing">Packing</SelectItem>
                    <SelectItem value="shipping">Shipping</SelectItem>
                    <SelectItem value="inventory">Inventory</SelectItem>
                    <SelectItem value="administration">Administration</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm font-medium mb-2 block">Role</label>
                <Select value={selectedRole} onValueChange={setSelectedRole}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Roles" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="supervisor">Supervisor</SelectItem>
                    <SelectItem value="worker">Worker</SelectItem>
                    <SelectItem value="picker">Picker</SelectItem>
                    <SelectItem value="packer">Packer</SelectItem>
                    <SelectItem value="loader">Loader</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm font-medium mb-2 block">Status</label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="on-leave">On Leave</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Workers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredWorkers.map((worker) => (
            <Card key={worker.id} className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full">
                      <User className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{worker.name}</CardTitle>
                      <CardDescription className="font-mono text-xs">{worker.id}</CardDescription>
                    </div>
                  </div>
                  <Badge className={getStatusBadgeClass(worker.status)}>
                    <span className="flex items-center space-x-1">
                      {getStatusIcon(worker.status)}
                      <span className="capitalize">{worker.status.replace('_', ' ')}</span>
                    </span>
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Building className="h-4 w-4 text-slate-500" />
                    <span className="text-slate-600">{getDepartmentDisplayName(worker.department)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-slate-500" />
                    <span className="text-slate-600">{getRoleDisplayName(worker.role)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-slate-500" />
                    <span className="text-slate-600">{new Date(worker.hireDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-4 w-4 text-slate-500" />
                    <span className="text-slate-600">₹{worker.hourlyRate}/hr</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1">
                    {renderStarRating(worker.performanceRating || 0)}
                    <span className="text-sm text-slate-600 ml-1">
                      {worker.performanceRating?.toFixed(1) || 'N/A'}
                    </span>
                  </div>
                  <Badge variant="outline" className="capitalize">
                    {worker.shift}
                  </Badge>
                </div>

                <div className="flex items-center space-x-2 text-sm text-slate-600">
                  <Phone className="h-4 w-4" />
                  <span>{worker.phone}</span>
                </div>

                <div className="flex items-center space-x-2 text-sm text-slate-600">
                  <Mail className="h-4 w-4" />
                  <span className="truncate">{worker.email}</span>
                </div>

                <div className="flex items-center space-x-2 text-sm text-slate-600">
                  <MapPin className="h-4 w-4" />
                  <span className="truncate">{worker.address.city}, {worker.address.state}</span>
                </div>

                {worker.emergencyContact && (
                  <div className="pt-2 border-t">
                    <div className="text-xs text-slate-500 mb-1">Emergency Contact</div>
                    <div className="flex items-center space-x-2 text-sm">
                      <Phone className="h-3 w-3" />
                      <span>{worker.emergencyContact.name} ({worker.emergencyContact.relationship})</span>
                    </div>
                  </div>
                )}

                <div className="flex space-x-2 pt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => { setSelectedWorker(worker); setViewOpen(true); }}
                    className="flex-1"
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    View
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => statusMutation.mutate({ id: worker.id, status: worker.status === 'active' ? 'on-leave' : 'active' })}
                    className="flex-1"
                  >
                    <CheckCircle className="h-4 w-4 mr-1" />
                    {worker.status === 'active' ? 'Mark On Leave' : 'Mark Active'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredWorkers.length === 0 && (
          <Card className="p-8 text-center">
            <Users className="h-12 w-12 mx-auto text-slate-400 mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No workers found</h3>
            <p className="text-slate-500">Try adjusting your search or filter criteria.</p>
          </Card>
        )}

        {/* View Worker Dialog */}
        <Dialog open={viewOpen} onOpenChange={setViewOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Worker Details</DialogTitle>
            </DialogHeader>
            {selectedWorker && (
              <div className="space-y-2 text-sm">
                <div className="font-semibold text-base">{selectedWorker.name}</div>
                <div className="flex items-center gap-2"><Mail className="h-4 w-4" /> {selectedWorker.email}</div>
                <div className="flex items-center gap-2"><Phone className="h-4 w-4" /> {selectedWorker.phone}</div>
                <div className="flex items-center gap-2"><Building className="h-4 w-4" /> {getDepartmentDisplayName(selectedWorker.department)} • {getRoleDisplayName(selectedWorker.role)}</div>
                <div className="flex items-center gap-2"><Calendar className="h-4 w-4" /> Hired: {new Date(selectedWorker.hireDate).toLocaleDateString()}</div>
                <div className="flex items-center gap-2"><DollarSign className="h-4 w-4" /> Rate: ₹{selectedWorker.hourlyRate}/hr</div>
                <div className="flex items-center gap-2"><MapPin className="h-4 w-4" /> {selectedWorker.address.city}, {selectedWorker.address.state}</div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}