import { useState, useEffect } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Warehouse,
  ArrowLeft,
  BarChart3,
  Download,
  Eye,
  Calendar as CalendarIcon,
  FileText,
  TrendingUp,
  Package,
  ShoppingCart,
  Users,
  Truck,
  DollarSign,
  Clock,
  CheckCircle,
  Filter,
  Printer,
  Settings,
  Save,
  RefreshCw,
  Zap,
  Target,
  AlertCircle,
  Star,
  History
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function GenerateReport() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("quick");
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  const [reportType, setReportType] = useState("");
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>([]);
  const [reportFormat, setReportFormat] = useState("pdf");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [savedReports, setSavedReports] = useState<any[]>([]);
  const [recentReports, setRecentReports] = useState<any[]>([]);
  const [scheduledReports, setScheduledReports] = useState<any[]>([]);
  const [reportName, setReportName] = useState("");
  const [autoSchedule, setAutoSchedule] = useState(false);
  const [scheduleFrequency, setScheduleFrequency] = useState("weekly");

  const reportTypes = [
    { 
      id: "inventory", 
      name: "Inventory Report", 
      description: "Stock levels, product details, and inventory valuation",
      icon: Package,
      category: "essential",
      popularity: "high",
      estimatedTime: "2-3 min"
    },
    { 
      id: "sales", 
      name: "Sales Report", 
      description: "Revenue, order statistics, and sales performance",
      icon: TrendingUp,
      category: "essential",
      popularity: "high",
      estimatedTime: "1-2 min"
    },
    { 
      id: "orders", 
      name: "Orders Report", 
      description: "Order processing, delivery status, and customer details",
      icon: ShoppingCart,
      category: "essential",
      popularity: "medium",
      estimatedTime: "2-3 min"
    },
    { 
      id: "suppliers", 
      name: "Suppliers Report", 
      description: "Supplier performance, delivery times, and costs",
      icon: Users,
      category: "advanced",
      popularity: "medium",
      estimatedTime: "3-4 min"
    },
    { 
      id: "warehouse", 
      name: "Warehouse Report", 
      description: "Space utilization, zone efficiency, and operations",
      icon: Warehouse,
      category: "advanced",
      popularity: "low",
      estimatedTime: "2-3 min"
    },
    { 
      id: "financial", 
      name: "Financial Report", 
      description: "Profit margins, costs, and financial overview",
      icon: DollarSign,
      category: "advanced",
      popularity: "high",
      estimatedTime: "4-5 min"
    },
    { 
      id: "performance", 
      name: "Performance Report", 
      description: "KPIs, efficiency metrics, and analytics",
      icon: Target,
      category: "advanced",
      popularity: "medium",
      estimatedTime: "3-4 min"
    },
    { 
      id: "custom", 
      name: "Custom Report", 
      description: "Create a custom report with selected metrics",
      icon: Settings,
      category: "custom",
      popularity: "low",
      estimatedTime: "5-10 min"
    }
  ];

  const quickReports = [
    { id: "daily-summary", name: "Daily Summary", description: "Today's key metrics and activities", icon: Clock, time: "30 sec" },
    { id: "weekly-overview", name: "Weekly Overview", description: "Complete weekly performance review", icon: CalendarIcon, time: "1 min" },
    { id: "monthly-analysis", name: "Monthly Analysis", description: "Comprehensive monthly business analysis", icon: BarChart3, time: "2 min" },
    { id: "low-stock-alert", name: "Low Stock Alert", description: "Critical inventory items needing attention", icon: AlertCircle, time: "30 sec" },
    { id: "top-performers", name: "Top Performers", description: "Best selling products and suppliers", icon: Star, time: "1 min" }
  ];

  const metrics = [
    { id: "total_stock", name: "Total Stock Items", category: "inventory", icon: Package },
    { id: "stock_value", name: "Stock Valuation", category: "inventory", icon: DollarSign },
    { id: "low_stock", name: "Low Stock Alerts", category: "inventory", icon: Package },
    { id: "total_orders", name: "Total Orders", category: "orders", icon: ShoppingCart },
    { id: "order_value", name: "Order Value", category: "orders", icon: DollarSign },
    { id: "pending_orders", name: "Pending Orders", category: "orders", icon: Clock },
    { id: "completed_orders", name: "Completed Orders", category: "orders", icon: CheckCircle },
    { id: "active_suppliers", name: "Active Suppliers", category: "suppliers", icon: Users },
    { id: "supplier_performance", name: "Supplier Performance", category: "suppliers", icon: TrendingUp },
    { id: "shipments", name: "Shipment Status", category: "logistics", icon: Truck },
    { id: "delivery_time", name: "Average Delivery Time", category: "logistics", icon: Clock },
    { id: "warehouse_utilization", name: "Warehouse Utilization", category: "warehouse", icon: Warehouse },
    { id: "zone_efficiency", name: "Zone Efficiency", category: "warehouse", icon: BarChart3 }
  ];

  const handleMetricToggle = (metricId: string) => {
    setSelectedMetrics(prev => 
      prev.includes(metricId) 
        ? prev.filter(id => id !== metricId)
        : [...prev, metricId]
    );
  };

  useEffect(() => {
    // Load recent reports and saved configurations
    const mockRecentReports = [
      { id: 1, name: "Inventory Report", type: "inventory", date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), format: "pdf" },
      { id: 2, name: "Sales Analysis", type: "sales", date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), format: "excel" },
      { id: 3, name: "Weekly Summary", type: "performance", date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), format: "pdf" }
    ];
    setRecentReports(mockRecentReports);
  }, []);

  const handleQuickReport = async (reportId: string) => {
    const report = quickReports.find(r => r.id === reportId);
    if (!report) return;

    setIsGenerating(true);
    setGenerationProgress(0);

    // Simulate quick generation
    const interval = setInterval(() => {
      setGenerationProgress(prev => Math.min(100, prev + 25));
    }, 200);

    setTimeout(() => {
      clearInterval(interval);
      setGenerationProgress(100);
      setIsGenerating(false);
      toast({
        title: "Quick Report Generated",
        description: `${report.name} has been generated successfully.`,
      });
    }, 800);
  };

  const handleSaveConfiguration = () => {
    if (!reportType || !reportName) {
      toast({
        title: "Missing Information",
        description: "Please provide a report name and select a report type.",
        variant: "destructive"
      });
      return;
    }

    const config = {
      id: Date.now(),
      name: reportName,
      type: reportType,
      format: reportFormat,
      dateFrom,
      dateTo,
      metrics: selectedMetrics,
      autoSchedule,
      frequency: scheduleFrequency,
      createdAt: new Date()
    };

    setSavedReports(prev => [...prev, config]);
    toast({
      title: "Configuration Saved",
      description: "Report configuration has been saved for future use.",
    });
  };

  const handleScheduleReport = () => {
    if (!reportType || !autoSchedule) {
      toast({
        title: "Schedule Configuration Required",
        description: "Please select a report type and enable scheduling.",
        variant: "destructive"
      });
      return;
    }

    const scheduledConfig = {
      id: Date.now(),
      name: reportName || `${selectedReportType?.name} - Auto`,
      type: reportType,
      frequency: scheduleFrequency,
      nextRun: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Next week
      active: true
    };

    setScheduledReports(prev => [...prev, scheduledConfig]);
    toast({
      title: "Report Scheduled",
      description: `Report will be generated ${scheduleFrequency}.`,
    });
  };

  const handleGenerateReport = async () => {
    if (!reportType) {
      toast({
        title: "Report Type Required",
        description: "Please select a report type to generate.",
        variant: "destructive"
      });
      return;
    }

    if (!dateFrom || !dateTo) {
      toast({
        title: "Date Range Required",
        description: "Please select a date range for the report.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);

    const from = dateFrom.toISOString();
    const to = dateTo.toISOString();

    // Simulate progress while waiting
    const progressInterval = setInterval(() => {
      setGenerationProgress(prev => Math.min(98, prev + Math.random() * 20));
    }, 400);

    try {
      // For generate, trigger a file download according to selected format
      const typeMap: Record<string, string> = {
        inventory: 'inventory',
        sales: 'sales',
        orders: 'orders',
        suppliers: 'customer',
        warehouse: 'inventory',
        financial: 'financial',
        performance: 'sales',
        custom: 'low-stock'
      };

      const endpointType = typeMap[reportType] || 'low-stock';
      await api.reports.download(endpointType, reportFormat as any, { from, to });

      clearInterval(progressInterval);
      setGenerationProgress(100);
      setIsGenerating(false);
      toast({
        title: "Report Generated",
        description: `Downloaded ${reportFormat.toUpperCase()} for ${selectedReportType?.name}.`,
      });
    } catch (e: any) {
      clearInterval(progressInterval);
      setIsGenerating(false);
      toast({
        title: "Report Generation Failed",
        description: e?.message || 'Unknown error',
        variant: 'destructive'
      });
    }
  };

  const handlePreviewReport = async () => {
    if (!reportType) {
      toast({
        title: "Report Type Required",
        description: "Please select a report type to preview.",
        variant: "destructive"
      });
      return;
    }

    try {
      const from = dateFrom?.toISOString();
      const to = dateTo?.toISOString();
      let res;
      switch (reportType) {
        case 'inventory': res = await api.reports.getInventory({ from, to }); break;
        case 'sales': res = await api.reports.getSales({ from, to }); break;
        case 'orders': res = await api.orders.getStats(); break;
        case 'suppliers': res = await api.reports.getCustomer({ from, to }); break;
        case 'warehouse': res = await api.dashboard.getStats(); break;
        case 'financial': res = await api.reports.getFinancial({ from, to }); break;
        case 'performance': res = await api.reports.getSales({ from, to }); break;
        default: res = await api.reports.getLowStock({ from, to }); break;
      }
      if (!res.success) throw new Error(res.error || 'Failed to fetch preview');

      const win = window.open('', '_blank');
      if (win) {
        win.document.write(`<html><head><title>Report Preview</title><meta charset='utf-8'/>
          <style>body{font-family:Inter,system-ui,Arial;padding:16px;color:#0f172a} pre{white-space:pre-wrap;word-break:break-word;background:#f8fafc;border:1px solid #e2e8f0;padding:12px;border-radius:8px} h1{font-size:18px;margin:0 0 12px} small{color:#64748b}</style>
          </head><body><h1>${selectedReportType?.name} Preview</h1><small>${new Date().toLocaleString()}</small><pre>${
            (() => {
              try { return JSON.stringify(res.data, null, 2); } catch { return String(res.data); }
            })()
          }</pre></body></html>`);
        win.document.close();
      }
    } catch (e: any) {
      toast({
        title: "Preview Failed",
        description: e?.message || 'Unknown error',
        variant: 'destructive'
      });
    }
  };

  const handleDownloadSample = async (type: string) => {
    try {
      await api.reports.downloadSample(type, reportFormat as any);
      toast({
        title: "Sample Downloaded",
        description: `Sample ${type} (${reportFormat.toUpperCase()}) downloaded.`,
      });
    } catch (e: any) {
      toast({ title: 'Download Failed', description: e?.message || 'Unknown error', variant: 'destructive' });
    }
  };

  const getMetricsByCategory = (category: string) => {
    return metrics.filter(metric => metric.category === category);
  };

  const selectedReportType = reportTypes.find(r => r.id === reportType);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Enhanced Header */}
      <header className="bg-card/70 backdrop-blur border-b border-border sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => navigate('/')}
                className="hover:bg-slate-100"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg">
                  <BarChart3 className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                    Report Center
                  </h1>
                  <p className="text-xs text-muted-foreground">Generate, schedule, and manage reports</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline"
                onClick={handlePreviewReport}
                disabled={!reportType}
              >
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </Button>
              <Button 
                onClick={handleGenerateReport}
                disabled={isGenerating || !reportType}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {isGenerating ? (
                  <>
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Productivity Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="quick" className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Quick Reports
              </TabsTrigger>
              <TabsTrigger value="custom" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Custom Reports
              </TabsTrigger>
              <TabsTrigger value="scheduled" className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4" />
                Scheduled
              </TabsTrigger>
              <TabsTrigger value="history" className="flex items-center gap-2">
                <History className="h-4 w-4" />
                History
              </TabsTrigger>
            </TabsList>

            {/* Quick Reports Tab */}
            <TabsContent value="quick" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {quickReports.map((report) => (
                  <Card key={report.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <report.icon className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{report.name}</h3>
                          <p className="text-sm text-muted-foreground mt-1">{report.description}</p>
                          <div className="flex items-center justify-between mt-3">
                            <Badge variant="secondary" className="text-xs">
                              <Clock className="h-3 w-3 mr-1" />
                              {report.time}
                            </Badge>
                            <Button 
                              size="sm" 
                              onClick={() => handleQuickReport(report.id)}
                              disabled={isGenerating}
                            >
                              Generate
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Custom Reports Tab */}
            <TabsContent value="custom" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main Configuration */}
                <div className="lg:col-span-2 space-y-6">
                  {/* Report Configuration Card */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Report Configuration</CardTitle>
                      <CardDescription>
                        Configure your custom report settings
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label htmlFor="report-name">Report Name</Label>
                        <Input
                          id="report-name"
                          placeholder="Enter report name"
                          value={reportName}
                          onChange={(e) => setReportName(e.target.value)}
                        />
                      </div>
                      
                      <div>
                        <Label>Report Type</Label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                          {reportTypes.map((type) => (
                            <div
                              key={type.id}
                              className={`p-3 border rounded-lg cursor-pointer transition-all duration-200 hover:shadow-md ${
                                reportType === type.id 
                                  ? 'border-primary bg-primary/10 ring-2 ring-primary/30' 
                                  : 'border-border hover:border-muted'
                              }`}
                              onClick={() => setReportType(type.id)}
                            >
                              <div className="flex items-start space-x-3">
                                <type.icon className="h-5 w-5 text-primary mt-0.5" />
                                <div className="flex-1">
                                  <h3 className="font-medium text-sm">{type.name}</h3>
                                  <p className="text-xs text-muted-foreground mt-1">{type.description}</p>
                                  <div className="flex items-center space-x-2 mt-2">
                                    <Badge variant={type.popularity === 'high' ? 'default' : 'secondary'} className="text-xs">
                                      {type.popularity}
                                    </Badge>
                                    <span className="text-xs text-muted-foreground">{type.estimatedTime}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <Label htmlFor="format">Output Format</Label>
                        <Select value={reportFormat} onValueChange={setReportFormat}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select format" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pdf">PDF Document</SelectItem>
                            <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                            <SelectItem value="csv">CSV File</SelectItem>
                            <SelectItem value="html">HTML Report</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="auto-schedule" 
                          checked={autoSchedule}
                          onCheckedChange={setAutoSchedule}
                        />
                        <Label htmlFor="auto-schedule" className="text-sm">Auto-schedule this report</Label>
                      </div>

                      {autoSchedule && (
                        <div>
                          <Label htmlFor="frequency">Schedule Frequency</Label>
                          <Select value={scheduleFrequency} onValueChange={setScheduleFrequency}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select frequency" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="daily">Daily</SelectItem>
                              <SelectItem value="weekly">Weekly</SelectItem>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="quarterly">Quarterly</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Date Range Selection */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Date Range</CardTitle>
                      <CardDescription>
                        Select the date range for your report
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>From Date</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className={`w-full justify-start text-left font-normal ${
                                  !dateFrom && "text-muted-foreground"
                                }`}
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {dateFrom ? format(dateFrom, "PPP") : "Pick a date"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={dateFrom}
                                onSelect={setDateFrom}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div>
                          <Label>To Date</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className={`w-full justify-start text-left font-normal ${
                                  !dateTo && "text-muted-foreground"
                                }`}
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {dateTo ? format(dateTo, "PPP") : "Pick a date"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={dateTo}
                                onSelect={setDateTo}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2 mt-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const today = new Date();
                            const lastWeek = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
                            setDateFrom(lastWeek);
                            setDateTo(today);
                          }}
                        >
                          Last 7 Days
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const today = new Date();
                            const lastMonth = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
                            setDateFrom(lastMonth);
                            setDateTo(today);
                          }}
                        >
                          Last 30 Days
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const today = new Date();
                            const lastQuarter = new Date(today.getTime() - 90 * 24 * 60 * 60 * 1000);
                            setDateFrom(lastQuarter);
                            setDateTo(today);
                          }}
                        >
                          Last Quarter
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Generation Progress */}
                  {isGenerating && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Generating Report</CardTitle>
                        <CardDescription>
                          Please wait while we generate your report
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <Progress value={generationProgress} className="w-full" />
                          <p className="text-sm text-muted-foreground">
                            {generationProgress < 30 && "Collecting data..."}
                            {generationProgress >= 30 && generationProgress < 60 && "Processing metrics..."}
                            {generationProgress >= 60 && generationProgress < 90 && "Formatting report..."}
                            {generationProgress >= 90 && "Finalizing..."}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  {/* Quick Actions */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Quick Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={handleSaveConfiguration}
                        disabled={!reportType || !reportName}
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Save Configuration
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={handleScheduleReport}
                        disabled={!reportType || !autoSchedule}
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Schedule Report
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => {
                          setReportType('');
                          setReportName('');
                          setDateFrom(undefined);
                          setDateTo(undefined);
                          setSelectedMetrics([]);
                          setAutoSchedule(false);
                        }}
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Reset Form
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Report Summary */}
                  {selectedReportType && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Report Summary</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Type:</span>
                          <span className="font-medium">{selectedReportType.name}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Format:</span>
                          <span className="font-medium uppercase">{reportFormat}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Date Range:</span>
                          <span className="font-medium">
                            {dateFrom && dateTo 
                              ? `${format(dateFrom, "MMM dd")} - ${format(dateTo, "MMM dd")}`
                              : "Not selected"
                            }
                          </span>
                        </div>
                        {reportType === 'custom' && (
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Metrics:</span>
                            <span className="font-medium">{selectedMetrics.length} selected</span>
                          </div>
                        )}
                        {autoSchedule && (
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Schedule:</span>
                            <span className="font-medium capitalize">{scheduleFrequency}</span>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Sample Reports */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Sample Reports</CardTitle>
                      <CardDescription>
                        Download sample reports to see the format
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => handleDownloadSample('inventory')}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Inventory Sample
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => handleDownloadSample('sales')}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Sales Sample
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => handleDownloadSample('performance')}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Performance Sample
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Scheduled Reports Tab */}
            <TabsContent value="scheduled" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Scheduled Reports</CardTitle>
                  <CardDescription>
                    Manage your automated report schedule
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {scheduledReports.length === 0 ? (
                    <div className="text-center py-8">
                      <RefreshCw className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No Scheduled Reports</h3>
                      <p className="text-muted-foreground mb-4">Create a scheduled report to automate your reporting workflow</p>
                      <Button onClick={() => setActiveTab('custom')}>
                        Create Scheduled Report
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {scheduledReports.map((report) => (
                        <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="p-2 bg-primary/10 rounded-lg">
                              <RefreshCw className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h4 className="font-medium">{report.name}</h4>
                              <p className="text-sm text-muted-foreground">
                                Runs {report.frequency} • Next: {format(report.nextRun, "MMM dd, yyyy")}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant={report.active ? 'default' : 'secondary'}>
                              {report.active ? 'Active' : 'Paused'}
                            </Badge>
                            <Button variant="outline" size="sm">
                              <Settings className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* History Tab */}
            <TabsContent value="history" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Report History</CardTitle>
                  <CardDescription>
                    View and download your previously generated reports
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {recentReports.length === 0 ? (
                    <div className="text-center py-8">
                      <History className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No Report History</h3>
                      <p className="text-muted-foreground mb-4">Generate your first report to see it here</p>
                      <Button onClick={() => setActiveTab('quick')}>
                        Generate Report
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {recentReports.map((report) => (
                        <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="p-2 bg-primary/10 rounded-lg">
                              <FileText className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h4 className="font-medium">{report.name}</h4>
                              <p className="text-sm text-muted-foreground">
                                {format(report.date, "MMM dd, yyyy • HH:mm")} • {report.format.toUpperCase()}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4 mr-1" />
                              Download
                            </Button>
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
