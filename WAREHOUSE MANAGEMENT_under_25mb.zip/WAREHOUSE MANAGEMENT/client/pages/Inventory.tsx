import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { BarcodeScanner } from '../components/BarcodeScanner';
import { Barcode, Camera, X } from 'lucide-react';

type InventoryItem = {
  id: string;
  barcode: string;
  name: string;
  quantity: number;
  lastScanned: Date;
};

export default function Inventory() {
  const [showScanner, setShowScanner] = useState(false);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Check if the device is mobile
    const checkIfMobile = () => {
      setIsMobile(/iPhone|iPad|iPod|Android/i.test(navigator.userAgent));
    };
    
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    
    return () => {
      window.removeEventListener('resize', checkIfMobile);
    };
  }, []);

  const handleScan = (barcode: string) => {
    // Check if item already exists in inventory
    const existingItemIndex = inventory.findIndex(item => item.barcode === barcode);
    
    if (existingItemIndex >= 0) {
      // Update existing item
      const updatedInventory = [...inventory];
      updatedInventory[existingItemIndex] = {
        ...updatedInventory[existingItemIndex],
        quantity: updatedInventory[existingItemIndex].quantity + 1,
        lastScanned: new Date()
      };
      setInventory(updatedInventory);
    } else {
      // Add new item
      const newItem: InventoryItem = {
        id: Date.now().toString(),
        barcode,
        name: `Product ${barcode}`, // In a real app, you would fetch this from a database
        quantity: 1,
        lastScanned: new Date()
      };
      setInventory(prev => [...prev, newItem]);
    }
    
    // Close scanner after successful scan
    setShowScanner(false);
  };

  const filteredInventory = inventory.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.barcode.includes(searchTerm)
  );

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Inventory Management</h1>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={() => setShowScanner(true)}
          >
            {isMobile ? <Camera className="h-4 w-4" /> : <Barcode className="h-4 w-4" />}
            {isMobile ? 'Open Camera' : 'Scan Barcode'}
          </Button>
          <Button onClick={() => {
            const barcode = prompt('Enter barcode:');
            if (barcode) handleScan(barcode);
          }}>
            <Barcode className="h-4 w-4 mr-2" />
            Enter Manually
          </Button>
        </div>
      </div>

      <div className="mb-6">
        <input
          type="text"
          placeholder="Search by name or barcode..."
          className="w-full p-2 border border-border rounded bg-background text-foreground"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="bg-card rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-border">
          <thead className="bg-secondary">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Barcode
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Product Name
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Quantity
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Last Scanned
              </th>
            </tr>
          </thead>
          <tbody className="bg-card divide-y divide-border">
            {filteredInventory.length > 0 ? (
              filteredInventory.map((item) => (
                <tr key={item.id} className="hover:bg-secondary">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">
                    {item.barcode}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                    {item.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                    {item.quantity}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                    {item.lastScanned.toLocaleString()}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={4} className="px-6 py-4 text-center text-sm text-muted-foreground">
                  No items found. Scan a barcode to add items to inventory.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showScanner && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-card rounded-lg p-6 w-full max-w-2xl relative">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold">Scan Barcode</h3>
              <button 
                onClick={() => setShowScanner(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <BarcodeScanner
              onScan={handleScan}
              onClose={() => setShowScanner(false)}
            />
            <div className="mt-4 text-sm text-muted-foreground">
              {isMobile 
                ? 'Point your camera at a barcode to scan it.'
                : 'To scan a barcode, please use a mobile device with a camera.'}
              </div>
          </div>
        </div>
      )}
    </div>
  );
}
