import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Warehouse,
  ArrowLeft,
  ShoppingCart,
  Plus,
  Minus,
  X,
  Save,
  Calculator,
  User,
  MapPin
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { useProducts, useCustomers, useCreateOrder } from "@/hooks/useApi";
import { useWebSocket } from "@/hooks/useWebSocket";

interface OrderItem {
  id: string;
  name: string;
  category: string;
  price: number;
  quantity: number;
  stock: number;
}

export default function NewOrder() {
  const navigate = useNavigate();
  const { data: productsData, loading: productsLoading } = useProducts();
  const { data: customersData, loading: customersLoading } = useCustomers();
  const { createOrder, loading: creating } = useCreateOrder();
  const { sendOrderUpdate } = useWebSocket();
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [deliveryDate, setDeliveryDate] = useState("");
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    country: ""
  });

  const [billingInfo, setBillingInfo] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    country: ""
  });

  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState("");
  const [orderNotes, setOrderNotes] = useState("");
  const [specialInstructions, setSpecialInstructions] = useState("");
  const [orderPriority, setOrderPriority] = useState("medium");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [paymentTerms, setPaymentTerms] = useState("");
  const [shippingMethod, setShippingMethod] = useState("");
  const [orderSource, setOrderSource] = useState("");
  const [gstNumber, setGstNumber] = useState("");
  const [discountType, setDiscountType] = useState("percentage");
  const [discountValue, setDiscountValue] = useState("");
  const [assignedWorker, setAssignedWorker] = useState("");
  const [expectedDeliveryTime, setExpectedDeliveryTime] = useState("");
  // Form derived state helpers
  const isFormValid = selectedCustomerId && orderItems.length > 0 && deliveryDate;

  // Available products from API
  const availableProducts = (productsData || []).map(p => ({
    id: p.id,
    name: p.name,
    category: p.category,
    price: p.price,
    stock: p.stock,
  }));

  const handleCustomerInfoChange = (field: string, value: string) => {
    setCustomerInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleBillingInfoChange = (field: string, value: string) => {
    setBillingInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddProduct = () => {
    if (!selectedProduct) return;
    
    const product = availableProducts.find(p => p.id === selectedProduct);
    if (!product) return;

    const existingItem = orderItems.find(item => item.id === product.id);
    if (existingItem) {
      if (existingItem.quantity < product.stock) {
        setOrderItems(prev => 
          prev.map(item => 
            item.id === product.id 
              ? { ...item, quantity: item.quantity + 1 }
              : item
          )
        );
      } else {
        toast({
          title: "Stock Limit Reached",
          description: `Only ${product.stock} units available in stock.`,
          variant: "destructive"
        });
      }
    } else {
      setOrderItems(prev => [...prev, {
        id: product.id,
        name: product.name,
        category: product.category,
        price: product.price,
        quantity: 1,
        stock: product.stock
      }]);
    }
    setSelectedProduct("");
  };

  const handleQuantityChange = (itemId: string, newQuantity: number) => {
    const item = orderItems.find(item => item.id === itemId);
    if (!item) return;

    if (newQuantity <= 0) {
      handleRemoveItem(itemId);
      return;
    }

    if (newQuantity > item.stock) {
      toast({
        title: "Stock Limit Reached",
        description: `Only ${item.stock} units available in stock.`,
        variant: "destructive"
      });
      return;
    }

    setOrderItems(prev => 
      prev.map(item => 
        item.id === itemId 
          ? { ...item, quantity: newQuantity }
          : item
      )
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setOrderItems(prev => prev.filter(item => item.id !== itemId));
  };

  const calculateSubtotal = () => {
    return orderItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const calculateDiscount = () => {
    const subtotal = calculateSubtotal();
    const discount = parseFloat(discountValue) || 0;
    if (discountType === "percentage") {
      return subtotal * (discount / 100);
    } else {
      return Math.min(discount, subtotal); // Don't allow discount > subtotal
    }
  };

  const calculateTotal = () => {
    return calculateSubtotal() - calculateDiscount();
  };

  const calculateTax = () => {
    return calculateTotal() * 0.18; // 18% GST
  };

  const calculateGrandTotal = () => {
    return calculateTotal() + calculateTax();
  };

  const handleCreateOrder = async () => {
    if (!selectedCustomerId) {
      toast({
        title: "Customer Required",
        description: "Please select a customer.",
        variant: "destructive",
      });
      return;
    }
    if (orderItems.length === 0) {
      toast({
        title: "No Items",
        description: "Please add at least one product.",
        variant: "destructive",
      });
      return;
    }
    if (!deliveryDate) {
      toast({
        title: "Delivery Date Required",
        description: "Please select a delivery date.",
        variant: "destructive",
      });
      return;
    }

    try {
      const payload = {
        customerId: selectedCustomerId,
        items: orderItems.map(i => ({ productId: i.id, quantity: i.quantity })),
        priority: (['low','medium','high'].includes(orderPriority) ? orderPriority : 'medium') as 'low'|'medium'|'high',
        deliveryDate,
        shippingAddress: {
          street: customerInfo.address,
          city: customerInfo.city,
          state: customerInfo.state,
          pincode: customerInfo.pincode,
          country: customerInfo.country || 'India',
        },
        billingAddress: billingInfo.address ? {
          street: billingInfo.address,
          city: billingInfo.city,
          state: billingInfo.state,
          pincode: billingInfo.pincode,
          country: billingInfo.country || 'India',
        } : undefined,
        notes: orderNotes || undefined,
        specialInstructions: specialInstructions || undefined,
        paymentMethod: paymentMethod || undefined,
        paymentTerms: paymentTerms || undefined,
        shippingMethod: shippingMethod || undefined,
        orderSource: orderSource || undefined,
        gstNumber: gstNumber || undefined,
        discount: discountValue ? {
          type: discountType as 'percentage' | 'fixed',
          value: parseFloat(discountValue)
        } : undefined,
        assignedWorker: assignedWorker || undefined,
        expectedDeliveryTime: expectedDeliveryTime || undefined,
      };

      const created = await createOrder(payload);
      if (created) {
        toast({ title: "Order Created", description: `Order created for ${customerInfo.name}.` });
        try {
          // Notify other clients via WebSocket to refresh
          sendOrderUpdate({ orderId: created.id, customerId: created.customer.id, customerName: created.customer.name, status: created.status });
        } catch {}
        // Reset form
        setSelectedCustomerId("");
        setDeliveryDate("");
        setCustomerInfo({
          name: "",
          email: "",
          phone: "",
          address: "",
          city: "",
          state: "",
          pincode: "",
          country: "",
        });
        setBillingInfo({
          name: "",
          email: "",
          phone: "",
          address: "",
          city: "",
          state: "",
          pincode: "",
          country: "",
        });
        setOrderItems([]);
        setOrderNotes("");
        setSpecialInstructions("");
        setPaymentMethod("");
        setPaymentTerms("");
        setShippingMethod("");
        setOrderSource("");
        setGstNumber("");
        setDiscountType("percentage");
        setDiscountValue("");
        setAssignedWorker("");
        setExpectedDeliveryTime("");
        navigate('/orders');
      }
    } catch (err) {
      toast({ title: "Failed to create order", description: err instanceof Error ? err.message : String(err), variant: 'destructive' });
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      "Clothes": "bg-gradient-to-r from-pink-500 to-rose-500",
      "Electronics": "bg-gradient-to-r from-blue-500 to-cyan-500",
      "Accessories": "bg-gradient-to-r from-purple-500 to-violet-500",
      "Sports": "bg-gradient-to-r from-orange-500 to-red-500",
      "Beauty": "bg-gradient-to-r from-teal-500 to-cyan-500",
      "Home Decor": "bg-gradient-to-r from-green-500 to-emerald-500"
    };
    return colors[category] || "bg-gradient-to-r from-gray-500 to-slate-500";
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/90 backdrop-blur-xl border-b border-border sticky top-0 z-50 shadow-lg shadow-slate-200/20">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => navigate('/')}
                className="hover:bg-slate-100"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-gradient-to-br from-emerald-500 to-green-600 rounded-lg">
                  <ShoppingCart className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  Create New Order
                </h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline"
                onClick={() => {
                  setSelectedCustomerId("");
                  setDeliveryDate("");
                  setCustomerInfo({
                    name: "",
                    email: "",
                    phone: "",
                    address: "",
                    city: "",
                    state: "",
                    pincode: "",
                    country: "",
                  });
                  setBillingInfo({
                    name: "",
                    email: "",
                    phone: "",
                    address: "",
                    city: "",
                    state: "",
                    pincode: "",
                    country: "",
                  });
                  setOrderItems([]);
                  setOrderNotes("");
                  setSpecialInstructions("");
                  setPaymentMethod("");
                  setPaymentTerms("");
                  setShippingMethod("");
                  setOrderSource("");
                  setGstNumber("");
                  setDiscountType("percentage");
                  setDiscountValue("");
                  setAssignedWorker("");
                  setExpectedDeliveryTime("");
                }}
              >
                Clear Form
              </Button>
              <Button 
                onClick={handleCreateOrder}
                disabled={!isFormValid || creating}
                className="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white"
              >
                <Save className="h-4 w-4 mr-2" />
                {creating ? 'Creating...' : 'Create Order'}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* Customer Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <User className="h-5 w-5" />
                    <span>Customer Information</span>
                  </CardTitle>
                  <CardDescription>
                    Enter customer details for the order
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Select existing customer */}
                  <div>
                    <Label>Customer *</Label>
                    <Select
                      value={selectedCustomerId}
                      onValueChange={(val) => {
                        setSelectedCustomerId(val);
                        const sel = (customersData || []).find((c: any) => c.id === val);
                        if (sel) {
                          setCustomerInfo({
                            name: sel.name,
                            email: sel.email,
                            phone: sel.phone,
                            address: sel.address.street,
                            city: sel.address.city,
                            state: sel.address.state,
                            pincode: sel.address.pincode,
                            country: sel.address.country,
                          });
                        }
                      }}
                    >
                      <SelectTrigger disabled={customersLoading}>
                        <SelectValue placeholder={customersLoading ? "Loading customers..." : "Select a customer"} />
                      </SelectTrigger>
                      <SelectContent>
                        {(customersData || []).map((c: any) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.name} - {c.email}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="customerName">Customer Name *</Label>
                      <Input
                        id="customerName"
                        value={customerInfo.name}
                        onChange={(e) => handleCustomerInfoChange('name', e.target.value)}
                        placeholder="Enter customer name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="customerEmail">Email *</Label>
                      <Input
                        id="customerEmail"
                        type="email"
                        value={customerInfo.email}
                        onChange={(e) => handleCustomerInfoChange('email', e.target.value)}
                        placeholder="Enter email address"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="customerPhone">Phone</Label>
                      <Input
                        id="customerPhone"
                        value={customerInfo.phone}
                        onChange={(e) => handleCustomerInfoChange('phone', e.target.value)}
                        placeholder="Enter phone number"
                      />
                    </div>
                    <div>
                      <Label htmlFor="deliveryDate">Delivery Date *</Label>
                      <Input
                        id="deliveryDate"
                        type="date"
                        value={deliveryDate}
                        onChange={(e) => setDeliveryDate(e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Textarea
                      id="address"
                      value={customerInfo.address}
                      onChange={(e) => handleCustomerInfoChange('address', e.target.value)}
                      placeholder="Enter full address"
                      rows={2}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        value={customerInfo.city}
                        onChange={(e) => handleCustomerInfoChange('city', e.target.value)}
                        placeholder="Enter city"
                      />
                    </div>
                    <div>
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        value={customerInfo.state}
                        onChange={(e) => handleCustomerInfoChange('state', e.target.value)}
                        placeholder="Enter state"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="country">Country</Label>
                    <Input
                      id="country"
                      value={customerInfo.country}
                      onChange={(e) => handleCustomerInfoChange('country', e.target.value)}
                      placeholder="Enter country"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Billing Address */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MapPin className="h-5 w-5" />
                    <span>Billing Address</span>
                  </CardTitle>
                  <CardDescription>
                    Enter billing address (leave empty to use shipping address)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="billingName">Billing Name</Label>
                      <Input
                        id="billingName"
                        value={billingInfo.name}
                        onChange={(e) => handleBillingInfoChange('name', e.target.value)}
                        placeholder="Enter billing name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="billingEmail">Billing Email</Label>
                      <Input
                        id="billingEmail"
                        type="email"
                        value={billingInfo.email}
                        onChange={(e) => handleBillingInfoChange('email', e.target.value)}
                        placeholder="Enter billing email"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="billingPhone">Billing Phone</Label>
                      <Input
                        id="billingPhone"
                        value={billingInfo.phone}
                        onChange={(e) => handleBillingInfoChange('phone', e.target.value)}
                        placeholder="Enter billing phone"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="billingAddress">Billing Address</Label>
                    <Textarea
                      id="billingAddress"
                      value={billingInfo.address}
                      onChange={(e) => handleBillingInfoChange('address', e.target.value)}
                      placeholder="Enter billing address"
                      rows={2}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="billingCity">City</Label>
                      <Input
                        id="billingCity"
                        value={billingInfo.city}
                        onChange={(e) => handleBillingInfoChange('city', e.target.value)}
                        placeholder="Enter city"
                      />
                    </div>
                    <div>
                      <Label htmlFor="billingState">State</Label>
                      <Input
                        id="billingState"
                        value={billingInfo.state}
                        onChange={(e) => handleBillingInfoChange('state', e.target.value)}
                        placeholder="Enter state"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="billingPincode">Pincode</Label>
                      <Input
                        id="billingPincode"
                        value={billingInfo.pincode}
                        onChange={(e) => handleBillingInfoChange('pincode', e.target.value)}
                        placeholder="Enter pincode"
                      />
                    </div>
                    <div>
                      <Label htmlFor="billingCountry">Country</Label>
                      <Input
                        id="billingCountry"
                        value={billingInfo.country}
                        onChange={(e) => handleBillingInfoChange('country', e.target.value)}
                        placeholder="Enter country"
                        defaultValue="India"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Product Selection */}
              <Card>
                <CardHeader>
                  <CardTitle>Add Products</CardTitle>
                  <CardDescription>
                    Select products to add to the order
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex space-x-2">
                    <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                      <SelectTrigger className="flex-1" disabled={productsLoading}>
                        <SelectValue placeholder={productsLoading ? "Loading products..." : "Select a product"} />
                      </SelectTrigger>
                      <SelectContent>
                        {availableProducts.map((product) => (
                          <SelectItem key={product.id} value={product.id}>
                            <div className="flex items-center justify-between w-full">
                              <span>{product.name}</span>
                              <div className="flex items-center space-x-2 ml-4">
                                <span className="text-sm text-green-600">₹{product.price}</span>
                                <span className="text-xs text-slate-500">({product.stock} in stock)</span>
                              </div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button onClick={handleAddProduct} disabled={!selectedProduct || productsLoading}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add
                    </Button>
                  </div>

                  {/* Order Items */}
                  {orderItems.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="font-medium text-slate-900">Order Items ({orderItems.length})</h4>
                      <div className="space-y-2">
                        {orderItems.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between p-4 border rounded-lg bg-slate-50"
                          >
                            <div className="flex items-center space-x-3">
                              <Badge className={`text-xs ${getCategoryColor(item.category)} text-white border-0`}>
                                {item.category}
                              </Badge>
                              <div>
                                <p className="font-medium text-slate-900">{item.name}</p>
                                <p className="text-sm text-slate-600">₹{item.price} each</p>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-3">
                              <div className="flex items-center space-x-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="w-12 text-center font-medium">{item.quantity}</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                              
                              <div className="text-right min-w-[80px]">
                                <p className="font-medium">₹{(item.price * item.quantity).toLocaleString()}</p>
                              </div>
                              
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleRemoveItem(item.id)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Order Details */}
              <Card>
                <CardHeader>
                  <CardTitle>Order Details</CardTitle>
                  <CardDescription>
                    Additional order information and settings
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="priority">Priority</Label>
                      <Select value={orderPriority} onValueChange={setOrderPriority}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low Priority</SelectItem>
                          <SelectItem value="medium">Medium Priority</SelectItem>
                          <SelectItem value="high">High Priority</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="payment">Payment Method</Label>
                      <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select payment method" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cash">Cash on Delivery</SelectItem>
                          <SelectItem value="card">Credit/Debit Card</SelectItem>
                          <SelectItem value="upi">UPI</SelectItem>
                          <SelectItem value="bank">Bank Transfer</SelectItem>
                          <SelectItem value="cheque">Cheque</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="paymentTerms">Payment Terms</Label>
                      <Select value={paymentTerms} onValueChange={setPaymentTerms}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select payment terms" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="prepaid">Prepaid</SelectItem>
                          <SelectItem value="cod">Cash on Delivery</SelectItem>
                          <SelectItem value="net-15">Net 15 Days</SelectItem>
                          <SelectItem value="net-30">Net 30 Days</SelectItem>
                          <SelectItem value="net-45">Net 45 Days</SelectItem>
                          <SelectItem value="net-60">Net 60 Days</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="shippingMethod">Shipping Method</Label>
                      <Select value={shippingMethod} onValueChange={setShippingMethod}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select shipping method" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="standard">Standard Delivery</SelectItem>
                          <SelectItem value="express">Express Delivery</SelectItem>
                          <SelectItem value="overnight">Overnight</SelectItem>
                          <SelectItem value="same-day">Same Day</SelectItem>
                          <SelectItem value="pickup">Store Pickup</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="orderSource">Order Source</Label>
                      <Select value={orderSource} onValueChange={setOrderSource}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select order source" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="online">Online Store</SelectItem>
                          <SelectItem value="phone">Phone Order</SelectItem>
                          <SelectItem value="walk-in">Walk-in Customer</SelectItem>
                          <SelectItem value="wholesale">Wholesale</SelectItem>
                          <SelectItem value="retail">Retail</SelectItem>
                          <SelectItem value="b2b">B2B Portal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="gstNumber">GST Number</Label>
                      <Input
                        id="gstNumber"
                        value={gstNumber}
                        onChange={(e) => setGstNumber(e.target.value)}
                        placeholder="Enter GST number"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="discountType">Discount Type</Label>
                      <Select value={discountType} onValueChange={setDiscountType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="percentage">Percentage (%)</SelectItem>
                          <SelectItem value="fixed">Fixed Amount (₹)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2">
                      <Label htmlFor="discountValue">Discount Value</Label>
                      <Input
                        id="discountValue"
                        type="number"
                        value={discountValue}
                        onChange={(e) => setDiscountValue(e.target.value)}
                        placeholder={discountType === "percentage" ? "Enter percentage (e.g., 10)" : "Enter amount (e.g., 500)"}
                        min="0"
                        step={discountType === "percentage" ? "0.1" : "1"}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expectedDeliveryTime">Expected Delivery Time</Label>
                      <Input
                        id="expectedDeliveryTime"
                        type="time"
                        value={expectedDeliveryTime}
                        onChange={(e) => setExpectedDeliveryTime(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="assignedWorker">Assigned Worker</Label>
                      <Select value={assignedWorker} onValueChange={setAssignedWorker}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select worker (optional)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="auto-assign">Auto Assign</SelectItem>
                          <SelectItem value="john-doe">John Doe</SelectItem>
                          <SelectItem value="jane-smith">Jane Smith</SelectItem>
                          <SelectItem value="mike-johnson">Mike Johnson</SelectItem>
                          <SelectItem value="sarah-wilson">Sarah Wilson</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="notes">Order Notes</Label>
                    <Textarea
                      id="notes"
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      placeholder="General order notes and comments"
                      rows={2}
                    />
                  </div>

                  <div>
                    <Label htmlFor="specialInstructions">Special Instructions</Label>
                    <Textarea
                      id="specialInstructions"
                      value={specialInstructions}
                      onChange={(e) => setSpecialInstructions(e.target.value)}
                      placeholder="Special handling instructions, delivery preferences, etc."
                      rows={2}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary Sidebar */}
            <div className="space-y-6">
              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calculator className="h-5 w-5" />
                    <span>Order Summary</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Subtotal ({orderItems.length} items):</span>
                      <span>₹{calculateSubtotal().toLocaleString()}</span>
                    </div>
                    {calculateDiscount() > 0 && (
                      <div className="flex justify-between text-sm text-green-600">
                        <span>Discount ({discountType === "percentage" ? `${discountValue}%` : `₹${discountValue}`}):</span>
                        <span>-₹{calculateDiscount().toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Taxable Amount:</span>
                      <span>₹{calculateTotal().toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Tax (18% GST):</span>
                      <span>₹{calculateTax().toLocaleString()}</span>
                    </div>
                    <div className="border-t pt-2">
                      <div className="flex justify-between font-semibold text-lg">
                        <span>Grand Total:</span>
                        <span>₹{calculateGrandTotal().toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {orderItems.length > 0 && (
                    <div className="pt-4 border-t">
                      <h4 className="font-medium text-slate-900 mb-2">Items</h4>
                      <div className="space-y-2">
                        {orderItems.map((item) => (
                          <div key={item.id} className="flex justify-between text-sm">
                            <span className="text-slate-600">{item.name} x{item.quantity}</span>
                            <span>₹{(item.price * item.quantity).toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Customer Summary */}
              {customerInfo.name && (
                <Card>
                  <CardHeader>
                    <CardTitle>Customer Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div>
                      <span className="text-sm text-slate-600">Name:</span>
                      <p className="font-medium">{customerInfo.name}</p>
                    </div>
                    <div>
                      <span className="text-sm text-slate-600">Email:</span>
                      <p className="font-medium">{customerInfo.email}</p>
                    </div>
                    {customerInfo.phone && (
                      <div>
                        <span className="text-sm text-slate-600">Phone:</span>
                        <p className="font-medium">{customerInfo.phone}</p>
                      </div>
                    )}
                    {customerInfo.city && (
                      <div>
                        <span className="text-sm text-slate-600">Location:</span>
                        <p className="font-medium">{customerInfo.city}, {customerInfo.state}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => navigate('/orders')}
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    View All Orders
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => navigate('/stock')}
                  >
                    <Warehouse className="h-4 w-4 mr-2" />
                    Check Stock
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
