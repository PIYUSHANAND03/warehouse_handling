import { useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { api } from "@/lib/api";

// Server shipment status type
type ShipmentStatus = "pending" | "in-transit" | "delivered" | "returned";

interface ShipmentListItem {
  id: string;
  orderId: string;
  trackingNumber: string;
  carrier: string;
  status: ShipmentStatus;
  shipDate: string;
  estimatedDelivery: string;
  actualDelivery?: string;
  origin: { address: string; city: string; state: string; pincode: string };
  destination: { address: string; city: string; state: string; pincode: string };
  weight: number;
  dimensions: { length: number; width: number; height: number };
  cost: number;
}

export default function PendingShipments() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<"all" | ShipmentStatus>("all");

  const [shipments, setShipments] = useState<ShipmentListItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [stats, setStats] = useState<{
    totalShipments: number;
    pending: number;
    inTransit: number;
    delivered: number;
    returned: number;
  } | null>(null);

  // Pick up initial search from URL (?search=...)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const q = params.get("search") || "";
    if (q) setSearchTerm(q);
  }, [location.search]);

  // Fetch shipments and stats from backend
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        setError(null);
        // Fetch only pending + in-transit shipments for this page
        const [pendingRes, statsRes] = await Promise.all([
          api.shipments.getAll({ status: undefined, sortBy: "estimatedDelivery", sortOrder: "asc", limit: 200 }),
          api.shipments.getStatsSummary(),
        ]);

        if (!mounted) return;

        if (pendingRes.success && Array.isArray(pendingRes.data)) {
          // Filter to pending + in-transit here for display
          const filtered = (pendingRes.data as ShipmentListItem[]).filter(
            (s) => s.status === "pending" || s.status === "in-transit"
          );
          setShipments(filtered);
        } else {
          setError(pendingRes.error || "Failed to load shipments");
        }

        if (statsRes.success && statsRes.data) {
          setStats(statsRes.data as any);
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : "Unknown error");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const filteredShipments = useMemo(() => {
    return shipments.filter((s) => {
      const matchesSearch =
        s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.orderId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.trackingNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.carrier.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.destination.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.destination.state.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = selectedStatus === "all" || s.status === selectedStatus;
      return matchesSearch && matchesStatus;
    });
  }, [shipments, searchTerm, selectedStatus]);

  const shipmentStats = useMemo(() => {
    const total = shipments.length;
    const pending = shipments.filter((s) => s.status === "pending").length;
    const inTransit = shipments.filter((s) => s.status === "in-transit").length;
    const totalCost = shipments.reduce((sum, s) => sum + (s.cost || 0), 0);
    const totalWeight = shipments.reduce((sum, s) => sum + (s.weight || 0), 0);
    return {
      total,
      pending,
      inTransit,
      delivered: stats?.delivered ?? 0,
      returned: stats?.returned ?? 0,
      totalValue: totalCost,
      totalWeight,
    };
  }, [shipments, stats]);

  const getStatusColor = (status: ShipmentStatus) => {
    switch (status) {
      case "pending":
        return "#f59e0b"; // amber
      case "in-transit":
        return "#3b82f6"; // blue
      case "delivered":
        return "#22c55e"; // green
      case "returned":
        return "#ef4444"; // red
      default:
        return "#6b7280"; // gray
    }
  };

  // Actions
  const handleView = (shipment: ShipmentListItem) => {
    if (shipment.orderId) {
      navigate(`/orders/${shipment.orderId}`);
    } else {
      toast({ title: "View Shipment", description: `Shipment ${shipment.id}` });
    }
  };

  const handleEdit = async (shipment: ShipmentListItem) => {
    try {
      const newEta = window.prompt("Update estimated delivery (YYYY-MM-DD):", shipment.estimatedDelivery);
      if (!newEta || newEta === shipment.estimatedDelivery) return;
      const res = await api.shipments.update(shipment.id, { estimatedDelivery: newEta });
      if (res.success && res.data) {
        setShipments((prev) => prev.map((s) => (s.id === shipment.id ? { ...s, estimatedDelivery: newEta } : s)));
        toast({ title: "Shipment updated", description: `ETA updated to ${newEta}` });
      } else {
        toast({ title: "Update failed", description: res.error || "Unable to update", variant: "destructive" as any });
      }
    } catch (e) {
      toast({ title: "Update failed", description: e instanceof Error ? e.message : "Unknown error", variant: "destructive" as any });
    }
  };

  const handleDispatch = async (shipment: ShipmentListItem) => {
    try {
      if (shipment.status === "in-transit") return;
      const res = await api.shipments.updateStatus(shipment.id, "in-transit");
      if (res.success && res.data) {
        setShipments((prev) => prev.map((s) => (s.id === shipment.id ? { ...s, status: "in-transit" } : s)));
        toast({ title: "Shipment dispatched", description: `${shipment.id} is now in-transit` });
      } else {
        toast({ title: "Dispatch failed", description: res.error || "Unable to dispatch", variant: "destructive" as any });
      }
    } catch (e) {
      toast({ title: "Dispatch failed", description: e instanceof Error ? e.message : "Unknown error", variant: "destructive" as any });
    }
  };

  const handleScheduleShipment = () => {
    navigate("/new-order");
  };

  return (
    <div data-zone="shipping" className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card/70 backdrop-blur border-b border-border sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="flex items-center px-4 py-2 rounded-lg border border-border bg-card hover:bg-secondary transition-colors"
              >
                <i className="fas fa-arrow-left mr-2"></i>
                Back to Dashboard
              </button>
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-lg bg-primary text-primary-foreground">
                  <i className="fas fa-truck"></i>
                </div>
                <h1 className="text-2xl font-bold">
                  Pending Shipments
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"></i>
                <input
                  placeholder="Search shipments..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-80 bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                />
              </div>
              <button 
                onClick={handleScheduleShipment} 
                className="flex items-center px-4 py-2 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors"
              >
                <i className="fas fa-plus mr-2"></i>
                Schedule Shipment
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 py-8">
        {error && (
          <div className="mb-4 text-sm text-destructive-foreground bg-destructive/20 border border-destructive rounded-md p-3">
            {error}
          </div>
        )}

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-blue-100">Total Shipments</h3>
              <i className="fas fa-truck text-white"></i>
            </div>
            <div className="text-3xl font-bold">{stats?.totalShipments ?? shipmentStats.total}</div>
            <div className="text-sm text-blue-100">All</div>
          </div>

          <div className="bg-gradient-to-br from-amber-500 to-yellow-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-amber-100">Pending</h3>
              <i className="fas fa-hourglass-half text-white"></i>
            </div>
            <div className="text-3xl font-bold">{shipmentStats.pending}</div>
            <div className="text-sm text-amber-100">Awaiting dispatch</div>
          </div>

          <div className="bg-gradient-to-br from-indigo-500 to-blue-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-indigo-100">In Transit</h3>
              <i className="fas fa-shipping-fast text-white"></i>
            </div>
            <div className="text-3xl font-bold">{shipmentStats.inTransit}</div>
            <div className="text-sm text-indigo-100">On the way</div>
          </div>

          <div className="bg-gradient-to-br from-emerald-500 to-green-600 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-emerald-100">Total Cost</h3>
              <i className="fas fa-rupee-sign text-white"></i>
            </div>
            <div className="text-3xl font-bold">₹{shipmentStats.totalValue.toLocaleString()}</div>
            <div className="text-sm text-emerald-100">Shipping</div>
          </div>

          <div className="bg-gradient-to-br from-pink-500 to-rose-500 text-white border-0 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-pink-100">Total Weight</h3>
              <i className="fas fa-weight-hanging text-white"></i>
            </div>
            <div className="text-3xl font-bold">{shipmentStats.totalWeight}kg</div>
            <div className="text-sm text-pink-100">To ship</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center px-3 py-1 bg-secondary border border-[#4a4e69] rounded-lg text-sm">
              <span className="text-muted-foreground">{filteredShipments.length} shipments found</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="fas fa-filter text-muted-foreground"></i>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value as any)}
                className="bg-secondary border border-[#4a4e69] rounded-lg px-3 py-1 text-sm text-foreground focus:outline-none focus:border-[#4f46e5]"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="in-transit">In Transit</option>
                <option value="delivered">Delivered</option>
                <option value="returned">Returned</option>
              </select>
            </div>
          </div>
        </div>

        {/* Shipments Grid */}
        {loading ? (
          <div className="text-sm text-muted-foreground">Loading shipments…</div>
        ) : filteredShipments.length === 0 ? (
          <div className="bg-card border border-border rounded-xl p-12 text-center">
            <div className="flex flex-col items-center space-y-4">
              <div className="p-4 rounded-full bg-muted">
                <i className="fas fa-truck text-4xl text-muted-foreground"></i>
              </div>
              <h3 className="text-xl font-semibold">No Pending Shipments Found</h3>
              <p className="text-muted-foreground max-w-md">
                {searchTerm || selectedStatus !== 'all' 
                  ? 'No shipments match your current filters. Try adjusting your search or filter criteria.'
                  : 'There are currently no pending or in-transit shipments. All shipments have been delivered or are in other statuses.'}
              </p>
              <div className="flex items-center space-x-3 mt-4">
                <button 
                  onClick={() => { setSearchTerm(''); setSelectedStatus('all'); }}
                  className="px-4 py-2 rounded-lg border border-border bg-card hover:bg-secondary transition-colors"
                >
                  <i className="fas fa-redo mr-2"></i>
                  Clear Filters
                </button>
                <button 
                  onClick={handleScheduleShipment}
                  className="px-4 py-2 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors"
                >
                  <i className="fas fa-plus mr-2"></i>
                  Schedule New Shipment
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {filteredShipments.map((shipment) => (
              <div key={shipment.id} className="bg-card border border-border rounded-xl p-6 hover:border-primary transition-all duration-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="px-2 py-1 rounded text-xs text-white font-medium"
                      style={{ backgroundColor: getStatusColor(shipment.status) }}
                    >
                      {shipment.status}
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div 
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: getStatusColor(shipment.status) }}
                    ></div>
                  </div>
                </div>
                
                <h3 className="text-xl font-semibold mb-1">{shipment.id}</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Order: {shipment.orderId} | {shipment.trackingNumber}
                </p>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Destination</div>
                      <div className="font-medium flex items-center space-x-1">
                        <i className="fas fa-map-marker-alt text-muted-foreground"></i>
                        <span>{shipment.destination.city}, {shipment.destination.state}</span>
                      </div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">ETA</div>
                      <div className="font-medium flex items-center space-x-1">
                        <i className="fas fa-calendar text-muted-foreground"></i>
                        <span>{shipment.estimatedDelivery}</span>
                      </div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Weight</div>
                      <div className="font-medium">{shipment.weight}kg</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Cost</div>
                      <div className="font-medium">₹{(shipment.cost || 0).toLocaleString()}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="text-xs text-muted-foreground">
                      <div>Carrier: {shipment.carrier}</div>
                      <div>Ship Date: {shipment.shipDate}</div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => handleView(shipment)}
                        className="p-2 text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-secondary"
                        title="View order"
                      >
                        <i className="fas fa-eye"></i>
                      </button>
                      <button 
                        onClick={() => handleEdit(shipment)}
                        className="p-2 text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-secondary"
                        title="Edit ETA"
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                      <button 
                        onClick={() => handleDispatch(shipment)}
                        className="flex items-center px-3 py-1 bg-[#06b6d4] hover:bg-[#0891b2] text-white rounded-lg text-sm transition-colors"
                        disabled={shipment.status === "in-transit"}
                        title={shipment.status === "in-transit" ? "Already dispatched" : "Dispatch"}
                      >
                        <i className="fas fa-truck mr-1"></i>
                        {shipment.status === "in-transit" ? "In Transit" : "Dispatch"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
