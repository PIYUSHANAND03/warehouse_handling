import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { useDashboard } from "@/hooks/useApi";
import { api } from "@/lib/api";
import { ProfileMenu } from "@/components/ProfileMenu";

export default function Index() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeNav, setActiveNav] = useState("dashboard");
  
  // Fetch real data from API
  const { data: dashboardData, loading, error } = useDashboard();

  // Shipping activities counts from backend shipments summary
  const [shippingCounts, setShippingCounts] = useState({ ready: 0, prepared: 0, delayed: 0 });
  // Workers statistics from backend summary
  const [workerStats, setWorkerStats] = useState<any>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const res = await api.shipments.getStatsSummary();
      if (mounted && res.success && res.data) {
        // Map to previously used labels: ready ~ pending, prepared ~ inTransit, delayed ~ returned (approx.)
        setShippingCounts({
          ready: (res.data as any).pending ?? 0,
          prepared: (res.data as any).inTransit ?? 0,
          delayed: (res.data as any).returned ?? 0,
        });
      }
    })();
    return () => { mounted = false };
  }, []);

  // Load worker stats for dashboard card
  useEffect(() => {
    let mounted = true;
    (async () => {
      const res = await api.workers.getStatsSummary();
      if (mounted && res.success && res.data) setWorkerStats(res.data as any);
    })();
    return () => { mounted = false };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => date.toLocaleTimeString("en-US", { hour12: false });

  const handleNavClick = (navItem: string, path?: string) => {
    setActiveNav(navItem);
    if (path) {
      navigate(path);
    } else {
      toast({ title: `${navItem} Section`, description: `Navigating to ${navItem}...` });
    }
  };


  return (
    <div className="flex h-screen bg-background text-foreground font-sans overflow-hidden">
      {/* Sidebar */}
      <aside data-zone="dashboard" className="w-64 bg-card p-6 flex flex-col flex-shrink-0 border-r border-border">
        <div className="flex items-center gap-3 mb-10">
          <div className="bg-primary p-2 rounded-lg text-primary-foreground">
            <i className="fas fa-warehouse text-xl"></i>
          </div>
          <div className="flex flex-col leading-tight">
            <h1 className="text-xl font-semibold">invenTREE</h1>
            <span className="text-xs text-muted-foreground">where inventory grows in order</span>
          </div>
        </div>

        <nav className="flex-1">
          <ul className="space-y-2">
            <li>
              <button
                onClick={() => handleNavClick("dashboard")}
                className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                  activeNav === "dashboard"
                    ? "bg-primary text-primary-foreground font-semibold"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <i className="fas fa-home w-6 text-center mr-4"></i>
                Dashboard
              </button>
            </li>
            <li>
              <button
                onClick={() => handleNavClick("inventory", "/stock")}
                className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                  activeNav === "inventory"
                    ? "bg-background text-foreground font-semibold"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <i className="fas fa-box-archive w-6 text-center mr-4"></i>
                Inventory
              </button>
            </li>
            <li>
              <button
                onClick={() => handleNavClick("orders", "/orders")}
                className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                  activeNav === "orders"
                    ? "bg-background text-foreground font-semibold"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <i className="fas fa-clipboard-list w-6 text-center mr-4"></i>
                Orders
                {dashboardData && dashboardData.pendingOrders > 0 && (
                  <span className="ml-auto bg-destructive text-destructive-foreground text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {dashboardData.pendingOrders}
                  </span>
                )}
              </button>
            </li>
            <li>
              <button
                onClick={() => handleNavClick("shipping", "/pending-shipments")}
                className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                  activeNav === "shipping"
                    ? "bg-background text-foreground font-semibold"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <i className="fas fa-truck-fast w-6 text-center mr-4"></i>
                Shipping
              </button>
            </li>
            <li>
              <button
                onClick={() => handleNavClick("receiving", "/receiving")}
                className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                  activeNav === "receiving"
                    ? "bg-background text-foreground font-semibold"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <i className="fas fa-dolly w-6 text-center mr-4"></i>
                Receiving
              </button>
            </li>
            <li>
              <button
                onClick={() => handleNavClick("workers", "/workers")}
                className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                  activeNav === "workers"
                    ? "bg-background text-foreground font-semibold"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <i className="fas fa-users w-6 text-center mr-4"></i>
                Workers
              </button>
            </li>
            <li>
              <button
                onClick={() => handleNavClick("reports", "/generate-report")}
                className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                  activeNav === "reports"
                    ? "bg-background text-foreground font-semibold"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <i className="fas fa-chart-pie w-6 text-center mr-4"></i>
                Reports
              </button>
            </li>
            <li>
              <button
                onClick={() => handleNavClick("settings", "/settings")}
                className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                  activeNav === "settings"
                    ? "bg-background text-foreground font-semibold"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <i className="fas fa-gear w-6 text-center mr-4"></i>
                Settings
              </button>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Main Content */}
      <main data-zone="dashboard" className="flex-1 p-6 md:p-8 overflow-y-auto flex flex-col">
        {/* Header */}
        <header data-zone="dashboard" className="flex justify-between items-center mb-6">
          <form onSubmit={e => { e.preventDefault(); const term = searchTerm.trim(); navigate(term ? `/stock?search=${encodeURIComponent(term)}` : "/stock"); }} className="relative w-96">
            <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"></i>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search for items, orders, or SKUs..."
              className="w-full pl-12 pr-4 py-3 bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
            />
                      </form>

          <div className="flex items-center gap-5">
            <div className="flex items-center gap-2 bg-card px-4 py-2 rounded-lg border border-border">
              <i className="fas fa-clock text-muted-foreground"></i>
              <span className="font-semibold tracking-wide">{formatTime(currentTime)}</span>
            </div>
            <button
              className="text-muted-foreground hover:text-foreground transition-colors"
              onClick={() => toast({ title: "Notifications", description: "No new notifications" })}
            >
              <i className="fas fa-bell text-xl"></i>
            </button>
            <ProfileMenu />
                      </div>
        </header>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 grid-rows-auto gap-6 flex-1">
          {/* Warehouse Map */}
          <div className="lg:col-span-2 xl:col-span-2 lg:row-span-2 bg-card rounded-xl p-6 border border-border relative min-h-96 flex flex-col justify-between box-glow">
            <div
              className="absolute inset-0 rounded-xl"
              style={{
                backgroundImage:
                  "url('https://t4.ftcdn.net/jpg/12/92/30/85/360_F_1292308539_4WdctHyo3Ge2Ckdf2dGy51gFQlY4OpGc.jpg')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                opacity: 0.3,
              }}
            ></div>

            <div className="relative z-10">
              <div className="gap-5 bg-secondary/80 backdrop-blur-sm p-3 rounded-lg flex">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-4 h-4 bg-[#22c55e] rounded"></div>
                  <span>Available</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-4 h-4 bg-[#f59e0b] rounded"></div>
                  <span>Pending</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-4 h-4 bg-[#ef4444] rounded"></div>
                  <span>Occupied</span>
                </div>
              </div>
            </div>

            <div className="relative z-10 bg-secondary/80 backdrop-blur-sm p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Warehouse Overview</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Total Zones:</span>
                  <span className="ml-2 font-medium">12</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Capacity:</span>
                  <span className="ml-2 font-medium">85%</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Active Staff:</span>
                  <span className="ml-2 font-medium">24</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Today's Orders:</span>
                  <span className="ml-2 font-medium">{dashboardData?.pendingOrders || 0}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Low Stock Alerts */}
          <div className="bg-card rounded-xl p-6 border border-border flex flex-col box-glow">
            <h3 className="text-lg font-semibold mb-5 flex items-center">
              <i className="fas fa-exclamation-triangle text-[#f59e0b] mr-2"></i>
              Low Stock Alerts
            </h3>
            <div className="space-y-3 flex-1">
              <div className="flex justify-between items-center p-3 bg-secondary rounded-lg border-l-4 border-[#f59e0b]">
                <div>
                  <p className="font-medium text-sm">Cotton T-Shirts</p>
                  <p className="text-xs text-muted-foreground">Zone A-1 • SKU-84302</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-[#f59e0b]">23/50</p>
                  <p className="text-xs text-muted-foreground">units left</p>
                </div>
              </div>

              <div className="flex justify-between items-center p-3 bg-secondary rounded-lg border-l-4 border-[#ef4444]">
                <div>
                  <p className="font-medium text-sm">Face Serum</p>
                  <p className="text-xs text-muted-foreground">Zone D-1 • SKU-19943</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-[#ef4444]">8/40</p>
                  <p className="text-xs text-muted-foreground">units left</p>
                </div>
              </div>

              <div className="flex justify-between items-center p-3 bg-secondary rounded-lg border-l-4 border-[#f59e0b]">
                <div>
                  <p className="font-medium text-sm">Protein Powder</p>
                  <p className="text-xs text-muted-foreground">Zone C-1 • SKU-58321</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-[#f59e0b]">15/30</p>
                  <p className="text-xs text-muted-foreground">units left</p>
                </div>
              </div>

              <button
                onClick={() => navigate('/stock')}
                className="w-full mt-3 p-2 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg text-sm transition-colors"
              >
                View All Stock Levels
              </button>
            </div>
          </div>

          {/* Analytics Overview */}
          <div className="bg-card rounded-xl p-6 border border-border box-glow">
            <h3 className="text-lg font-semibold mb-5">Analytics Overview</h3>
            <div className="space-y-4">
              <div className="bg-secondary rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Demand Forecast</span>
                  <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">+12%</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: '75%' }}></div>
                </div>
              </div>
              
              <div className="bg-secondary rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Storage Utilization</span>
                  <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full">85%</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500 rounded-full" style={{ width: '85%' }}></div>
                </div>
              </div>
              
              <div className="bg-secondary rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Order Fulfillment</span>
                  <span className="text-xs px-2 py-1 bg-purple-100 text-purple-800 rounded-full">92%</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-purple-500 rounded-full" style={{ width: '92%' }}></div>
                </div>
              </div>
              
              <button
                onClick={() => navigate('/analytics')}
                className="w-full mt-2 p-2 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg text-sm transition-colors"
              >
                View Detailed Analytics
              </button>
            </div>
          </div>

          {/* Shipping Activities */}
          <div className="bg-card rounded-xl p-6 border border-border box-glow">
            <h3 className="text-lg font-semibold mb-5">Shipping Activities</h3>
            <div className="grid grid-cols-1 gap-4">
              <div className="bg-secondary rounded-lg p-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#10b981' }}></div>
                  <span className="text-sm">Ready</span>
                </div>
                <span className="text-xl font-bold">{shippingCounts.ready}</span>
              </div>
              <div className="bg-secondary rounded-lg p-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#3b82f6' }}></div>
                  <span className="text-sm">Preparing</span>
                </div>
                <span className="text-xl font-bold">{shippingCounts.prepared}</span>
              </div>
              <div className="bg-secondary rounded-lg p-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#ef4444' }}></div>
                  <span className="text-sm">Delayed</span>
                </div>
                <span className="text-xl font-bold">{shippingCounts.delayed}</span>
              </div>
            </div>
            <button
              onClick={() => navigate('/pending-shipments')}
              className="w-full mt-4 p-2 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg text-sm transition-colors"
            >
              View Pending Shipments
            </button>
          </div>

          {/* Workers Overview */}
          <div
            className="bg-card rounded-xl p-6 border border-border flex flex-col cursor-pointer hover:bg-card/80 transition-colors box-glow"
            onClick={() => navigate('/workers')}
            role="button"
            aria-label="Open Workers Management"
            tabIndex={0}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') navigate('/workers') }}
          >
            <h3 className="text-lg font-semibold mb-5 flex items-center">
              <i className="fas fa-users text-[#3b82f6] mr-2"></i>
              Workers Overview
            </h3>
            <div className="space-y-4 flex-1">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-secondary rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Workers</p>
                      <p className="text-2xl font-bold text-[#3b82f6]">
                        {workerStats?.totalWorkers ?? '—'}
                      </p>
                    </div>
                    <i className="fas fa-users text-2xl text-[#3b82f6]"></i>
                  </div>
                </div>
                <div className="bg-secondary rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active</p>
                      <p className="text-2xl font-bold text-[#22c55e]">
                        {workerStats?.activeWorkers ?? '—'}
                      </p>
                    </div>
                    <i className="fas fa-user-check text-2xl text-[#22c55e]"></i>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-[#22c55e] rounded-full"></div>
                    <span className="text-sm">Receiving Department</span>
                  </div>
                  <span className="text-sm font-medium">{workerStats?.byDepartment?.receiving ?? '—'} workers</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-[#f59e0b] rounded-full"></div>
                    <span className="text-sm">Shipping Department</span>
                  </div>
                  <span className="text-sm font-medium">{workerStats?.byDepartment?.shipping ?? '—'} workers</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-[#3b82f6] rounded-full"></div>
                    <span className="text-sm">Inventory Department</span>
                  </div>
                  <span className="text-sm font-medium">{workerStats?.byDepartment?.inventory ?? '—'} workers</span>
                </div>
              </div>

              <div className="w-full mt-3 p-2 bg-primary text-primary-foreground rounded-lg text-sm text-center">
                Manage Workers
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
