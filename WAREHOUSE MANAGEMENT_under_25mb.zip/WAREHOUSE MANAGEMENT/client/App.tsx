import "./global.css";
import { Toaster as ShadToaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation, Navigate } from "react-router-dom";
import { useEffect } from "react";
import { AuthProvider } from "./contexts/AuthContext";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { ProtectedRoute } from "./components/ProtectedRoute";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Unauthorized from "./pages/Unauthorized";
import Stock from "./pages/Stock";
import Orders from "./pages/Orders";
import Sellers from "./pages/Sellers";
import PendingShipments from "./pages/PendingShipments";
import Receiving from "./pages/Receiving";
import AddProduct from "./pages/AddProduct";
import Workers from "./pages/Workers";
import GenerateReport from "./pages/GenerateReport";
import NewOrder from "./pages/NewOrder";
import NotFound from "./pages/NotFound";
import Settings from "./pages/Settings";
import OrderDetails from "./pages/OrderDetails";
import Analytics from "./pages/Analytics";
import Inventory from "./pages/Inventory";
import CommandPalette from "@/components/CommandPalette";

// Initialize theme and accent from localStorage with support for system mode
(function initAppearance() {
  try {
    const root = document.documentElement;
    const applyTheme = (mode: string) => {
      const w = window as any;
      // clean previous listener if any
      if (w.__themeMql && w.__themeListener) {
        w.__themeMql.removeEventListener?.("change", w.__themeListener);
        w.__themeMql = null;
        w.__themeListener = null;
      }
      // Remove all theme classes
      root.classList.remove("dark", "midnight-ember");
      if (mode === "system") {
        const mql = window.matchMedia("(prefers-color-scheme: dark)");
        const set = () => {
          root.classList.remove("dark", "midnight-ember");
          if (mql.matches) root.classList.add("dark");
        };
        set();
        if (mql.addEventListener) {
          mql.addEventListener("change", set);
        } else if ((mql as any).addListener) {
          (mql as any).addListener(set);
        }
        w.__themeMql = mql;
        w.__themeListener = set;
      } else {
        if (mode === "dark") root.classList.add("dark");
        if (mode === "midnight-ember") root.classList.add("midnight-ember");
      }
    };

    const mode = localStorage.getItem("theme") || "dark";
    applyTheme(mode);

    const accent = localStorage.getItem("accent");
    if (accent) {
      root.style.setProperty("--primary", accent);
    }
  } catch {}
})();

const queryClient = new QueryClient();

const App = () => {
  // The useEffect and useRef for particles have been completely removed.

  // Global hover state for boxes (fallback for browsers without :has)
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      const hoveredBox = target?.closest(
        '.box-glow, [class*="rounded"][class*="border"][class*="bg-card"], [class*="rounded"][class*="bg-card"], [class*="rounded"][class*="bg-secondary"]'
      );
      if (hoveredBox) document.body.classList.add('any-box-hovered');
      else document.body.classList.remove('any-box-hovered');
    };
    window.addEventListener('mousemove', onMove, { passive: true });
    return () => window.removeEventListener('mousemove', onMove);
  }, []);

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <TooltipProvider>
            {/* No extra divs needed, the background is now handled by the body element in your CSS */}
            <ShadToaster />
            <Sonner />
            <BrowserRouter>
              <AnimatedRoutes />
              <CommandPalette />
            </BrowserRouter>
          </TooltipProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
};

const AnimatedRoutes = () => {
  const location = useLocation();
  
  return (
    <div key={location.pathname} className="scale-up-center-normal">
      <Routes location={location}>
        <Route path="/login" element={<Login />} />
        
        {/* Protected routes with role-based access */}
        <Route element={
          <ProtectedRoute>
            <Index />
          </ProtectedRoute>
        } path="/" />
        
        <Route element={
          <ProtectedRoute>
            <Stock />
          </ProtectedRoute>
        } path="/stock" />
        
        <Route element={
          <ProtectedRoute>
            <Orders />
          </ProtectedRoute>
        } path="/orders" />
        
        <Route element={
          <ProtectedRoute>
            <OrderDetails />
          </ProtectedRoute>
        } path="/orders/:id" />
        
        <Route element={
          <ProtectedRoute>
            <Sellers />
          </ProtectedRoute>
        } path="/sellers" />
        
        <Route element={
          <ProtectedRoute>
            <PendingShipments />
          </ProtectedRoute>
        } path="/pending-shipments" />
        
        <Route element={
          <ProtectedRoute>
            <Receiving />
          </ProtectedRoute>
        } path="/receiving" />
        
        {/* Owner and Manager only routes */}
        <Route element={
          <ProtectedRoute roles={['owner', 'manager']}>
            <AddProduct />
          </ProtectedRoute>
        } path="/add-product" />
        
        {/* Owner only routes */}
        <Route element={
          <ProtectedRoute roles={['owner']}>
            <GenerateReport />
          </ProtectedRoute>
        } path="/generate-report" />
        
        <Route element={
          <ProtectedRoute roles={['owner']}>
            <Workers />
          </ProtectedRoute>
        } path="/workers" />
        
        <Route element={
          <ProtectedRoute roles={['owner']}>
            <Analytics />
          </ProtectedRoute>
        } path="/analytics" />
        
        <Route element={
          <ProtectedRoute roles={['owner']}>
            <Inventory />
          </ProtectedRoute>
        } path="/inventory" />
        
        {/* Settings - accessible to all authenticated users */}
        <Route element={
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        } path="/settings" />
        
        {/* Error pages */}
        <Route path="/unauthorized" element={<Unauthorized />} />
        
        {/* Catch-all route */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
};

createRoot(document.getElementById("root")!).render(<App />);
