import { useState, useEffect } from 'react';
import { api, Product, Order, Customer, DashboardStats } from '../lib/api';

// Generic hook for API calls with explicit dependencies to avoid refetch on every render
export function useApi<T>(
  apiCall: () => Promise<{ success: boolean; data?: T; error?: string }>,
  deps: any[] = []
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async (showLoading: boolean = !data) => {
    if (showLoading) setLoading(true);
    setError(null);

    try {
      const response = await apiCall();
      if (response.success && response.data !== undefined) {
        setData(response.data);
      } else {
        setError(response.error || 'Failed to fetch data');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return { data, loading, error, refetch: () => fetchData(false) };
}

// Specific hooks for different data types
export function useProducts(filters?: { category?: string; status?: string; search?: string }) {
  const key = JSON.stringify(filters || {});
  return useApi(() => api.products.getAll(filters), [key]);
}

export function useOrders(filters?: { 
  status?: string; 
  priority?: string; 
  customerId?: string; 
  search?: string;
  page?: number;
  limit?: number;
}) {
  const key = JSON.stringify(filters || {});
  return useApi(() => api.orders.getAll(filters), [key]);
}

export function useCustomers() {
  return useApi(() => api.customers.getAll(), []);
}

export function useDashboard() {
  return useApi(() => api.dashboard.getStats(), []);
}

// Hook for creating products
export function useCreateProduct() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createProduct = async (productData: Omit<Product, 'id' | 'lastUpdated' | 'currency'>) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.products.create(productData);
      if (!response.success) {
        throw new Error(response.error || 'Failed to create product');
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { createProduct, loading, error };
}

// Hook for updating products
export function useUpdateProduct() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateProduct = async (id: string, productData: Partial<Product>) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.products.update(id, productData);
      if (!response.success) {
        throw new Error(response.error || 'Failed to update product');
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { updateProduct, loading, error };
}

// Hook for deleting products
export function useDeleteProduct() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const deleteProduct = async (id: string) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.products.delete(id);
      if (!response.success) {
        throw new Error(response.error || 'Failed to delete product');
      }
      return response;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { deleteProduct, loading, error };
}

// Hook for updating product stock
export function useUpdateStock() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateStock = async (id: string, stockData: { stock: number; minStock?: number; reason?: string }) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.products.updateStock(id, stockData);
      if (!response.success) {
        throw new Error(response.error || 'Failed to update stock');
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { updateStock, loading, error };
}

// Hook for bulk operations
export function useBulkOperations() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const bulkDelete = async (ids: string[]) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.products.bulkDelete(ids);
      if (!response.success) {
        throw new Error(response.error || 'Failed to bulk delete products');
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const bulkUpdate = async (updates: { id: string; changes: Partial<Product> }[]) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.products.bulkUpdate(updates);
      if (!response.success) {
        throw new Error(response.error || 'Failed to bulk update products');
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { bulkDelete, bulkUpdate, loading, error };
}

// Hook for product statistics
export function useProductStats() {
  return useApi(() => api.products.getStats());
}

// Order management hooks
export function useOrderStats() {
  return useApi(() => api.orders.getStats());
}

export function useCreateOrder() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createOrder = async (orderData: {
    customerId: string;
    items: { productId: string; quantity: number }[];
    priority: 'low' | 'medium' | 'high';
    deliveryDate: string;
    shippingAddress: {
      street: string;
      city: string;
      state: string;
      pincode: string;
      country: string;
    };
    notes?: string;
  }) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.orders.create(orderData);
      if (!response.success) {
        throw new Error(response.error || 'Failed to create order');
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { createOrder, loading, error };
}

export function useUpdateOrder() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateOrder = async (id: string, orderData: {
    status?: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled';
    priority?: 'low' | 'medium' | 'high';
    deliveryDate?: string;
    trackingNumber?: string;
    notes?: string;
  }) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.orders.update(id, orderData);
      if (!response.success) {
        throw new Error(response.error || 'Failed to update order');
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { updateOrder, loading, error };
}

export function useUpdateOrderStatus() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateStatus = async (id: string, status: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled') => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.orders.updateStatus(id, status);
      if (!response.success) {
        throw new Error(response.error || 'Failed to update order status');
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { updateStatus, loading, error };
}

export function useDeleteOrder() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const deleteOrder = async (id: string) => {
    setLoading(true);
    setError(null);

    try {
      const response = await api.orders.delete(id);
      if (!response.success) {
        throw new Error(response.error || 'Failed to delete order');
      }
      return response;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { deleteOrder, loading, error };
}
