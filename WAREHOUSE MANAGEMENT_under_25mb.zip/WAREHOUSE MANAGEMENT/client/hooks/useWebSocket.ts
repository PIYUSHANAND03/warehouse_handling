import { useEffect, useState, useCallback, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { toast } from './use-toast';

interface InventoryUpdate {
  productId: string;
  name: string;
  oldStock: number;
  newStock: number;
  location: string;
  timestamp: string;
  changeType: 'addition' | 'reduction' | 'adjustment';
}

interface OrderUpdate {
  orderId: string;
  customerId: string;
  customerName: string;
  status: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled';
  previousStatus?: string;
  timestamp: string;
}

interface ActivityUpdate {
  user: string;
  activity: string;
  location: string;
  timestamp: string;
}

interface StatsUpdate {
  activeUsers: number;
  totalOrders: number;
  pendingShipments: number;
  lowStockItems: number;
  timestamp: string;
}

interface NotificationData {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: string;
  userId?: string;
}

interface UseWebSocketReturn {
  // Connection status
  isConnected: boolean;
  connectionId: string | null;
  
  // Real-time data
  inventoryUpdates: InventoryUpdate[];
  orderUpdates: OrderUpdate[];
  recentActivities: ActivityUpdate[];
  liveStats: StatsUpdate | null;
  activeUsers: number;
  
  // Methods to send data
  sendInventoryUpdate: (update: Partial<InventoryUpdate>) => void;
  sendOrderUpdate: (update: Partial<OrderUpdate>) => void;
  trackActivity: (action: string, page: string) => void;
  sendNotification: (notification: Omit<NotificationData, 'id' | 'timestamp'>) => void;
  
  // Connection methods
  connect: () => void;
  disconnect: () => void;
}

export const useWebSocket = (
  serverUrl?: string,
  userName: string = 'Anonymous User'
): UseWebSocketReturn => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionId, setConnectionId] = useState<string | null>(null);
  const [activeUsers, setActiveUsers] = useState(0);
  
  // Real-time data states
  const [inventoryUpdates, setInventoryUpdates] = useState<InventoryUpdate[]>([]);
  const [orderUpdates, setOrderUpdates] = useState<OrderUpdate[]>([]);
  const [recentActivities, setRecentActivities] = useState<ActivityUpdate[]>([]);
  const [liveStats, setLiveStats] = useState<StatsUpdate | null>(null);
  
  const socketRef = useRef<Socket | null>(null);

  // Resolve socket URL: env > prop > default 3000
  const resolvedUrl = serverUrl ?? ((typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SOCKET_URL) || 'http://localhost:3000');
  
  // Feature flag: allow disabling real-time via env
  const realtimeEnv = String(((typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_ENABLE_REALTIME) ?? 'true')).toLowerCase();
  const realtimeEnabled = !['false', '0', 'no', 'off'].includes(realtimeEnv);

  // Connect to WebSocket
  const connect = useCallback(() => {
    if (!realtimeEnabled) return;
    if (socketRef.current?.connected) return;

    const newSocket = io(resolvedUrl);
    socketRef.current = newSocket;
    setSocket(newSocket);

    // Connection handlers
    newSocket.on('connect', () => {
      setIsConnected(true);
      console.log('Connected to WebSocket server');
      
      // Join with user info
      newSocket.emit('user:join', {
        name: userName,
        joinTime: new Date().toISOString()
      });
      
      toast({
        title: "Connected",
        description: "Real-time updates are now active!",
      });
    });

    newSocket.on('connection:confirmed', (data) => {
      setConnectionId(data.socketId);
    });

    newSocket.on('disconnect', () => {
      setIsConnected(false);
      setConnectionId(null);
      console.log('Disconnected from WebSocket server');
      
      toast({
        title: "Disconnected",
        description: "Real-time updates are paused.",
        variant: "destructive"
      });
    });

    // Data handlers
    newSocket.on('inventory:updated', (update: InventoryUpdate) => {
      setInventoryUpdates(prev => {
        const newUpdates = [update, ...prev].slice(0, 50); // Keep last 50 updates
        return newUpdates;
      });
      
      toast({
        title: "Inventory Updated",
        description: `${update.name} stock changed from ${update.oldStock} to ${update.newStock}`,
      });
    });

    newSocket.on('order:status-changed', (update: OrderUpdate) => {
      setOrderUpdates(prev => {
        const newUpdates = [update, ...prev].slice(0, 50); // Keep last 50 updates
        return newUpdates;
      });
      
      toast({
        title: "Order Status Changed",
        description: `Order ${update.orderId} is now ${update.status}`,
      });
    });

    newSocket.on('activity:update', (activity: ActivityUpdate) => {
      setRecentActivities(prev => {
        const newActivities = [activity, ...prev].slice(0, 20); // Keep last 20 activities
        return newActivities;
      });
    });

    newSocket.on('users:count', (count: number) => {
      setActiveUsers(count);
    });

    newSocket.on('stats:updated', (stats: StatsUpdate) => {
      setLiveStats(stats);
    });

    newSocket.on('notification:received', (notification: NotificationData) => {
      toast({
        title: notification.title,
        description: notification.message,
        variant: notification.type === 'error' ? 'destructive' : 'default',
      });
    });

    // Error handling
    newSocket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error);
      toast({
        title: "Connection Error",
        description: "Failed to connect to real-time server",
        variant: "destructive"
      });
    });

  }, [serverUrl, userName]);

  // Disconnect from WebSocket
  const disconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
      setSocket(null);
      setIsConnected(false);
      setConnectionId(null);
    }
  }, []);

  // Send inventory update
  const sendInventoryUpdate = useCallback((update: Partial<InventoryUpdate>) => {
    if (socket?.connected) {
      const fullUpdate: InventoryUpdate = {
        productId: update.productId || `PROD-${Date.now()}`,
        name: update.name || 'Unknown Product',
        oldStock: update.oldStock || 0,
        newStock: update.newStock || 0,
        location: update.location || 'Unknown Location',
        timestamp: new Date().toISOString(),
        changeType: update.changeType || 'adjustment'
      };
      
      socket.emit('inventory:update', fullUpdate);
    }
  }, [socket]);

  // Send order update
  const sendOrderUpdate = useCallback((update: Partial<OrderUpdate>) => {
    if (socket?.connected) {
      const fullUpdate: OrderUpdate = {
        orderId: update.orderId || `ORD-${Date.now()}`,
        customerId: update.customerId || `CUST-${Date.now()}`,
        customerName: update.customerName || 'Unknown Customer',
        status: update.status || 'pending',
        timestamp: new Date().toISOString(),
        previousStatus: update.previousStatus
      };
      
      socket.emit('order:status-change', fullUpdate);
    }
  }, [socket]);

  // Track user activity
  const trackActivity = useCallback((action: string, page: string) => {
    if (socket?.connected) {
      socket.emit('user:activity', {
        action,
        page,
        timestamp: new Date().toISOString()
      });
    }
  }, [socket]);

  // Send notification
  const sendNotification = useCallback((notification: Omit<NotificationData, 'id' | 'timestamp'>) => {
    if (socket?.connected) {
      const fullNotification: NotificationData = {
        ...notification,
        id: `notif-${Date.now()}`,
        timestamp: new Date().toISOString()
      };
      
      socket.emit('notification:send', fullNotification);
    }
  }, [socket]);

  // Auto-connect on mount
  useEffect(() => {
    connect();
    
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  // Track page activities automatically
  useEffect(() => {
    const currentPage = window.location.pathname;
    trackActivity('page_visit', currentPage);
  }, [trackActivity]);

  return {
    // Connection status
    isConnected,
    connectionId,
    
    // Real-time data
    inventoryUpdates,
    orderUpdates,
    recentActivities,
    liveStats,
    activeUsers,
    
    // Methods
    sendInventoryUpdate,
    sendOrderUpdate,
    trackActivity,
    sendNotification,
    connect,
    disconnect
  };
};