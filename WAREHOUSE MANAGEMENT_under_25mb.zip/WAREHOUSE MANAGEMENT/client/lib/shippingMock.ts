// Shared mock shipping data and stats helper

export const shipmentsData = [
  {
    id: "SHIP-001",
    orderId: "ORD-1234",
    customerName: "Fashion Boutique",
    customerEmail: "orders@fashionboutique.com",
    customerPhone: "+91 98765-43210",
    destination: "Mumbai, Maharashtra",
    pickupAddress: "Warehouse A-1, Industrial Area",
    items: [
      { name: "Cotton T-Shirts", quantity: 50, weight: "25kg" },
      { name: "Denim Jeans", quantity: 30, weight: "18kg" }
    ],
    totalWeight: "43kg",
    totalValue: "₹45,000",
    status: "ready",
    priority: "high",
    scheduledDate: "2024-01-16",
    carrier: "Express Logistics",
    trackingNumber: "EL123456789",
    estimatedDelivery: "2024-01-18",
    createdDate: "2024-01-15"
  },
  {
    id: "SHIP-002",
    orderId: "ORD-1235",
    customerName: "TechWorld Store",
    customerEmail: "shipping@techworld.com",
    customerPhone: "+91 87654-32109",
    destination: "Bangalore, Karnataka",
    pickupAddress: "Warehouse B-2, Tech Park",
    items: [
      { name: "Wireless Earbuds", quantity: 25, weight: "5kg" },
      { name: "Smart Watches", quantity: 15, weight: "8kg" }
    ],
    totalWeight: "13kg",
    totalValue: "₹75,000",
    status: "preparing",
    priority: "medium",
    scheduledDate: "2024-01-17",
    carrier: "Swift Delivery",
    trackingNumber: "SD987654321",
    estimatedDelivery: "2024-01-19",
    createdDate: "2024-01-15"
  },
  {
    id: "SHIP-003",
    orderId: "ORD-1236",
    customerName: "Luxury Accessories",
    customerEmail: "orders@luxuryacc.com",
    customerPhone: "+91 76543-21098",
    destination: "Delhi, Delhi",
    pickupAddress: "Warehouse C-3, Craft Zone",
    items: [
      { name: "Leather Wallets", quantity: 100, weight: "20kg" },
      { name: "Designer Belts", quantity: 50, weight: "15kg" }
    ],
    totalWeight: "35kg",
    totalValue: "₹89,500",
    status: "ready",
    priority: "high",
    scheduledDate: "2024-01-16",
    carrier: "Premium Logistics",
    trackingNumber: "PL456789123",
    estimatedDelivery: "2024-01-17",
    createdDate: "2024-01-14"
  },
  {
    id: "SHIP-004",
    orderId: "ORD-1237",
    customerName: "Home & Garden",
    customerEmail: "dispatch@homeandgarden.com",
    customerPhone: "+91 65432-10987",
    destination: "Pune, Maharashtra",
    pickupAddress: "Warehouse D-1, Industrial Complex",
    items: [
      { name: "Ceramic Vases", quantity: 40, weight: "30kg" },
      { name: "Decorative Lights", quantity: 60, weight: "12kg" }
    ],
    totalWeight: "42kg",
    totalValue: "₹32,000",
    status: "delayed",
    priority: "low",
    scheduledDate: "2024-01-15",
    carrier: "City Express",
    trackingNumber: "CE789123456",
    estimatedDelivery: "2024-01-18",
    createdDate: "2024-01-13"
  },
  {
    id: "SHIP-005",
    orderId: "ORD-1238",
    customerName: "Sports Equipment Co",
    customerEmail: "shipping@sportsequip.com",
    customerPhone: "+91 54321-09876",
    destination: "Chennai, Tamil Nadu",
    pickupAddress: "Warehouse E-2, Sports Complex",
    items: [
      { name: "Yoga Mats", quantity: 80, weight: "40kg" },
      { name: "Dumbbells", quantity: 20, weight: "100kg" }
    ],
    totalWeight: "140kg",
    totalValue: "₹95,000",
    status: "preparing",
    priority: "medium",
    scheduledDate: "2024-01-18",
    carrier: "Heavy Freight",
    trackingNumber: "HF234567890",
    estimatedDelivery: "2024-01-20",
    createdDate: "2024-01-15"
  }
];

export function computeShipmentStats(data: any[] = shipmentsData) {
  const parseCurrency = (val: string) => parseInt(val.replace('₹', '').replace(/,/g, '')) || 0;
  const parseKg = (val: string) => parseInt(val.replace('kg', '')) || 0;
  return {
    total: data.length,
    ready: data.filter((s) => s.status === 'ready').length,
    preparing: data.filter((s) => s.status === 'preparing').length,
    delayed: data.filter((s) => s.status === 'delayed').length,
    totalValue: data.reduce((sum, s) => sum + parseCurrency(s.totalValue), 0),
    totalWeight: data.reduce((sum, s) => sum + parseKg(s.totalWeight), 0),
  };
}