// Application Constants

export const APP_NAME = 'invenTREE';
export const APP_DESCRIPTION = 'Where inventory grows in order';

// API Configuration
export const API_TIMEOUT = 30000; // 30 seconds
export const API_RETRY_ATTEMPTS = 3;

// Pagination
export const DEFAULT_PAGE_SIZE = 10;
export const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

// Status Options
export const PRODUCT_STATUSES = ['in-stock', 'low-stock', 'out-of-stock'] as const;
export const ORDER_STATUSES = ['pending', 'processing', 'shipped', 'completed', 'cancelled'] as const;
export const ORDER_PRIORITIES = ['low', 'medium', 'high'] as const;
export const SHIPMENT_STATUSES = ['pending', 'in-transit', 'delivered', 'returned'] as const;
export const WORKER_STATUSES = ['active', 'inactive', 'on-leave'] as const;

// Roles and Departments
export const WORKER_ROLES = ['manager', 'supervisor', 'worker', 'picker', 'packer', 'loader'] as const;
export const WORKER_DEPARTMENTS = ['receiving', 'picking', 'packing', 'shipping', 'inventory', 'administration'] as const;
export const WORKER_SHIFTS = ['morning', 'afternoon', 'night'] as const;

// Customer Types
export const CUSTOMER_TYPES = ['business', 'individual'] as const;

// Categories (can be extended)
export const PRODUCT_CATEGORIES = [
  'Clothes',
  'Electronics',
  'Accessories',
  'Sports',
  'Beauty',
  'Home Decor',
  'Food & Beverages',
  'Books',
  'Toys',
  'Health',
] as const;

// Carriers
export const SHIPPING_CARRIERS = [
  'FedEx',
  'UPS',
  'DHL',
  'USPS',
  'Blue Dart',
  'Delhivery',
  'India Post',
  'Aramex',
] as const;

// Date Formats
export const DATE_FORMAT = 'yyyy-MM-dd';
export const DATETIME_FORMAT = 'yyyy-MM-dd HH:mm:ss';
export const DISPLAY_DATE_FORMAT = 'MMM dd, yyyy';
export const DISPLAY_DATETIME_FORMAT = 'MMM dd, yyyy HH:mm';

// Currency
export const DEFAULT_CURRENCY = '₹';
export const SUPPORTED_CURRENCIES = ['₹', '$', '€', '£'] as const;

// Validation
export const MIN_STOCK_THRESHOLD = 10;
export const MAX_PRODUCT_NAME_LENGTH = 100;
export const MAX_DESCRIPTION_LENGTH = 500;
export const MIN_PASSWORD_LENGTH = 8;
export const PHONE_REGEX = /^\+?[\d\s-()]+$/;
export const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// File Upload
export const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const ALLOWED_DOCUMENT_TYPES = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

// Local Storage Keys
export const STORAGE_KEYS = {
  THEME: 'theme',
  ACCENT: 'accent',
  USER: 'user',
  AUTH_TOKEN: 'auth_token',
  SIDEBAR_COLLAPSED: 'sidebar_collapsed',
  RECENT_SEARCHES: 'recent_searches',
  PREFERENCES: 'user_preferences',
} as const;

// Toast Duration
export const TOAST_DURATION = 3000; // 3 seconds

// Debounce Delays
export const SEARCH_DEBOUNCE_DELAY = 300;
export const INPUT_DEBOUNCE_DELAY = 500;

// Chart Colors
export const CHART_COLORS = {
  primary: '#3b82f6',
  success: '#22c55e',
  warning: '#f59e0b',
  danger: '#ef4444',
  info: '#06b6d4',
  purple: '#8b5cf6',
  pink: '#ec4899',
  orange: '#f97316',
} as const;

// Status Colors
export const STATUS_COLORS = {
  'in-stock': '#22c55e',
  'low-stock': '#f59e0b',
  'out-of-stock': '#ef4444',
  'pending': '#f59e0b',
  'processing': '#3b82f6',
  'shipped': '#06b6d4',
  'completed': '#22c55e',
  'cancelled': '#ef4444',
  'in-transit': '#3b82f6',
  'delivered': '#22c55e',
  'returned': '#ef4444',
  'active': '#22c55e',
  'inactive': '#6b7280',
  'on-leave': '#f59e0b',
} as const;

// Priority Colors
export const PRIORITY_COLORS = {
  low: '#22c55e',
  medium: '#f59e0b',
  high: '#ef4444',
} as const;

// Report Types
export const REPORT_TYPES = [
  'inventory',
  'sales',
  'low-stock',
  'customer',
  'financial',
  'worker-performance',
  'shipment-tracking',
] as const;

// Export Formats
export const EXPORT_FORMATS = ['csv', 'json', 'pdf', 'excel'] as const;

// Notification Types
export const NOTIFICATION_TYPES = ['info', 'success', 'warning', 'error'] as const;

// WebSocket Events
export const WS_EVENTS = {
  CONNECT: 'connect',
  DISCONNECT: 'disconnect',
  INVENTORY_UPDATE: 'inventory:updated',
  ORDER_UPDATE: 'order:status-changed',
  SHIPMENT_UPDATE: 'shipment:status-changed',
  USER_ACTIVITY: 'activity:update',
  STATS_UPDATE: 'stats:updated',
  NOTIFICATION: 'notification:received',
} as const;

// Feature Flags
export const FEATURES = {
  REAL_TIME_UPDATES: true,
  ADVANCED_ANALYTICS: true,
  BULK_OPERATIONS: true,
  EXPORT_DATA: true,
  BARCODE_SCANNING: false, // Future feature
  MOBILE_APP: false, // Future feature
  EMAIL_NOTIFICATIONS: false, // Requires configuration
  SMS_NOTIFICATIONS: false, // Requires configuration
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network error. Please check your connection.',
  SERVER_ERROR: 'Server error. Please try again later.',
  VALIDATION_ERROR: 'Please check your input and try again.',
  UNAUTHORIZED: 'You are not authorized to perform this action.',
  NOT_FOUND: 'The requested resource was not found.',
  TIMEOUT: 'Request timed out. Please try again.',
  UNKNOWN: 'An unknown error occurred.',
} as const;

// Success Messages
export const SUCCESS_MESSAGES = {
  CREATED: 'Created successfully!',
  UPDATED: 'Updated successfully!',
  DELETED: 'Deleted successfully!',
  SAVED: 'Saved successfully!',
  EXPORTED: 'Exported successfully!',
} as const;
