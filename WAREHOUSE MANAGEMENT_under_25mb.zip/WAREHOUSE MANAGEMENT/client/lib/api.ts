// API Base Configuration
// Use same-origin by default (works with Vite+Express single-port dev and production)
// Allow override via VITE_API_BASE_URL when needed.
const API_BASE_URL = (typeof window !== 'undefined' && (window as any).__API_BASE_URL__)
  || (import.meta as any)?.env?.VITE_API_BASE_URL
  || 'https://backend-11-se7z.onrender.com/api'; // Fallback for testing

import { UserProfile, Invoice } from '@shared/api';

// Re-export shared types for client use
export type { Invoice };

// Types for API responses
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  total?: number;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  stock: number;
  minStock: number;
  price: number;
  currency: string;
  status: 'in-stock' | 'low-stock' | 'out-of-stock';
  location: string;
  supplier: string;
  lastUpdated: string;
  sku?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  type: 'business' | 'individual';
  registrationDate: string;
  lastOrderDate?: string;
  totalOrders: number;
  totalValue: number;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export interface Order {
  id: string;
  customer: Customer;
  items: OrderItem[];
  totalItems: number;
  totalValue: number;
  status: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  orderDate: string;
  deliveryDate: string;
  shippingAddress: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  trackingNumber?: string;
  notes?: string;
  shipments?: any[];
}

export interface Worker {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'manager' | 'supervisor' | 'worker' | 'picker' | 'packer' | 'loader';
  department: 'receiving' | 'picking' | 'packing' | 'shipping' | 'inventory' | 'administration';
  status: 'active' | 'inactive' | 'on-leave';
  hireDate: string;
  shift: 'morning' | 'afternoon' | 'night';
  hourlyRate: number;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  emergencyContact?: {
    name: string;
    phone: string;
    relationship: string;
  };
  skills?: string[];
  performanceRating?: number;
  lastActive?: string;
}

export interface Inbound {
  id: string;
  vendor: string;
  eta: string; // YYYY-MM-DD HH:mm or date string
  location: string; // Dock
  cartons: number;
  items: number;
  status: 'arrived' | 'in-progress' | 'qc-hold' | 'received';
  notes?: string;
}

export interface DashboardStats {
  totalProducts: number;
  lowStockItems: number;
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  totalRevenue: number;
  recentActivities: Array<{
    id: string;
    location: string;
    status: string;
    statusColor: string;
    timestamp: string;
    type: 'stock' | 'order' | 'shipment';
  }>;
}

// Generic API call function
async function apiCall<T>(endpoint: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('API call failed:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

// Helper to download a file response (blob) and trigger browser save
async function downloadFile(endpoint: string, filename: string, options: RequestInit = {}) {
  const res = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
  });
  if (!res.ok) throw new Error(`Failed to download: ${res.status}`);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// Products API
export const productsApi = {
  // Get all products
  getAll: (filters?: { category?: string; status?: string; search?: string }): Promise<ApiResponse<Product[]>> => {
    const params = new URLSearchParams();
    if (filters?.category) params.append('category', filters.category);
    if (filters?.status) params.append('status', filters.status);
    if (filters?.search) params.append('search', filters.search);
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiCall<Product[]>(`/products${query}`);
  },

  // Get single product
  getById: (id: string): Promise<ApiResponse<Product>> => 
    apiCall<Product>(`/products/${id}`),

  // Create product
  create: (productData: Omit<Product, 'id' | 'lastUpdated' | 'currency'>): Promise<ApiResponse<Product>> => 
    apiCall<Product>('/products', {
      method: 'POST',
      body: JSON.stringify(productData),
    }),

  // Update product
  update: (id: string, productData: Partial<Product>): Promise<ApiResponse<Product>> => 
    apiCall<Product>(`/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(productData),
    }),

  // Delete product
  delete: (id: string): Promise<ApiResponse<void>> => 
    apiCall<void>(`/products/${id}`, {
      method: 'DELETE',
    }),

  // Update stock only (server requires { stock, operation })
  updateStock: (
    id: string,
    stockData: { stock: number; operation?: 'add' | 'subtract' }
  ): Promise<ApiResponse<Product>> =>
    apiCall<Product>(`/products/${id}/stock`, {
      method: 'PATCH',
      body: JSON.stringify({
        stock: stockData.stock,
        operation: stockData.operation, // optional: pass to add/subtract relative
      }),
    }),

  // Bulk delete products
  bulkDelete: (ids: string[]): Promise<ApiResponse<{ deleted: number }>> => 
    apiCall<{ deleted: number }>('/products/bulk/delete', {
      method: 'DELETE',
      body: JSON.stringify({ ids }),
    }),

  // Bulk update products
  bulkUpdate: (updates: { id: string; changes: Partial<Product> }[]): Promise<ApiResponse<{ updated: number }>> => 
    apiCall<{ updated: number }>('/products/bulk/update', {
      method: 'PATCH',
      body: JSON.stringify({ updates }),
    }),

  // Get product statistics (server shape)
  getStats: (): Promise<ApiResponse<{
    totalProducts: number;
    inStock: number;
    lowStock: number;
    outOfStock: number;
    totalValue: number;
    categories: string[];
    averagePrice: number;
  }>> =>
    apiCall('/products/stats/summary'),

  // Search products
  search: (term: string): Promise<ApiResponse<Product[]>> => 
    apiCall<Product[]>(`/products?search=${encodeURIComponent(term)}`),

  // Get low stock products
  getLowStock: (): Promise<ApiResponse<Product[]>> => 
    apiCall<Product[]>('/products?status=low-stock'),

  // Get out of stock products  
  getOutOfStock: (): Promise<ApiResponse<Product[]>> => 
    apiCall<Product[]>('/products?status=out-of-stock'),
};

// Orders API
export const ordersApi = {
  // Get all orders with filtering
  getAll: (filters?: { 
    status?: string; 
    priority?: string; 
    customerId?: string; 
    search?: string;
    page?: number;
    limit?: number;
  }): Promise<ApiResponse<Order[]>> => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.priority) params.append('priority', filters.priority);
    if (filters?.customerId) params.append('customerId', filters.customerId);
    if (filters?.search) params.append('search', filters.search);
    if (filters?.page) params.append('page', filters.page.toString());
    if (filters?.limit) params.append('limit', filters.limit.toString());
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiCall<Order[]>(`/orders${query}`);
  },

  // Get single order
  getById: (id: string): Promise<ApiResponse<Order>> => 
    apiCall<Order>(`/orders/${id}`),

  // Create order
  create: (orderData: {
    customerId: string;
    items: { productId: string; quantity: number }[];
    priority: 'low' | 'medium' | 'high';
    deliveryDate: string;
    shippingAddress: {
      street: string;
      city: string;
      state: string;
      pincode: string;
      country: string;
    };
    billingAddress?: {
      street: string;
      city: string;
      state: string;
      pincode: string;
      country: string;
    };
    notes?: string;
    specialInstructions?: string;
    paymentMethod?: string;
    paymentTerms?: string;
    shippingMethod?: string;
    orderSource?: string;
    gstNumber?: string;
    discount?: {
      type: 'percentage' | 'fixed';
      value: number;
    };
    assignedWorker?: string;
    expectedDeliveryTime?: string;
  }): Promise<ApiResponse<Order>> =>
    apiCall<Order>('/orders', {
      method: 'POST',
      body: JSON.stringify(orderData),
    }),

  // Update order
  update: (id: string, orderData: {
    status?: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled';
    priority?: 'low' | 'medium' | 'high';
    deliveryDate?: string;
    trackingNumber?: string;
    notes?: string;
  }): Promise<ApiResponse<Order>> => 
    apiCall<Order>(`/orders/${id}`, {
      method: 'PUT',
      body: JSON.stringify(orderData),
    }),

  // Delete order
  delete: (id: string): Promise<ApiResponse<void>> => 
    apiCall<void>(`/orders/${id}`, {
      method: 'DELETE',
    }),

  // Update order status
  updateStatus: (id: string, status: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled'): Promise<ApiResponse<Order>> => 
    apiCall<Order>(`/orders/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  // Get orders by customer
  getByCustomer: (customerId: string): Promise<ApiResponse<Order[]>> => 
    apiCall<Order[]>(`/orders/customer/${customerId}`),

  // Get order statistics
  getStats: (): Promise<ApiResponse<{
    totalOrders: number;
    pending: number;
    processing: number;
    shipped: number;
    completed: number;
    cancelled: number;
    totalValue: number;
    completedValue: number;
    averageOrderValue: number;
    highPriorityOrders: number;
  }>> => 
    apiCall('/orders/stats/summary'),

  // Get invoice for order
  getInvoice: (id: string): Promise<ApiResponse<Invoice>> => apiCall<Invoice>(`/orders/${id}/invoice`),

  // Download invoice
  downloadInvoice: (id: string, format: 'pdf' | 'html' | 'csv' | 'excel' = 'pdf') => {
    const ext = format === 'excel' ? 'csv' : format;
    const query = format ? `?format=${format}` : '';
    return downloadFile(`/orders/${id}/invoice/download${query}`, `invoice-${id}.${ext}`);
  },
};

// Shipments API
export const shipmentsApi = {
  // Get all shipments with optional filters and pagination
  getAll: (filters?: {
    status?: string;
    carrier?: string;
    orderId?: string;
    search?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }): Promise<ApiResponse<any[]>> => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.carrier) params.append('carrier', filters.carrier);
    if (filters?.orderId) params.append('orderId', filters.orderId);
    if (filters?.search) params.append('search', filters.search);
    if (filters?.page) params.append('page', String(filters.page));
    if (filters?.limit) params.append('limit', String(filters.limit));
    if (filters?.sortBy) params.append('sortBy', filters.sortBy);
    if (filters?.sortOrder) params.append('sortOrder', filters.sortOrder);
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiCall<any[]>(`/shipments${query}`);
  },

  // Get single shipment
  getById: (id: string): Promise<ApiResponse<any>> => apiCall<any>(`/shipments/${id}`),

  // Create shipment
  create: (payload: any): Promise<ApiResponse<any>> =>
    apiCall<any>(`/shipments`, { method: 'POST', body: JSON.stringify(payload) }),

  // Update shipment (PUT)
  update: (id: string, changes: any): Promise<ApiResponse<any>> =>
    apiCall<any>(`/shipments/${id}`, { method: 'PUT', body: JSON.stringify(changes) }),

  // Update shipment status (PATCH)
  updateStatus: (id: string, status: 'pending' | 'in-transit' | 'delivered' | 'returned'): Promise<ApiResponse<any>> =>
    apiCall<any>(`/shipments/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),

  // Delete shipment
  delete: (id: string): Promise<ApiResponse<void>> =>
    apiCall<void>(`/shipments/${id}`, { method: 'DELETE' }),

  // Get shipments summary stats
  getStatsSummary: (): Promise<ApiResponse<{
    totalShipments: number;
    pending: number;
    inTransit: number;
    delivered: number;
    returned: number;
    totalShippingCost: number;
    averageShippingCost: number;
    onTimeDeliveries: number;
    carrierBreakdown: Record<string, number>;
  }>> => apiCall('/shipments/stats/summary'),

  // Get pending shipments (pending or in-transit sorted by ETA)
  getPending: (): Promise<ApiResponse<any[]>> => apiCall('/shipments/pending'),
};

// Customers API
export const customersApi = {
  // Get all customers with optional filters and pagination
  getAll: (filters?: {
    type?: 'business' | 'individual';
    search?: string;
    city?: string;
    state?: string;
    sortBy?: 'name' | 'registrationDate' | 'totalOrders' | 'totalValue';
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
  }): Promise<ApiResponse<Customer[]>> => {
    const params = new URLSearchParams();
    if (filters?.type) params.append('type', filters.type);
    if (filters?.search) params.append('search', filters.search);
    if (filters?.city) params.append('city', filters.city);
    if (filters?.state) params.append('state', filters.state);
    if (filters?.sortBy) params.append('sortBy', filters.sortBy);
    if (filters?.sortOrder) params.append('sortOrder', filters.sortOrder);
    if (filters?.page) params.append('page', String(filters.page));
    if (filters?.limit) params.append('limit', String(filters.limit));
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiCall<Customer[]>(`/customers${query}`);
  },

  // Get single customer
  getById: (id: string): Promise<ApiResponse<Customer>> => 
    apiCall<Customer>(`/customers/${id}`),

  // Search customers
  search: (term: string): Promise<ApiResponse<Customer[]>> =>
    apiCall<Customer[]>(`/customers/search/${encodeURIComponent(term)}`),

  // Customers stats summary
  getStatsSummary: (): Promise<ApiResponse<any>> =>
    apiCall(`/customers/stats/summary`),
};

// Workers API
export const workersApi = {
  getAll: (filters?: {
    page?: number;
    limit?: number;
    department?: Worker['department'];
    role?: Worker['role'];
    status?: Worker['status'];
    shift?: Worker['shift'];
    search?: string;
    minHourlyRate?: number;
    maxHourlyRate?: number;
    sortBy?: 'name' | 'hireDate' | 'hourlyRate';
    sortOrder?: 'asc' | 'desc';
  }): Promise<ApiResponse<Worker[]>> => {
    const params = new URLSearchParams();
    if (filters?.page) params.append('page', String(filters.page));
    if (filters?.limit) params.append('limit', String(filters.limit));
    if (filters?.department) params.append('department', filters.department);
    if (filters?.role) params.append('role', filters.role);
    if (filters?.status) params.append('status', filters.status);
    if (filters?.shift) params.append('shift', filters.shift);
    if (filters?.search) params.append('search', filters.search);
    if (typeof filters?.minHourlyRate === 'number') params.append('minHourlyRate', String(filters.minHourlyRate));
    if (typeof filters?.maxHourlyRate === 'number') params.append('maxHourlyRate', String(filters.maxHourlyRate));
    if (filters?.sortBy) params.append('sortBy', filters.sortBy);
    if (filters?.sortOrder) params.append('sortOrder', filters.sortOrder);
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiCall<Worker[]>(`/workers${query}`);
  },
  getById: (id: string): Promise<ApiResponse<Worker>> => apiCall<Worker>(`/workers/${id}`),
  create: (payload: Omit<Worker, 'id'>): Promise<ApiResponse<Worker>> =>
    apiCall<Worker>(`/workers`, { method: 'POST', body: JSON.stringify(payload) }),
  update: (id: string, changes: Partial<Worker>): Promise<ApiResponse<Worker>> =>
    apiCall<Worker>(`/workers/${id}`, { method: 'PUT', body: JSON.stringify(changes) }),
  delete: (id: string): Promise<ApiResponse<void>> =>
    apiCall<void>(`/workers/${id}`, { method: 'DELETE' }),
  updateStatus: (id: string, status: Worker['status']): Promise<ApiResponse<Worker>> =>
    apiCall<Worker>(`/workers/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  getStatsSummary: (): Promise<ApiResponse<any>> => apiCall(`/workers/stats/summary`),
};

// Reports API
export const reportsApi = {
  // JSON preview endpoints with optional query params
  getInventory: (params?: { from?: string; to?: string }): Promise<ApiResponse<any>> => {
    const q = new URLSearchParams();
    if (params?.from) q.append('from', params.from);
    if (params?.to) q.append('to', params.to);
    const query = q.toString() ? `?${q.toString()}` : '';
    return apiCall(`/reports/inventory${query}`);
  },
  getSales: (params?: { from?: string; to?: string }): Promise<ApiResponse<any>> => {
    const q = new URLSearchParams();
    if (params?.from) q.append('from', params.from);
    if (params?.to) q.append('to', params.to);
    const query = q.toString() ? `?${q.toString()}` : '';
    return apiCall(`/reports/sales${query}`);
  },
  getLowStock: (params?: { from?: string; to?: string }): Promise<ApiResponse<any>> => {
    const q = new URLSearchParams();
    if (params?.from) q.append('from', params.from);
    if (params?.to) q.append('to', params.to);
    const query = q.toString() ? `?${q.toString()}` : '';
    return apiCall(`/reports/low-stock${query}`);
  },
  getCustomer: (params?: { from?: string; to?: string }): Promise<ApiResponse<any>> => {
    const q = new URLSearchParams();
    if (params?.from) q.append('from', params.from);
    if (params?.to) q.append('to', params.to);
    const query = q.toString() ? `?${q.toString()}` : '';
    return apiCall(`/reports/customer${query}`);
  },
  getFinancial: (params?: { from?: string; to?: string }): Promise<ApiResponse<any>> => {
    const q = new URLSearchParams();
    if (params?.from) q.append('from', params.from);
    if (params?.to) q.append('to', params.to);
    const query = q.toString() ? `?${q.toString()}` : '';
    return apiCall(`/reports/financial${query}`);
  },
  // File downloads (CSV/HTML)
  download: (type: string, format: 'csv' | 'html' | 'pdf' | 'excel', params: { from?: string; to?: string }) => {
    const q = new URLSearchParams();
    if (params?.from) q.append('from', params.from);
    if (params?.to) q.append('to', params.to);
    q.append('format', format);
    const filename = `${type}-report.${format === 'excel' ? 'xlsx' : format}`;
    return downloadFile(`/reports/${type}/export?${q.toString()}`, filename);
  },
  downloadSample: (type: string, format: 'csv' | 'html' | 'pdf' | 'excel') => {
    const filename = `sample-${type}-report.${format === 'excel' ? 'xlsx' : format}`;
    return downloadFile(`/reports/sample/${type}?format=${format}`, filename);
  }
};

// Inbound (Receiving) API
export const inboundApi = {
  getAll: (): Promise<ApiResponse<any[]>> => apiCall(`/inbound`),
  getStatsSummary: (): Promise<ApiResponse<{ incoming: number; arrived: number; inProgress: number; qcHold: number; received: number }>> =>
    apiCall(`/inbound/stats/summary`),
  create: (payload: { vendor: string; eta: string; location: string; cartons: number; items: number; notes?: string }): Promise<ApiResponse<any>> =>
    apiCall(`/inbound`, { method: 'POST', body: JSON.stringify(payload) }),
  update: (id: string, changes: Partial<any>): Promise<ApiResponse<any>> =>
    apiCall(`/inbound/${id}`, { method: 'PUT', body: JSON.stringify(changes) }),
  updateStatus: (id: string, status: 'arrived' | 'in-progress' | 'qc-hold' | 'received'): Promise<ApiResponse<any>> =>
    apiCall(`/inbound/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  delete: (id: string): Promise<ApiResponse<void>> => apiCall(`/inbound/${id}`, { method: 'DELETE' }),
};

// Dashboard API
export const dashboardApi = {
  // Get dashboard statistics
  getStats: (): Promise<ApiResponse<DashboardStats>> => 
    apiCall<DashboardStats>('/dashboard/stats'),
};

// Profile API
export const profileApi = {
  get: (): Promise<ApiResponse<UserProfile>> =>
    apiCall<UserProfile>('/profile'),
};

// Health check
export const healthCheck = (): Promise<ApiResponse<{ message: string }>> => 
  apiCall<{ message: string }>('/ping');

// Export all APIs
export const api = {
  products: productsApi,
  orders: ordersApi,
  customers: customersApi,
  shipments: shipmentsApi,
  workers: workersApi,
  inbound: inboundApi,
  reports: reportsApi,
  dashboard: dashboardApi,
  profile: profileApi,
  health: healthCheck,
};