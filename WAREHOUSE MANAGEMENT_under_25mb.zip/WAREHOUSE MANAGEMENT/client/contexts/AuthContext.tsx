import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type UserRole = 'owner' | 'manager' | 'employee';

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

// Define route permissions for each role
export const rolePermissions: Record<UserRole, string[]> = {
  owner: ['/', '/stock', '/orders', '/sellers', '/pending-shipments', '/receiving', '/add-product', '/workers', '/generate-report', '/settings', '/analytics', '/inventory'],
  manager: ['/', '/stock', '/orders', '/sellers', '/pending-shipments', '/receiving', '/workers', '/settings'],
  employee: ['/', '/orders', '/pending-shipments']
};

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
  hasAccess: (path: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Clear any stored user session to force login
    localStorage.removeItem('user');
    setUser(null);
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // In a real app, this would be an API call to your backend
      // For demo purposes, we'll simulate different users based on email
      let role: UserRole = 'employee';
      let name = 'Employee User';
      
      if (email.includes('owner')) {
        role = 'owner';
        name = 'Owner User';
      } else if (email.includes('manager')) {
        role = 'manager';
        name = 'Manager User';
      }
      
      const mockUser: User = {
        id: `user-${Math.floor(Math.random() * 1000)}`,
        name,
        email: email,
        role,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
      };
      
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  // Check if user has access to a specific route
  const hasAccess = (path: string): boolean => {
    if (!user) return path === '/login';
    const userRole = user.role;
    return rolePermissions[userRole].some(route => {
      if (route.endsWith('*')) {
        return path.startsWith(route.slice(0, -1));
      }
      return path === route;
    });
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      logout,
      updateUser,
      hasAccess
    }}>
      {!isLoading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
