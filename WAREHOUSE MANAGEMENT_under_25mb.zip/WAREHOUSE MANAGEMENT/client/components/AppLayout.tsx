import { ReactNode } from 'react';
import { ProfileMenu } from './ProfileMenu';

interface AppLayoutProps {
  children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Global Header with Profile Menu */}
      <header className="fixed top-0 right-0 z-50 p-4">
        <ProfileMenu />
      </header>

      {/* Main Content */}
      <main className="pt-16"> {/* Add top padding to account for fixed header */}
        {children}
      </main>
    </div>
  );
}