import React, { useEffect, useState, useRef, useCallback } from 'react';

interface TrailDot {
  id: number;
  x: number;
  y: number;
  timestamp: number;
  zone: string;
}

interface RippleEffect {
  id: number;
  x: number;
  y: number;
  zone: string;
  timestamp: number;
}

const ZONE_CONFIG = {
  dashboard: { icon: '📊', color: '#3b82f6', label: 'Dashboard' },
  inventory: { icon: '📦', color: '#10b981', label: 'Inventory' },
  orders: { icon: '📋', color: '#f59e0b', label: 'Orders' },
  shipping: { icon: '🚚', color: '#ef4444', label: 'Shipping' },
  receiving: { icon: '📥', color: '#8b5cf6', label: 'Receiving' },
  workers: { icon: '👥', color: '#06b6d4', label: 'Workers' },
  reports: { icon: '📈', color: '#ec4899', label: 'Reports' },
  settings: { icon: '⚙️', color: '#6b7280', label: 'Settings' },
};

const hexToRgb = (hex: string): string => {
  let c = hex.replace('#', '');
  if (c.length === 3) c = c.split('').map(x => x + x).join('');
  const num = parseInt(c, 16);
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `${r}, ${g}, ${b}`;
};

const WarehouseCursorTracker: React.FC = () => {
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [smoothedPos, setSmoothedPos] = useState({ x: 0, y: 0 });
  const [currentZone, setCurrentZone] = useState('dashboard');
  const [trailDots, setTrailDots] = useState<TrailDot[]>([]);
  const [ripples, setRipples] = useState<RippleEffect[]>([]);
  const [isVisible, setIsVisible] = useState(false);
  const [velocity, setVelocity] = useState({ x: 0, y: 0 });

  const cursorRef = useRef<HTMLDivElement>(null);
  const dotIdRef = useRef(0);
  const rippleIdRef = useRef(0);
  const lastMousePos = useRef({ x: 0, y: 0 });
  const lastTime = useRef(Date.now());

  // Zone detection function
  const detectZone = useCallback((x: number, y: number): string => {
    const element = document.elementFromPoint(x, y) as HTMLElement;
    if (!element) return 'dashboard';

    let currentElement: HTMLElement | null = element;
    while (currentElement && currentElement !== document.body) {
      if (currentElement.dataset.zone) {
        const detectedZone = currentElement.dataset.zone;
        if (Object.keys(ZONE_CONFIG).includes(detectedZone)) {
          return detectedZone;
        }
      }
      currentElement = currentElement.parentElement;
    }
    return 'dashboard';
  }, []);

  useEffect(() => {
    let animationFrame: number;

    const updateCursor = (e: MouseEvent) => {
      const now = Date.now();
      const deltaTime = now - lastTime.current;
      lastTime.current = now;

      const x = e.clientX;
      const y = e.clientY;

      // Calculate velocity for dynamic trail
      const dx = x - lastMousePos.current.x;
      const dy = y - lastMousePos.current.y;
      const speed = Math.sqrt(dx * dx + dy * dy);

      setVelocity({ x: dx / Math.max(1, deltaTime), y: dy / Math.max(1, deltaTime) });
      lastMousePos.current = { x, y };

      setCursorPos({ x, y });

      // Detect current zone
      const zone = detectZone(x, y);
      setCurrentZone(zone);

      // Add trail dot only if moving fast enough (professional touch)
      if (speed > 0.5) {
        setTrailDots(prev => {
          const newDot: TrailDot = {
            id: dotIdRef.current++,
            x,
            y,
            timestamp: now,
            zone
          };

          const updated = [...prev, newDot];
          // Keep fewer dots for cleaner look, remove older ones
          return updated.filter(dot => now - dot.timestamp < 1500).slice(-12);
        });
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
      animationFrame = requestAnimationFrame(() => updateCursor(e));
    };

    const handleMouseEnter = () => setIsVisible(true);
    const handleMouseLeave = () => setIsVisible(false);

    const handleClick = (e: MouseEvent) => {
      const newRipple: RippleEffect = {
        id: rippleIdRef.current++,
        x: e.clientX,
        y: e.clientY,
        zone: currentZone,
        timestamp: Date.now()
      };

      setRipples(prev => [...prev, newRipple]);

      // Remove ripple after animation (shorter for professional feel)
      setTimeout(() => {
        setRipples(prev => prev.filter(r => r.id !== newRipple.id));
      }, 600);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseenter', handleMouseEnter);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('click', handleClick);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseenter', handleMouseEnter);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('click', handleClick);
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [currentZone, detectZone]);

  // Clean up old trail dots and ripples periodically
  useEffect(() => {
    const cleanup = setInterval(() => {
      const now = Date.now();
      setTrailDots(prev => prev.filter(dot => now - dot.timestamp < 1500));
      setRipples(prev => prev.filter(ripple => now - ripple.timestamp < 600));
    }, 500); // More frequent cleanup for better performance

    return () => clearInterval(cleanup);
  }, []);

  // Professional cursor smoothing with velocity-based interpolation
  useEffect(() => {
    let smoothAnimationFrame: number;

    const smoothCursor = () => {
      setSmoothedPos(prev => {
        const speed = Math.sqrt(velocity.x * velocity.x + velocity.y * velocity.y);
        // Dynamic interpolation based on speed - faster movement = more responsive
        const lerpFactor = Math.min(0.4, Math.max(0.15, speed * 0.001));

        const easeInOut = (t: number) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
        const easedFactor = easeInOut(lerpFactor);

        return {
          x: prev.x + (cursorPos.x - prev.x) * easedFactor,
          y: prev.y + (cursorPos.y - prev.y) * easedFactor
        };
      });
      smoothAnimationFrame = requestAnimationFrame(smoothCursor);
    };

    smoothAnimationFrame = requestAnimationFrame(smoothCursor);

    return () => {
      if (smoothAnimationFrame) {
        cancelAnimationFrame(smoothAnimationFrame);
      }
    };
  }, [cursorPos, velocity]);

  // Expose CSS variables for global ambient/hover effects
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--cursor-x', `${smoothedPos.x}px`);
    root.style.setProperty('--cursor-y', `${smoothedPos.y}px`);

    const vw = Math.max(1, window.innerWidth);
    const vh = Math.max(1, window.innerHeight);
    const nx = smoothedPos.x / vw - 0.5;
    const ny = smoothedPos.y / vh - 0.5;
    root.style.setProperty('--cursor-vx', `${nx}`);
    root.style.setProperty('--cursor-vy', `${ny}`);
  }, [smoothedPos]);

  // Update color variable by zone
  useEffect(() => {
    const zoneConfig = ZONE_CONFIG[currentZone as keyof typeof ZONE_CONFIG] || ZONE_CONFIG.dashboard;
    const rgb = hexToRgb(zoneConfig.color);
    document.documentElement.style.setProperty('--cursor-color-rgb', rgb);
  }, [currentZone]);

  const zoneConfig = ZONE_CONFIG[currentZone as keyof typeof ZONE_CONFIG] || ZONE_CONFIG.dashboard;

  return (
    <>
      {/* Global styles for ambient + hover animations */}
      <style>{`
        :root {
          --cursor-x: 50vw;
          --cursor-y: 50vh;
          --cursor-vx: 0;
          --cursor-vy: 0;
          --cursor-color-rgb: 59, 130, 246; /* default to blue */
        }
        .cursor-ambient {
          position: fixed;
          inset: 0;
          pointer-events: none;
          z-index: 25;
          background: radial-gradient(650px at var(--cursor-x) var(--cursor-y), rgba(var(--cursor-color-rgb), 0.12), transparent 60%);
          transition: background 120ms ease-out;
          mix-blend-mode: screen;
        }
        [data-zone] {
          transition: transform 150ms ease, box-shadow 250ms ease, background 250ms ease, border-color 250ms ease;
          will-change: transform, box-shadow;
        }
        [data-zone]:hover {
          transform: translate3d(calc(var(--cursor-vx) * 8px), calc(var(--cursor-vy) * 8px), 0) scale(1.01);
          box-shadow: 0 10px 25px rgba(var(--cursor-color-rgb), 0.15), 0 0 0 1px rgba(var(--cursor-color-rgb), 0.15);
        }
      `}</style>

      {/* Ambient spotlight following the cursor across the whole page */}
      <div className="cursor-ambient" />

      {/* Professional Warehouse Grid Overlay - Subtle and Integrated */}
      <div
        className="fixed inset-0 pointer-events-none z-40 opacity-8"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }}
      />

      {/* Professional Cursor - Clean and Precise */}
      {isVisible && (
        <div
          ref={cursorRef}
          className="fixed pointer-events-none z-50"
          style={{
            left: smoothedPos.x,
            top: smoothedPos.y,
            transform: 'translate(-50%, -50%)',
            willChange: 'transform'
          }}
        >
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-lg font-medium shadow-lg border border-white/20 backdrop-blur-sm transition-all duration-200"
            style={{
              backgroundColor: `${zoneConfig.color}D0`,
              boxShadow: `0 4px 12px ${zoneConfig.color}40, 0 0 0 1px ${zoneConfig.color}30, inset 0 1px 0 rgba(255,255,255,0.2)`,
              color: '#ffffff'
            }}
          >
            {zoneConfig.icon}
          </div>
        </div>
      )}

      {/* Professional Movement Trail - Velocity-Based */}
      {trailDots.map((dot) => {
        const age = Date.now() - dot.timestamp;
        const progress = age / 1500;
        const opacity = Math.max(0, 1 - progress * progress); // Quadratic fade
        const size = Math.max(2, 6 * (1 - progress));

        const dotZoneConfig = ZONE_CONFIG[dot.zone as keyof typeof ZONE_CONFIG] || ZONE_CONFIG.dashboard;

        return (
          <div
            key={dot.id}
            className="fixed pointer-events-none z-30 rounded-full"
            style={{
              left: dot.x,
              top: dot.y,
              transform: 'translate(-50%, -50%)',
              width: size,
              height: size,
              backgroundColor: dotZoneConfig.color,
              opacity: opacity * 0.6,
              boxShadow: `0 0 ${size * 2}px ${dotZoneConfig.color}50`,
              transition: 'opacity 0.1s ease-out'
            }}
          />
        );
      })}

      {/* Professional Click Feedback - Subtle and Quick */}
      {ripples.map(ripple => {
        const age = Date.now() - ripple.timestamp;
        const progress = age / 600;
        const scale = progress * 1.8;
        const opacity = Math.max(0, 1 - progress);

        const rippleZoneConfig = ZONE_CONFIG[ripple.zone as keyof typeof ZONE_CONFIG] || ZONE_CONFIG.dashboard;

        return (
          <div
            key={ripple.id}
            className="fixed pointer-events-none z-45"
            style={{
              left: ripple.x,
              top: ripple.y,
              transform: `translate(-50%, -50%) scale(${scale})`,
              opacity: opacity * 0.8,
              transition: 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)'
            }}
          >
            <div
              className="rounded-full border-2 flex items-center justify-center text-xl"
              style={{
                width: '48px',
                height: '48px',
                borderColor: rippleZoneConfig.color,
                backgroundColor: `${rippleZoneConfig.color}15`,
                boxShadow: `0 0 20px ${rippleZoneConfig.color}40`
              }}
            >
              {rippleZoneConfig.icon}
            </div>
          </div>
        );
      })}
    </>
  );
};

export default WarehouseCursorTracker;
