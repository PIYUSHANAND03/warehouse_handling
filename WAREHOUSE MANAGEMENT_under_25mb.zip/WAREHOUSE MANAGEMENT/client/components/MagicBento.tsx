import React, { useState, useEffect, useRef } from 'react';
import './MagicBento.css';

interface MagicBentoProps {
  textAutoHide?: boolean;
  enableStars?: boolean;
  enableSpotlight?: boolean;
  enableBorderGlow?: boolean;
  enableTilt?: boolean;
  enableMagnetism?: boolean;
  clickEffect?: boolean;
  spotlightRadius?: number;
  particleCount?: number;
  glowColor?: string;
}

const MagicBento: React.FC<MagicBentoProps> = ({
  textAutoHide = true,
  enableStars = true,
  enableSpotlight = true,
  enableBorderGlow = true,
  enableTilt = true,
  enableMagnetism = true,
  clickEffect = true,
  spotlightRadius = 300,
  particleCount = 12,
  glowColor = "132, 0, 255"
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [tilt, setTilt] = useState<Record<number, { rotateX: number; rotateY: number }>>({});
  const [magnetism, setMagnetism] = useState<Record<number, { x: number; y: number }>>({});
  const [clicking, setClicking] = useState<Record<number, boolean>>({});

  // Handle mouse move for spotlight
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
      }
    };

    if (enableSpotlight) {
      window.addEventListener('mousemove', handleMouseMove);
      return () => window.removeEventListener('mousemove', handleMouseMove);
    }
  }, [enableSpotlight]);

  const handleCardMouseMove = (e: React.MouseEvent, index: number) => {
    if (enableTilt) {
      const card = cardRefs.current[index];
      if (card) {
        const rect = card.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const rotateX = (e.clientY - centerY) / 10;
        const rotateY = (e.clientX - centerX) / 10;
        setTilt(prev => ({ ...prev, [index]: { rotateX, rotateY } }));
      }
    }

    if (enableMagnetism) {
      const card = cardRefs.current[index];
      if (card) {
        const rect = card.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const deltaX = e.clientX - centerX;
        const deltaY = e.clientY - centerY;
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        if (distance < 100) {
          const strength = (100 - distance) / 100;
          setMagnetism(prev => ({ ...prev, [index]: { x: deltaX * strength * 0.1, y: deltaY * strength * 0.1 } }));
        } else {
          setMagnetism(prev => ({ ...prev, [index]: { x: 0, y: 0 } }));
        }
      }
    }
  };

  const handleCardMouseLeave = (index: number) => {
    if (enableTilt) {
      setTilt(prev => ({ ...prev, [index]: { rotateX: 0, rotateY: 0 } }));
    }
    if (enableMagnetism) {
      setMagnetism(prev => ({ ...prev, [index]: { x: 0, y: 0 } }));
    }
  };

  const handleClick = (index: number) => {
    if (clickEffect) {
      setClicking(prev => ({ ...prev, [index]: true }));
      setTimeout(() => setClicking(prev => ({ ...prev, [index]: false })), 300);
    }
  };

  // Sample cards data
  const cards = [
    { title: 'Warehouse Analytics', description: 'Real-time insights into inventory levels and stock movements.', label: 'Analytics' },
    { title: 'Order Management', description: 'Streamline order processing and fulfillment.', label: 'Orders' },
    { title: 'Inventory Control', description: 'Advanced tracking and management of warehouse stock.', label: 'Inventory' },
    { title: 'Supplier Integration', description: 'Seamless connection with suppliers for automatic replenishment.', label: 'Suppliers' },
    { title: 'Reporting Dashboard', description: 'Comprehensive reports on warehouse performance.', label: 'Reports' },
    { title: 'User Management', description: 'Manage workers, roles, and permissions.', label: 'Users' },
  ];

  // Generate particles
  const particles = Array.from({ length: particleCount }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 4 + 2,
    delay: Math.random() * 2,
  }));

  return (
    <div className="bento-section" ref={containerRef}>
      {enableSpotlight && (
        <div
          className="global-spotlight"
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            background: `radial-gradient(circle ${spotlightRadius}px at ${mousePos.x}px ${mousePos.y}px, rgba(${glowColor}, 0.3), transparent)`,
            pointerEvents: 'none',
          }}
        />
      )}

      <div className="card-grid">
        {cards.map((card, index) => (
          <div
            key={index}
            ref={(el) => cardRefs.current[index] = el}
            className={`card ${enableBorderGlow ? 'card--border-glow' : ''} ${textAutoHide ? 'card--text-autohide' : ''}`}
            onMouseMove={(e) => handleCardMouseMove(e, index)}
            onMouseLeave={() => handleCardMouseLeave(index)}
            onClick={() => handleClick(index)}
            style={{
              transform: `
                ${enableTilt ? `rotateX(${tilt[index]?.rotateX || 0}deg) rotateY(${tilt[index]?.rotateY || 0}deg)` : ''}
                ${enableMagnetism ? `translate(${magnetism[index]?.x || 0}px, ${magnetism[index]?.y || 0}px)` : ''}
                ${clicking[index] ? 'scale(0.95)' : ''}
              `,
              transition: clicking[index] ? 'transform 0.1s' : 'transform 0.3s',
            }}
          >
            <div className="card__header">
              <span className="card__label">{card.label}</span>
            </div>
            <div className="card__content">
              <h3 className="card__title">{card.title}</h3>
              <p className="card__description">{card.description}</p>
            </div>

            {enableStars && particles.map((p) => (
              <div
                key={p.id}
                className="particle"
                style={{
                  position: 'absolute',
                  left: `${p.x}%`,
                  top: `${p.y}%`,
                  width: `${p.size}px`,
                  height: `${p.size}px`,
                  background: `rgba(${glowColor}, 0.8)`,
                  borderRadius: '50%',
                  animation: `float ${2 + p.delay}s ease-in-out infinite`,
                  animationDelay: `${p.delay}s`,
                }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default MagicBento;