import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';

export function ProtectedRoute({ children, roles }: { 
  children: React.ReactNode;
  roles?: Array<'owner' | 'manager' | 'employee'>;
}) {
  const { user, isAuthenticated, isLoading, hasAccess } = useAuth();
  const location = useLocation();
  const currentPath = location.pathname;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  // If user is not authenticated, redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If roles are specified, check if user has one of the required roles
  if (roles && user && !roles.includes(user.role)) {
    // Redirect to home or unauthorized page
    return <Navigate to="/unauthorized" replace />;
  }

  // Check if user has access to the current route
  if (!hasAccess(currentPath)) {
    // Redirect to home or unauthorized page
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children}</>;
}
