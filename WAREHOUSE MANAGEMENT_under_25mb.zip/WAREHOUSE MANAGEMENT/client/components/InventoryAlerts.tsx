import { useEffect, useState } from "react";
import { Product } from "@/lib/api";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface InventoryAlertsProps {
  products: Product[];
}

export function InventoryAlerts({ products }: InventoryAlertsProps) {
  const [dismissedAlerts, setDismissedAlerts] = useState<string[]>([]);
  
  // Calculate alerts
  const lowStockProducts = products.filter(
    p => p.status === 'low-stock' && !dismissedAlerts.includes(`low-${p.id}`)
  );
  
  const outOfStockProducts = products.filter(
    p => p.status === 'out-of-stock' && !dismissedAlerts.includes(`out-${p.id}`)
  );
  
  const criticalAlerts = outOfStockProducts.length;
  const warningAlerts = lowStockProducts.length;
  const totalAlerts = criticalAlerts + warningAlerts;

  // Show toast notifications for critical alerts
  useEffect(() => {
    outOfStockProducts.forEach(product => {
      const alertId = `out-${product.id}`;
      if (!dismissedAlerts.includes(alertId)) {
        toast({
          title: "⚠️ Critical Stock Alert",
          description: `${product.name} is now out of stock!`,
          variant: "destructive",
        });
      }
    });
  }, [outOfStockProducts, dismissedAlerts]);

  // Auto-dismiss alerts after successful actions
  useEffect(() => {
    const activeProductIds = products.map(p => p.id);
    setDismissedAlerts(prev => 
      prev.filter(alertId => {
        const productId = alertId.replace(/^(low|out)-/, '');
        return activeProductIds.includes(productId);
      })
    );
  }, [products]);

  const dismissAlert = (alertId: string) => {
    setDismissedAlerts(prev => [...prev, alertId]);
  };

  const dismissAllAlerts = () => {
    const allAlertIds = [
      ...lowStockProducts.map(p => `low-${p.id}`),
      ...outOfStockProducts.map(p => `out-${p.id}`)
    ];
    setDismissedAlerts(prev => [...prev, ...allAlertIds]);
  };

  if (totalAlerts === 0) {
    return (
      <Button variant="ghost" size="sm" disabled>
        <i className="fas fa-bell text-muted-foreground"></i>
      </Button>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <i className="fas fa-bell"></i>
          <Badge 
            variant={criticalAlerts > 0 ? "destructive" : "secondary"}
            className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs"
          >
            {totalAlerts}
          </Badge>
        </Button>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent align="end" className="w-80">
        <div className="flex items-center justify-between p-3 border-b">
          <div className="font-semibold">Inventory Alerts</div>
          <Button variant="ghost" size="sm" onClick={dismissAllAlerts}>
            Dismiss All
          </Button>
        </div>
        
        <div className="max-h-64 overflow-y-auto">
          {/* Critical Alerts */}
          {outOfStockProducts.map((product) => (
            <div
              key={product.id}
              className="flex items-start justify-between p-3 border-b hover:bg-muted/50"
            >
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <i className="fas fa-exclamation-triangle text-destructive text-sm"></i>
                  <Badge variant="destructive" className="text-xs">Critical</Badge>
                </div>
                <div className="font-medium text-sm">{product.name}</div>
                <div className="text-xs text-muted-foreground">
                  Out of stock • {product.category}
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => dismissAlert(`out-${product.id}`)}
                className="h-6 w-6 p-0"
              >
                <i className="fas fa-times text-xs"></i>
              </Button>
            </div>
          ))}
          
          {/* Warning Alerts */}
          {lowStockProducts.map((product) => (
            <div
              key={product.id}
              className="flex items-start justify-between p-3 border-b hover:bg-muted/50"
            >
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <i className="fas fa-exclamation-circle text-amber-500 text-sm"></i>
                  <Badge variant="secondary" className="text-xs">Warning</Badge>
                </div>
                <div className="font-medium text-sm">{product.name}</div>
                <div className="text-xs text-muted-foreground">
                  {product.stock} units left • {product.category}
                  {product.minStock && ` • Min: ${product.minStock}`}
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => dismissAlert(`low-${product.id}`)}
                className="h-6 w-6 p-0"
              >
                <i className="fas fa-times text-xs"></i>
              </Button>
            </div>
          ))}
        </div>
        
        {totalAlerts === 0 && (
          <div className="p-6 text-center text-muted-foreground">
            <i className="fas fa-check-circle text-2xl mb-2"></i>
            <p className="text-sm">All caught up!</p>
          </div>
        )}
        
        <div className="p-3 border-t bg-muted/30">
          <div className="text-xs text-muted-foreground text-center">
            {criticalAlerts > 0 && (
              <span className="text-destructive font-medium">
                {criticalAlerts} critical
              </span>
            )}
            {criticalAlerts > 0 && warningAlerts > 0 && ' • '}
            {warningAlerts > 0 && (
              <span className="text-amber-600 font-medium">
                {warningAlerts} warnings
              </span>
            )}
          </div>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}