import { useState } from "react";
import { Product } from "@/lib/api";
import { useDeleteProduct } from "@/hooks/useApi";
import { toast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface DeleteConfirmationDialogProps {
  product: Product | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function DeleteConfirmationDialog({ 
  product, 
  open, 
  onOpenChange, 
  onSuccess 
}: DeleteConfirmationDialogProps) {
  const { deleteProduct, loading, error } = useDeleteProduct();
  const [confirmText, setConfirmText] = useState("");

  const handleDelete = async () => {
    if (!product) return;

    try {
      await deleteProduct(product.id);
      
      toast({
        title: "Product Deleted",
        description: `${product.name} has been permanently deleted.`,
      });

      onSuccess();
      onOpenChange(false);
      setConfirmText("");
    } catch (err) {
      toast({
        title: "Delete Failed",
        description: error || "Failed to delete product. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setConfirmText("");
    }
    onOpenChange(newOpen);
  };

  if (!product) return null;

  const isConfirmed = confirmText.toLowerCase() === product.name.toLowerCase();

  return (
    <AlertDialog open={open} onOpenChange={handleOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="text-destructive">
            Delete Product
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-3">
            <p>
              Are you sure you want to delete <strong>{product.name}</strong>? 
              This action cannot be undone and will permanently remove the product 
              from your inventory.
            </p>
            <div className="bg-muted p-3 rounded-md">
              <p className="text-sm font-medium">Product Details:</p>
              <ul className="text-sm mt-1 space-y-1">
                <li>SKU: {product.sku || "N/A"}</li>
                <li>Category: {product.category}</li>
                <li>Current Stock: {product.stock}</li>
                <li>Price: ₹{product.price}</li>
              </ul>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium">
                To confirm deletion, type the product name below:
              </p>
              <input
                type="text"
                placeholder={`Type "${product.name}" to confirm`}
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={loading || !isConfirmed}
            className="bg-destructive hover:bg-destructive/90"
          >
            {loading ? "Deleting..." : "Delete Product"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}