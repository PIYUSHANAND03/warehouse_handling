import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { WarehouseMetrics, EquipmentStatus, WarehouseZones } from '@shared/api';

const WarehouseOptimizationDemo: React.FC = () => {
  const [metrics, setMetrics] = useState({
    efficiency: 87,
    throughput: 94,
    accuracy: 96,
    utilization: 78
  });

  const [equipmentStatus, setEquipmentStatus] = useState({
    forklifts: { active: 8, total: 12 },
    conveyors: { active: 15, total: 16 },
    scanners: { active: 6, total: 8 },
    robots: { active: 4, total: 5 }
  });

  const [storageZones, setStorageZones] = useState({
    A: { capacity: 85, items: 340 },
    B: { capacity: 92, items: 460 },
    C: { capacity: 67, items: 268 }
  });

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        efficiency: Math.max(70, Math.min(100, prev.efficiency + (Math.random() - 0.5) * 2)),
        throughput: Math.max(85, Math.min(100, prev.throughput + (Math.random() - 0.5) * 1.5)),
        accuracy: Math.max(90, Math.min(100, prev.accuracy + (Math.random() - 0.5) * 0.5)),
        utilization: Math.max(60, Math.min(95, prev.utilization + (Math.random() - 0.5) * 3))
      }));

      // Update equipment occasionally
      if (Math.random() < 0.1) {
        setEquipmentStatus(prev => ({
          forklifts: {
            ...prev.forklifts,
            active: Math.max(6, Math.min(12, prev.forklifts.active + (Math.random() > 0.5 ? 1 : -1)))
          },
          conveyors: {
            ...prev.conveyors,
            active: Math.max(13, Math.min(16, prev.conveyors.active + (Math.random() > 0.5 ? 1 : -1)))
          },
          scanners: {
            ...prev.scanners,
            active: Math.max(4, Math.min(8, prev.scanners.active + (Math.random() > 0.5 ? 1 : -1)))
          },
          robots: {
            ...prev.robots,
            active: Math.max(3, Math.min(5, prev.robots.active + (Math.random() > 0.5 ? 1 : -1)))
          }
        }));
      }

      // Update storage zones
      if (Math.random() < 0.05) {
        const zones = ['A', 'B', 'C'] as const;
        const randomZone = zones[Math.floor(Math.random() * zones.length)];
        setStorageZones(prev => ({
          ...prev,
          [randomZone]: {
            capacity: Math.max(30, Math.min(100, prev[randomZone].capacity + (Math.random() - 0.5) * 10)),
            items: Math.max(100, Math.min(500, prev[randomZone].items + (Math.random() - 0.5) * 20))
          }
        }));
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleZoneClick = (zone: string, action: string) => {
    console.log(`Clicked ${action} in ${zone} zone`);
    // Add click effects or interactions here
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">🏭 Warehouse Optimization Dashboard</h1>
          <p className="text-slate-400">Real-time monitoring and zone-based operations</p>
        </div>

        {/* Performance Metrics */}
        <div data-zone="inventory" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Efficiency</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-400">{metrics.efficiency.toFixed(1)}%</div>
              <Progress value={metrics.efficiency} className="mt-2" />
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Throughput</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-400">{metrics.throughput.toFixed(1)}%</div>
              <Progress value={metrics.throughput} className="mt-2" />
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Accuracy</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-400">{metrics.accuracy.toFixed(1)}%</div>
              <Progress value={metrics.accuracy} className="mt-2" />
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Utilization</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-400">{metrics.utilization.toFixed(1)}%</div>
              <Progress value={metrics.utilization} className="mt-2" />
            </CardContent>
          </Card>
        </div>

        {/* Warehouse Zones Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Receiving Zone */}
          <div data-zone="receiving" className="space-y-4">
            <Card className="bg-red-900/20 border-red-700/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-400">
                  📥 Receiving Zone
                  <Badge variant="secondary" className="bg-red-700/50">High Priority</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    variant="outline"
                    className="border-red-700 text-red-400 hover:bg-red-700/20"
                    onClick={() => handleZoneClick('receiving', 'scan-inbound')}
                    data-warehouse-action="scan-inbound"
                  >
                    Scan Inbound
                  </Button>
                  <Button
                    variant="outline"
                    className="border-red-700 text-red-400 hover:bg-red-700/20"
                    onClick={() => handleZoneClick('receiving', 'quality-check')}
                    data-warehouse-action="quality-check"
                  >
                    Quality Check
                  </Button>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Pending Shipments</span>
                    <span className="text-red-400 font-medium">12</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Today Received</span>
                    <span className="text-green-400 font-medium">8</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Inventory Zone */}
          <div data-zone="inventory" className="space-y-4">
            <Card className="bg-green-900/20 border-green-700/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-400">
                  📋 Inventory Zone
                  <Badge variant="secondary" className="bg-green-700/50">Active</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Scan product barcode..."
                  className="bg-slate-800 border-green-700/50 text-green-400 placeholder:text-green-700"
                  data-warehouse-action="scan-product"
                />
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    variant="outline"
                    className="border-green-700 text-green-400 hover:bg-green-700/20"
                    onClick={() => handleZoneClick('inventory', 'stock-count')}
                    data-warehouse-action="stock-count"
                  >
                    Stock Count
                  </Button>
                  <Button
                    variant="outline"
                    className="border-green-700 text-green-400 hover:bg-green-700/20"
                    onClick={() => handleZoneClick('inventory', 'replenish')}
                    data-warehouse-action="replenish"
                  >
                    Replenish
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Storage Zones */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-slate-400">Storage Capacity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(storageZones).map(([zone, data]) => (
                  <div key={zone} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Zone {zone}</span>
                      <span className="text-white font-medium">{data.capacity.toFixed(0)}%</span>
                    </div>
                    <Progress value={data.capacity} className="h-2" />
                    <div className="text-xs text-slate-500">{data.items} items</div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Shipping Zone */}
          <div data-zone="shipping" className="space-y-4">
            <Card className="bg-orange-900/20 border-orange-700/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-400">
                  🚛 Shipping Zone
                  <Badge variant="secondary" className="bg-orange-700/50">Processing</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    variant="outline"
                    className="border-orange-700 text-orange-400 hover:bg-orange-700/20"
                    onClick={() => handleZoneClick('shipping', 'pack-order')}
                    data-warehouse-action="pack-order"
                  >
                    Pack Order
                  </Button>
                  <Button
                    variant="outline"
                    className="border-orange-700 text-orange-400 hover:bg-orange-700/20"
                    onClick={() => handleZoneClick('shipping', 'load-truck')}
                    data-warehouse-action="load-truck"
                  >
                    Load Truck
                  </Button>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Orders Ready</span>
                    <span className="text-orange-400 font-medium">24</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Trucks Loading</span>
                    <span className="text-blue-400 font-medium">3</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Equipment Status */}
        <div data-zone="equipment" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Forklifts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-cyan-400">
                {equipmentStatus.forklifts.active}/{equipmentStatus.forklifts.total}
              </div>
              <div className="text-sm text-slate-500 mt-1">Active units</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Conveyors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-cyan-400">
                {equipmentStatus.conveyors.active}/{equipmentStatus.conveyors.total}
              </div>
              <div className="text-sm text-slate-500 mt-1">Operational</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Scanners</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-cyan-400">
                {equipmentStatus.scanners.active}/{equipmentStatus.scanners.total}
              </div>
              <div className="text-sm text-slate-500 mt-1">Online</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">Robots</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-cyan-400">
                {equipmentStatus.robots.active}/{equipmentStatus.robots.total}
              </div>
              <div className="text-sm text-slate-500 mt-1">Automated</div>
            </CardContent>
          </Card>
        </div>

        {/* Storage Zone A (Bottom Section) */}
        <div data-zone="storage" className="mt-8">
          <Card className="bg-purple-900/20 border-purple-700/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                🏢 Storage Zone A
                <Badge variant="secondary" className="bg-purple-700/50">Bulk Storage</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-slate-400">Aisle 1-5</h4>
                  <div className="grid grid-cols-5 gap-2">
                    {Array.from({ length: 25 }, (_, i) => (
                      <div
                        key={i}
                        className="w-8 h-8 bg-purple-700/30 rounded cursor-pointer hover:bg-purple-700/50 transition-colors"
                        onClick={() => handleZoneClick('storage', `location-${i + 1}`)}
                        data-warehouse-action={`location-${i + 1}`}
                      />
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-slate-400">Aisle 6-10</h4>
                  <div className="grid grid-cols-5 gap-2">
                    {Array.from({ length: 25 }, (_, i) => (
                      <div
                        key={i}
                        className="w-8 h-8 bg-purple-700/30 rounded cursor-pointer hover:bg-purple-700/50 transition-colors"
                        onClick={() => handleZoneClick('storage', `location-${i + 26}`)}
                        data-warehouse-action={`location-${i + 26}`}
                      />
                    ))}
                  </div>
                </div>
                <div className="space-y-4">
                  <Button
                    variant="outline"
                    className="w-full border-purple-700 text-purple-400 hover:bg-purple-700/20"
                    onClick={() => handleZoneClick('storage', 'optimize-layout')}
                    data-warehouse-action="optimize-layout"
                  >
                    Optimize Layout
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-purple-700 text-purple-400 hover:bg-purple-700/20"
                    onClick={() => handleZoneClick('storage', 'reorganize')}
                    data-warehouse-action="reorganize"
                  >
                    Reorganize Stock
                  </Button>
                  <div className="text-sm text-slate-400">
                    <div>Capacity: {storageZones.A.capacity.toFixed(0)}%</div>
                    <div>Items: {storageZones.A.items}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default WarehouseOptimizationDemo;