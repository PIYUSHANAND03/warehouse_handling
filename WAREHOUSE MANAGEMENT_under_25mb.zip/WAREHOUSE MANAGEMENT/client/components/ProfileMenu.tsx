import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useNavigate } from 'react-router-dom';
import { UserProfile } from '@shared/api';
import { toast } from '@/hooks/use-toast';

export function ProfileMenu() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      const res = await api.profile.get();
      let data = res.success ? (res.data as UserProfile) : null;
      // apply local overrides if any
      try {
        const raw = localStorage.getItem('profile:overrides');
        if (raw) {
          const overrides = JSON.parse(raw);
          data = { ...data, ...overrides } as any;
        }
      } catch {}
      if (mounted) setProfile(data as any);
      setLoading(false);
    })();
    return () => { mounted = false };
  }, []);

  const initials = (name?: string) => name?.split(' ').map(p => p[0]).slice(0,2).join('').toUpperCase() || 'U';

  const setTheme = (mode: 'light' | 'dark' | 'system') => {
    try {
      localStorage.setItem('theme', mode);
      const root = document.documentElement;
      const w = window as any;
      if (w.__themeMql && w.__themeListener) {
        w.__themeMql.removeEventListener?.('change', w.__themeListener);
        w.__themeMql = null;
        w.__themeListener = null;
      }
      root.classList.remove('dark', 'midnight-ember');
      if (mode === 'system') {
        const mql = window.matchMedia('(prefers-color-scheme: dark)');
        const set = () => {
          root.classList.remove('dark', 'midnight-ember');
          if (mql.matches) root.classList.add('dark');
        };
        set();
        mql.addEventListener('change', set);
        w.__themeMql = mql;
        w.__themeListener = set;
      } else {
        if (mode === 'dark') root.classList.add('dark');
      }
      toast({ title: 'Theme updated', description: `Theme set to ${mode}.` });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full border border-border">
          <Avatar className="h-9 w-9">
            {profile?.avatarUrl && <AvatarImage src={profile.avatarUrl} alt={profile?.name} />}
            <AvatarFallback className="text-sm">
              {initials(profile?.name)}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-72" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex items-center gap-3">
            <Avatar className="h-9 w-9">
              {profile?.avatarUrl && <AvatarImage src={profile.avatarUrl} alt={profile?.name} />}
              <AvatarFallback className="text-sm">
                {initials(profile?.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none">{profile?.name || 'User'}</p>
              <p className="text-xs leading-none text-muted-foreground">{profile?.email || 'user@example.com'}</p>
            </div>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        <DropdownMenuGroup>
          <DropdownMenuItem onClick={() => navigate('/settings?tab=profile')}>
            <i className="fas fa-user mr-2" />
            View Profile
            <DropdownMenuShortcut>Ctrl+P</DropdownMenuShortcut>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate('/settings')}>
            <i className="fas fa-gear mr-2" />
            Account Settings
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate('/orders')}>
            <i className="fas fa-receipt mr-2" />
            My Orders
          </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />

        <DropdownMenuGroup>
          <DropdownMenuLabel className="text-xs text-muted-foreground">Quick actions</DropdownMenuLabel>
          <DropdownMenuItem onClick={() => { navigator.clipboard?.writeText(profile?.email || ''); toast({ title: 'Copied', description: 'Email copied to clipboard' }); }}>
            <i className="fas fa-copy mr-2" />
            Copy email
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate('/') }>
            <i className="fas fa-house mr-2" />
            Dashboard
          </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />

        <DropdownMenuGroup>
          <DropdownMenuLabel className="text-xs text-muted-foreground">Theme</DropdownMenuLabel>
          <DropdownMenuItem onClick={() => setTheme('light')}>
            <i className="fas fa-sun mr-2" />
            Light
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme('dark')}>
            <i className="fas fa-moon mr-2" />
            Dark
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme('system')}>
            <i className="fas fa-desktop mr-2" />
            System
          </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={() => alert('Sign out mock')} className="text-destructive">
          <i className="fas fa-right-from-bracket mr-2" />
          Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
