import { useState, useEffect } from "react";
import { Product } from "@/lib/api";
import { useUpdateStock } from "@/hooks/useApi";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface StockAdjustmentDialogProps {
  product: Product | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function StockAdjustmentDialog({ 
  product, 
  open, 
  onOpenChange, 
  onSuccess 
}: StockAdjustmentDialogProps) {
  const { updateStock, loading, error } = useUpdateStock();
  const [adjustmentType, setAdjustmentType] = useState<"set" | "add" | "subtract">("add");
  const [quantity, setQuantity] = useState(0);
  const [reason, setReason] = useState("");
  const [minStock, setMinStock] = useState(0);

  const adjustmentReasons = [
    "Stock count correction",
    "Received new shipment",
    "Damaged goods",
    "Lost inventory",
    "Customer return",
    "Supplier adjustment",
    "Inventory audit",
    "Other"
  ];

  useEffect(() => {
    if (product) {
      setMinStock(product.minStock || 0);
      setQuantity(0);
      setReason("");
      setAdjustmentType("add");
    }
  }, [product]);

  const calculateNewStock = (): number => {
    if (!product) return 0;
    
    switch (adjustmentType) {
      case "set":
        return quantity;
      case "add":
        return product.stock + quantity;
      case "subtract":
        return Math.max(0, product.stock - quantity);
      default:
        return product.stock;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product) return;

    const newStock = calculateNewStock();
    
    if (newStock < 0) {
      toast({
        title: "Invalid Adjustment",
        description: "Stock cannot be negative.",
        variant: "destructive",
      });
      return;
    }

    try {
      await updateStock(product.id, {
        stock: newStock,
        minStock: minStock,
        reason: reason || `${adjustmentType === 'set' ? 'Set to' : adjustmentType === 'add' ? 'Added' : 'Subtracted'} ${quantity} units`
      });

      toast({
        title: "Stock Updated",
        description: `${product.name} stock updated to ${newStock} units.`,
      });

      onSuccess();
      onOpenChange(false);
    } catch (err) {
      toast({
        title: "Update Failed", 
        description: error || "Failed to update stock. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!product) return null;

  const newStock = calculateNewStock();
  const stockDifference = newStock - product.stock;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Adjust Stock</DialogTitle>
          <DialogDescription>
            Update the stock quantity for {product.name}
          </DialogDescription>
        </DialogHeader>

        <div className="bg-muted p-3 rounded-md mb-4">
          <div className="flex items-center justify-between text-sm">
            <span>Current Stock:</span>
            <Badge variant={product.status === 'low-stock' ? 'destructive' : 'secondary'}>
              {product.stock} units
            </Badge>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Adjustment Type</Label>
            <Select value={adjustmentType} onValueChange={(value) => setAdjustmentType(value as any)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="add">Add Stock</SelectItem>
                <SelectItem value="subtract">Subtract Stock</SelectItem>
                <SelectItem value="set">Set Exact Amount</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="quantity">
              {adjustmentType === "set" ? "New Stock Quantity" : "Quantity to " + (adjustmentType === "add" ? "Add" : "Subtract")}
            </Label>
            <Input
              id="quantity"
              type="number"
              min="0"
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
              placeholder={adjustmentType === "set" ? "Enter new stock amount" : "Enter quantity"}
              required
            />
          </div>

          <div>
            <Label htmlFor="minStock">Minimum Stock Level</Label>
            <Input
              id="minStock"
              type="number"
              min="0"
              value={minStock}
              onChange={(e) => setMinStock(parseInt(e.target.value) || 0)}
            />
          </div>

          <div>
            <Label htmlFor="reason">Reason for Adjustment</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger>
                <SelectValue placeholder="Select reason" />
              </SelectTrigger>
              <SelectContent>
                {adjustmentReasons.map((reasonOption) => (
                  <SelectItem key={reasonOption} value={reasonOption}>
                    {reasonOption}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {reason === "Other" && (
              <Textarea
                className="mt-2"
                placeholder="Please specify the reason..."
                value={reason === "Other" ? "" : reason}
                onChange={(e) => setReason(e.target.value)}
              />
            )}
          </div>

          {/* Preview */}
          <div className="bg-muted p-3 rounded-md space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Current Stock:</span>
              <span>{product.stock} units</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>New Stock:</span>
              <span className={newStock < product.minStock ? "text-destructive font-medium" : "text-foreground"}>
                {newStock} units
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Change:</span>
              <span className={stockDifference >= 0 ? "text-green-600" : "text-red-600"}>
                {stockDifference >= 0 ? "+" : ""}{stockDifference} units
              </span>
            </div>
            {newStock < minStock && (
              <div className="text-xs text-destructive mt-2">
                ⚠️ New stock will be below minimum level ({minStock} units)
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading || quantity === 0}>
              {loading ? "Updating..." : "Update Stock"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}