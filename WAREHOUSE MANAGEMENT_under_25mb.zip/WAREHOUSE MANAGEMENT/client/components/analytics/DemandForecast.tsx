'use client';

import { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

// Mock data - replace with actual API call
const mockSalesData = [
  { week: 'Week 1', sales: 120 },
  { week: 'Week 2', sales: 150 },
  { week: 'Week 3', sales: 180 },
  { week: 'Week 4', sales: 160 },
  { week: 'Week 5', sales: 200 },
  { week: 'Next Week', sales: 230 } // Predicted
];

export function DemandForecast() {
  const [forecastData, setForecastData] = useState({
    labels: mockSalesData.map(data => data.week),
    datasets: [
      {
        label: 'Units Sold',
        data: mockSalesData.map(data => data.sales),
        borderColor: 'rgb(99, 102, 241)',
        backgroundColor: 'rgba(99, 102, 241, 0.5)',
        tension: 0.3,
        borderWidth: 2,
      },
    ],
  });

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Weekly Sales Forecast',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Units Sold',
        },
      },
      x: {
        title: {
          display: true,
          text: 'Week',
        },
      },
    },
  };

  // TODO: Replace with actual API call
  const fetchForecastData = async () => {
    // const response = await fetch('/api/analytics/demand-forecast');
    // const data = await response.json();
    // setForecastData(data);
  };

  useEffect(() => {
    fetchForecastData();
  }, []);

  return (
    <div className="space-y-4">
      <div className="h-96">
        <Line options={options} data={forecastData} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Top Product</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Wireless Earbuds</div>
            <p className="text-xs text-muted-foreground">+12.5% from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Predicted Demand</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">230 units</div>
            <p className="text-xs text-muted-foreground">+15% from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Confidence</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">87%</div>
            <p className="text-xs text-muted-foreground">High confidence forecast</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Simple Card component since we're not importing it from UI
function Card({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
      {children}
    </div>
  );
}

function CardHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={"flex flex-col space-y-1.5 p-6" + (className ? ` ${className}` : '')}
      {...props}
    />
  );
}

function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3
      className={"text-2xl font-semibold leading-none tracking-tight" + (className ? ` ${className}` : '')}
      {...props}
    />
  );
}

function CardContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={"p-6 pt-0" + (className ? ` ${className}` : '')}
      {...props}
    />
  );
}
