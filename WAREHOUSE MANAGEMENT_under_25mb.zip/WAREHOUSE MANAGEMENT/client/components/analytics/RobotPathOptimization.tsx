'use client';

import { useState, useEffect, useRef } from 'react';

// Mock warehouse layout (15x10 grid)
const WAREHOUSE_LAYOUT = [
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 2, 0, 3, 0, 4, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 5, 0, 0, 0, 6, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 7, 0, 8, 0, 9, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
];

// Mock product locations (x, y)
const PRODUCTS = [
  { id: 1, name: 'Earbuds', x: 2, y: 2, quantity: 10 },
  { id: 2, name: 'Speaker', x: 6, y: 2, quantity: 5 },
  { id: 3, name: 'Cable', x: 2, y: 4, quantity: 20 },
  { id: 4, name: 'Mouse', x: 6, y: 4, quantity: 8 },
  { id: 5, name: 'Keyboard', x: 2, y: 6, quantity: 7 },
  { id: 6, name: 'Charger', x: 6, y: 6, quantity: 15 },
];

// Mock robot path (A* pathfinding result)
const generatePath = (start: {x: number, y: number}, end: {x: number, y: number}) => {
  // Simple path generation for demo (would be replaced with A* in production)
  const path = [];
  let current = { ...start };
  
  while (current.x !== end.x || current.y !== end.y) {
    if (current.x < end.x) current.x++;
    else if (current.x > end.x) current.x--;
    else if (current.y < end.y) current.y++;
    else if (current.y > end.y) current.y--;
    
    // Skip if it's the starting point
    if (current.x !== start.x || current.y !== start.y) {
      path.push({ ...current });
    }
  }
  
  return path;
};

export function RobotPathOptimization() {
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);
  const [robotPath, setRobotPath] = useState<Array<{x: number, y: number}>>([]);
  const [efficiency, setEfficiency] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Robot starting position (packing station)
  const robotStart = { x: 8, y: 4 };

  useEffect(() => {
    if (selectedProduct !== null) {
      const product = PRODUCTS.find(p => p.id === selectedProduct);
      if (product) {
        setLoading(true);
        // Simulate path calculation
        setTimeout(() => {
          const path = generatePath(robotStart, { x: product.x, y: product.y });
          setRobotPath(path);
          // Calculate efficiency (shorter path = higher efficiency)
          const maxPossibleDistance = 20; // Approx max distance in our grid
          const distance = path.length;
          const eff = Math.max(0, 100 - (distance / maxPossibleDistance * 100));
          setEfficiency(Math.round(eff));
          setLoading(false);
          drawWarehouse(selectedProduct, path);
        }, 500);
      }
    } else {
      drawWarehouse();
    }
  }, [selectedProduct]);

  const drawWarehouse = (highlightProductId: number | null = null, path: Array<{x: number, y: number}> = []) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const cellSize = 40;
    const padding = 2;
    canvas.width = WAREHOUSE_LAYOUT[0].length * cellSize;
    canvas.height = WAREHOUSE_LAYOUT.length * cellSize;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw warehouse layout
    WAREHOUSE_LAYOUT.forEach((row, y) => {
      row.forEach((cell, x) => {
        // Draw cell
        if (cell === 1) {
          // Wall
          ctx.fillStyle = '#6b7280';
          ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
        } else {
          // Aisle
          ctx.fillStyle = '#f9fafb';
          ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
          ctx.strokeStyle = '#e5e7eb';
          ctx.strokeRect(x * cellSize, y * cellSize, cellSize, cellSize);
        }
      });
    });
    
    // Draw robot path
    if (path.length > 0) {
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 3;
      ctx.beginPath();
      
      // Start from robot position
      ctx.moveTo(
        (robotStart.x + 0.5) * cellSize,
        (robotStart.y + 0.5) * cellSize
      );
      
      // Draw path
      path.forEach((point, i) => {
        ctx.lineTo(
          (point.x + 0.5) * cellSize,
          (point.y + 0.5) * cellSize
        );
      });
      
      ctx.stroke();
      
      // Draw path points
      path.forEach((point, i) => {
        ctx.fillStyle = '#3b82f6';
        ctx.beginPath();
        ctx.arc(
          (point.x + 0.5) * cellSize,
          (point.y + 0.5) * cellSize,
          4,
          0,
          Math.PI * 2
        );
        ctx.fill();
      });
    }
    
    // Draw products
    PRODUCTS.forEach(product => {
      const isHighlighted = product.id === highlightProductId;
      
      // Draw product
      ctx.fillStyle = isHighlighted ? '#10b981' : '#6b7280';
      ctx.beginPath();
      ctx.arc(
        (product.x + 0.5) * cellSize,
        (product.y + 0.5) * cellSize,
        10,
        0,
        Math.PI * 2
      );
      ctx.fill();
      
      // Draw product label
      ctx.fillStyle = isHighlighted ? '#10b981' : '#6b7280';
      ctx.font = '10px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(
        product.name,
        (product.x + 0.5) * cellSize,
        (product.y - 0.2) * cellSize
      );
    });
    
    // Draw robot
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(
      (robotStart.x + 0.5) * cellSize,
      (robotStart.y + 0.5) * cellSize,
      8,
      0,
      Math.PI * 2
    );
    ctx.fill();
    
    // Draw robot label
    ctx.fillStyle = '#ef4444';
    ctx.font = '10px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(
      'Robot',
      (robotStart.x + 0.5) * cellSize,
      (robotStart.y - 0.2) * cellSize
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-1">
          <div className="border rounded-lg overflow-hidden">
            <canvas 
              ref={canvasRef} 
              className="w-full h-auto"
              style={{ backgroundColor: 'hsl(var(--muted))' }}
            />
          </div>
        </div>
        
        <div className="w-full md:w-64 space-y-6">
          <div className="bg-card p-4 rounded-lg shadow">
            <h3 className="font-medium text-foreground mb-3">Order Picker</h3>
            <div className="space-y-2">
              {PRODUCTS.map(product => (
                <button
                  key={product.id}
                  onClick={() => setSelectedProduct(product.id)}
                  className={`w-full text-left p-2 rounded ${
                    selectedProduct === product.id
                      ? 'bg-primary text-primary-foreground'
                      : 'hover:bg-secondary'
                  }`}
                >
                  <div className="font-medium">{product.name}</div>
                  <div className="text-xs text-muted-foreground">Qty: {product.quantity}</div>
                </button>
              ))}
            </div>
          </div>
          
          {selectedProduct && (
            <div className="bg-card p-4 rounded-lg shadow">
              <h3 className="font-medium text-foreground mb-3">Path Details</h3>
              {loading ? (
                <div className="text-center py-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mx-auto"></div>
                  <p className="mt-2 text-sm text-muted-foreground">Calculating optimal path...</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <div className="text-sm text-muted-foreground">Distance</div>
                    <div className="font-medium">{robotPath.length} units</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Efficiency</div>
                    <div className="w-full bg-secondary rounded-full h-2.5">
                      <div 
                        className={`h-2.5 rounded-full ${
                          efficiency > 70 ? 'bg-green-500' : 
                          efficiency > 40 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${efficiency}%` }}
                      ></div>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{efficiency}% efficient</div>
                  </div>
                  <div className="pt-2">
                    <button
                      onClick={() => setSelectedProduct(null)}
                      className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
                    >
                      Clear Selection
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <h4 className="font-medium text-foreground mb-2">Path Optimization</h4>
          <p className="text-sm text-muted-foreground">
            The system calculates the most efficient path for robots to pick items, 
            reducing travel time and increasing throughput.
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h4 className="font-medium text-foreground mb-2">Real-time Updates</h4>
          <p className="text-sm text-muted-foreground">
            Paths are recalculated in real-time based on warehouse conditions, 
            obstacles, and other moving robots.
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h4 className="font-medium text-foreground mb-2">Efficiency Metrics</h4>
          <p className="text-sm text-muted-foreground">
            Track and improve robot performance with detailed efficiency metrics 
            and path optimization suggestions.
          </p>
        </div>
      </div>
    </div>
  );
}
