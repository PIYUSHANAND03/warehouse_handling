'use client';

import { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

// Mock data - replace with actual API call
const mockMovementData = [
  { product: 'Wireless Earbuds', currentZone: 'A1', suggestedZone: 'A2', movementScore: 0.85 },
  { product: 'Bluetooth Speaker', currentZone: 'B3', suggestedZone: 'A1', movementScore: 0.92 },
  { product: 'USB-C Cable', currentZone: 'C2', suggestedZone: 'A3', movementScore: 0.78 },
  { product: 'Wireless Mouse', currentZone: 'A4', suggestedZone: 'B1', movementScore: 0.65 },
  { product: 'Mechanical Keyboard', currentZone: 'D1', suggestedZone: 'B2', movementScore: 0.88 },
];

export function StorageOptimization() {
  const [optimizationData, setOptimizationData] = useState({
    labels: mockMovementData.map(data => data.product),
    datasets: [
      {
        label: 'Movement Score',
        data: mockMovementData.map(data => data.movementScore * 100),
        backgroundColor: 'rgba(99, 102, 241, 0.7)',
        borderColor: 'rgba(99, 102, 241, 1)',
        borderWidth: 1,
      },
    ],
  });

  const options = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        title: {
          display: true,
          text: 'Movement Score (%)',
        },
      },
    },
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Product Movement Analysis',
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const dataIndex = context.dataIndex;
            const item = mockMovementData[dataIndex];
            return [
              `Current: ${item.currentZone}`,
              `Suggested: ${item.suggestedZone}`,
              `Score: ${(item.movementScore * 100).toFixed(1)}%`
            ];
          }
        }
      }
    },
  };

  // TODO: Replace with actual API call
  const fetchOptimizationData = async () => {
    // const response = await fetch('/api/analytics/storage-optimization');
    // const data = await response.json();
    // setOptimizationData(data);
  };

  useEffect(() => {
    fetchOptimizationData();
  }, []);

  return (
    <div className="space-y-6">
      <div className="h-96">
        <Bar options={options} data={optimizationData} />
      </div>
      
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Recommended Relocations</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-border">
            <thead className="bg-secondary">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Product</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Current Zone</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Suggested Zone</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Score</th>
              </tr>
            </thead>
            <tbody className="bg-card divide-y divide-border">
              {mockMovementData.map((item, index) => (
                <tr key={index} className="hover:bg-secondary">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">{item.product}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{item.currentZone}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-primary/20 text-primary">
                      {item.suggestedZone}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                    <div className="w-full bg-secondary rounded-full h-2.5">
                      <div 
                        className={`h-2.5 rounded-full ${item.movementScore > 0.8 ? 'bg-green-500' : item.movementScore > 0.6 ? 'bg-yellow-500' : 'bg-red-500'}`}
                        style={{ width: `${item.movementScore * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-xs text-muted-foreground mt-1 block">
                      {(item.movementScore * 100).toFixed(1)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="p-4 bg-blue-50 rounded-lg">
        <h4 className="font-medium text-blue-800">Optimization Suggestion</h4>
        <p className="text-sm text-blue-700 mt-1">
          Moving high-movement items closer to packing stations could reduce picking time by an estimated 15-20%.
        </p>
      </div>
    </div>
  );
}
