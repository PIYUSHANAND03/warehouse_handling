import { Loader2, Moon, Sun } from "lucide-react"

export const Icons = {
  spinner: Loader2,
  sun: Sun,
  moon: Moon,
}
