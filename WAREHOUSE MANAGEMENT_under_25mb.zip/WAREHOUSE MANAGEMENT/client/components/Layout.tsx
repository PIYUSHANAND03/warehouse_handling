import { ReactNode, useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { ProfileMenu } from "./ProfileMenu";
import { toast } from "@/hooks/use-toast";
import { Logo } from "./Logo";

interface LayoutProps {
  children: ReactNode;
  showSidebar?: boolean;
  showHeader?: boolean;
}

export function Layout({ children, showSidebar = true, showHeader = true }: LayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeNav, setActiveNav] = useState("dashboard");

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Update active nav based on current route
    const path = location.pathname;
    if (path === "/") setActiveNav("dashboard");
    else if (path.includes("/stock")) setActiveNav("inventory");
    else if (path.includes("/orders")) setActiveNav("orders");
    else if (path.includes("/pending-shipments")) setActiveNav("shipping");
    else if (path.includes("/receiving")) setActiveNav("receiving");
    else if (path.includes("/workers")) setActiveNav("workers");
    else if (path.includes("/generate-report")) setActiveNav("reports");
    else if (path.includes("/sellers")) setActiveNav("sellers");
    else if (path.includes("/settings")) setActiveNav("settings");
    else if (path.includes("/analytics")) setActiveNav("analytics");
  }, [location]);

  const formatTime = (date: Date) => date.toLocaleTimeString("en-US", { hour12: false });

  const handleNavClick = (navItem: string, path?: string) => {
    setActiveNav(navItem);
    if (path) {
      navigate(path);
    }
  };

  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: "fa-home", path: "/" },
    { id: "inventory", label: "Inventory", icon: "fa-box-archive", path: "/stock" },
    { id: "orders", label: "Orders", icon: "fa-clipboard-list", path: "/orders" },
    { id: "shipping", label: "Shipping", icon: "fa-truck-fast", path: "/pending-shipments" },
    { id: "receiving", label: "Receiving", icon: "fa-dolly", path: "/receiving" },
    { id: "sellers", label: "Customers", icon: "fa-users-gear", path: "/sellers" },
    { id: "workers", label: "Workers", icon: "fa-users", path: "/workers" },
    { id: "analytics", label: "Analytics", icon: "fa-chart-line", path: "/analytics" },
    { id: "reports", label: "Reports", icon: "fa-chart-pie", path: "/generate-report" },
    { id: "settings", label: "Settings", icon: "fa-gear", path: "/settings" },
  ];

  return (
    <div className="flex h-screen bg-background text-foreground font-sans overflow-hidden">
      {/* Sidebar */}
      {showSidebar && (
        <aside className="w-64 bg-card p-6 flex flex-col flex-shrink-0 border-r border-border">
          <div className="flex items-center gap-3 mb-10">
            <div className="text-primary">
              <Logo />
            </div>
            <div className="flex flex-col leading-tight">
              <h1 className="text-xl font-semibold">Warely</h1>
              <span className="text-xs text-muted-foreground">Modern Warehouse Management</span>
            </div>
          </div>

          <nav className="flex-1">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => handleNavClick(item.id, item.path)}
                    className={`w-full flex items-center p-3.5 rounded-lg text-left font-medium transition-all duration-200 ${
                      activeNav === item.id
                        ? "bg-primary text-primary-foreground font-semibold"
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                    }`}
                  >
                    <i className={`fas ${item.icon} w-6 text-center mr-4`}></i>
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </aside>
      )}

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-8 overflow-y-auto flex flex-col">
        {/* Header */}
        {showHeader && (
          <header className="flex justify-between items-center mb-6">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const term = searchTerm.trim();
                navigate(term ? `/stock?search=${encodeURIComponent(term)}` : "/stock");
              }}
              className="relative w-96"
            >
              <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"></i>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search for items, orders, or SKUs..."
                className="w-full pl-12 pr-4 py-3 bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </form>

            <div className="flex items-center gap-5">
              <div className="flex items-center gap-2 bg-card px-4 py-2 rounded-lg border border-border">
                <i className="fas fa-clock text-muted-foreground"></i>
                <span className="font-semibold tracking-wide">{formatTime(currentTime)}</span>
              </div>
              <button
                className="text-muted-foreground hover:text-foreground transition-colors"
                onClick={() => toast({ title: "Notifications", description: "No new notifications" })}
              >
                <i className="fas fa-bell text-xl"></i>
              </button>
              <ProfileMenu />
            </div>
          </header>
        )}

        {/* Page Content */}
        <div className="flex-1">{children}</div>
      </main>
    </div>
  );
}
