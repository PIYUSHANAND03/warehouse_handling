import { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, Bluetooth, RotateCw, Settings, X } from 'lucide-react';
import * as ZXing from '@zxing/library';
import { Button } from './ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';

interface BarcodeScannerProps {
  onScan: (result: string | ZXing.Result) => void;
  onClose: () => void;
}

export function BarcodeScanner({ onScan, onClose }: BarcodeScannerProps) {
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bluetoothDevice, setBluetoothDevice] = useState<BluetoothDevice | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanMode, setScanMode] = useState<'camera' | 'bluetooth'>('camera');
  const videoRef = useRef<HTMLVideoElement>(null);
  const codeReaderRef = useRef<ZXing.BrowserMultiFormatReader | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanningIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Toggle between front and back camera
  const toggleFacingMode = useCallback(() => {
    setFacingMode(prevMode => (prevMode === 'user' ? 'environment' : 'user'));
  }, []);

  // Function to disconnect from a Bluetooth device
  const disconnectBluetoothDevice = useCallback(() => {
    if (bluetoothDevice?.gatt?.connected) {
      bluetoothDevice.gatt.disconnect();
    }
    setBluetoothDevice(null);
    setError('Bluetooth device disconnected');
  }, [bluetoothDevice]);

  // Function to handle manual barcode entry
  const handleManualEntry = useCallback(() => {
    const barcode = prompt('Please enter the barcode:');
    if (barcode) {
      onScan(barcode);
    }
  }, [onScan]);

  // Function to connect to a Bluetooth device
  const connectToBluetoothDevice = useCallback(async () => {
    if (!('bluetooth' in navigator)) {
      setError('Web Bluetooth is not supported in your browser. Please use Chrome, Edge, or Opera on desktop or Android.');
      return;
    }

    try {
      setIsConnecting(true);
      setError(null);
      
      // Request a Bluetooth device with specific filters for barcode scanners
      const device = await navigator.bluetooth.requestDevice({
        filters: [
          // Common barcode scanner service UUIDs
          { services: ['00001101-0000-1000-8000-00805f9b34fb'] }, // Standard Serial Port Service
          { services: ['0000ffe0-0000-1000-8000-00805f9b34fb'] }, // Common BLE UART service
        ],
        // Optional: You can also filter by name prefix if you know your device name
        // namePrefix: 'YourScannerName',
        optionalServices: [
          '00001101-0000-1000-8000-00805f9b34fb',
          '0000ffe0-0000-1000-8000-00805f9b34fb',
          '0000ffe5-0000-1000-8000-00805f9b34fb', // Common for barcode scanner data
          '0000ffe9-0000-1000-8000-00805f9b34fb', // Common for barcode scanner control
        ],
      });

      if (!device) {
        throw new Error('No device selected');
      }

      // Store the device for later use
      setBluetoothDevice(device);
      
      // Listen for device disconnection
      device.addEventListener('gattserverdisconnected', () => {
        setBluetoothDevice(null);
        setError('Bluetooth device disconnected');
      });
      
      // Connect to the GATT server
      const server = await device.gatt?.connect();
      if (!server) {
        throw new Error('Could not connect to the device');
      }
      
      console.log('Connected to Bluetooth device:', device.name);
      // Try to find the barcode scanner service
      try {
        const services = await server.getPrimaryServices();
        console.log('Available services:', services.map(s => s.uuid));
      } catch (serviceError) {
        console.warn('Could not access services, but continuing anyway:', serviceError);
      }
    } catch (err) {
      console.error('Bluetooth connection error:', err);
    } finally {
      setIsConnecting(false);
    }
  }, []);

  // Initialize the barcode reader with specific formats
  const initBarcodeReader = useCallback(() => {
    try {
      const hints = new Map<ZXing.DecodeHintType, any>();
      hints.set(ZXing.DecodeHintType.POSSIBLE_FORMATS, [
        ZXing.BarcodeFormat.QR_CODE,
        ZXing.BarcodeFormat.CODE_128,
        ZXing.BarcodeFormat.CODE_39,
        ZXing.BarcodeFormat.CODE_93,
        ZXing.BarcodeFormat.EAN_13,
        ZXing.BarcodeFormat.EAN_8,
        ZXing.BarcodeFormat.UPC_A,
        ZXing.BarcodeFormat.UPC_E,
        ZXing.BarcodeFormat.ITF,
        ZXing.BarcodeFormat.CODABAR,
        ZXing.BarcodeFormat.DATA_MATRIX,
        ZXing.BarcodeFormat.PDF_417,
      ]);
      
      hints.set(ZXing.DecodeHintType.TRY_HARDER, true);
      
      const reader = new ZXing.BrowserMultiFormatReader(undefined, 500);
      reader.hints = hints;
      return reader;
    } catch (error) {
      console.error('Error initializing barcode reader:', error);
      setError('Failed to initialize barcode scanner');
      return null;
    }
  }, []);

  // Function to stop scanning
  const stopScanning = useCallback(() => {
    if (codeReaderRef.current) {
      codeReaderRef.current.reset();
    }
    if (scanningIntervalRef.current) {
      clearInterval(scanningIntervalRef.current);
      scanningIntervalRef.current = null;
    }
    setIsScanning(false);
  }, []);

  // Function to start the camera and begin barcode scanning
  const startCamera = useCallback(async () => {
    if (!codeReaderRef.current || !videoRef.current) {
      console.error('Code reader or video ref not available');
      return;
    }

    try {
      setIsScanning(true);
      setError(null);
      
      // Get available video devices
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter(device => device.kind === 'videoinput');
      
      if (videoDevices.length === 0) {
        throw new Error('No video devices found');
      }

      console.log('Available video devices:', videoDevices);
      
      // Try to find the back camera first, fall back to any available camera
      const backCamera = videoDevices.find(device => 
        device.label.toLowerCase().includes('back') || 
        device.label.toLowerCase().includes('rear') ||
        device.label.toLowerCase().includes('environment')
      );
      
      const deviceId = backCamera?.deviceId || videoDevices[0]?.deviceId;
      console.log('Using device:', backCamera?.label || videoDevices[0]?.label);
      
      // Reset the code reader
      codeReaderRef.current.reset();
      
      // Start decoding from the camera
      await codeReaderRef.current.decodeFromVideoDevice(
        deviceId,
        videoRef.current,
        (result, error) => {
          if (result) {
            const barcodeText = result.getText();
            console.log('Barcode detected:', barcodeText);
            // Stop scanning after successful detection
            stopScanning();
            // Call onScan with the barcode text
            onScan(barcodeText);
            // Close the scanner after a short delay
            setTimeout(() => onClose(), 500);
          }
          if (error) {
            if (!(error instanceof ZXing.NotFoundException)) {
              console.error('Barcode scan error:', error);
              setError(error.message || 'Error scanning barcode');
            }
          }
        }
      );
      
      // Add a small delay to ensure the camera is properly started
      await new Promise(resolve => setTimeout(resolve, 500));
      
    } catch (err) {
      console.error('Camera initialization error:', err);
      setError(`Failed to access camera: ${err.message}`);
      setIsScanning(false);
    }
  }, [onScan]);

  // Initialize and clean up barcode reader
  useEffect(() => {
    codeReaderRef.current = initBarcodeReader();
    
    if (scanMode === 'camera' && videoRef.current) {
      startCamera();
    } else if (scanMode === 'bluetooth') {
      stopScanning();
    }
    
    return () => {
      stopScanning();
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }
    };
  }, [initBarcodeReader, scanMode, startCamera, stopScanning]);

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
      <div className="bg-card rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Scan Barcode</h2>
          <button 
            onClick={onClose} 
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <Tabs 
          defaultValue="camera" 
          className="w-full"
          onValueChange={(value) => setScanMode(value as 'camera' | 'bluetooth')}
        >
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="camera" className="flex items-center gap-2">
              <Camera className="h-4 w-4" />
              Camera
            </TabsTrigger>
            <TabsTrigger value="bluetooth" className="flex items-center gap-2">
              <Bluetooth className="h-4 w-4" />
              Bluetooth
            </TabsTrigger>
          </TabsList>

          <TabsContent value="camera">
            <div className="relative aspect-square bg-black rounded-lg overflow-hidden mb-4">
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                autoPlay
                playsInline
                muted
              />
              {isScanning ? (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="border-4 border-green-500 rounded-lg w-3/4 h-1/2 relative">
                    <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-green-500"></div>
                    <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-green-500"></div>
                    <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-green-500"></div>
                    <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-green-500"></div>
                  </div>
                </div>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white">
                  <p>Camera not available</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="bluetooth">
            <div className="aspect-square bg-secondary rounded-lg flex items-center justify-center mb-4">
              {bluetoothDevice ? (
                <div className="text-center p-4">
                  <Bluetooth className="h-12 w-12 mx-auto text-blue-500 mb-2" />
                  <p className="font-medium">{bluetoothDevice.name || 'Bluetooth Device'}</p>
                  <p className="text-sm text-muted-foreground">Connected</p>
                </div>
              ) : (
                <div className="text-center p-4">
                  <Bluetooth className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                  <p className="text-muted-foreground">No device connected</p>
                  <Button 
                    onClick={connectToBluetoothDevice}
                    disabled={isConnecting}
                    className="mt-2"
                    variant="outline"
                  >
                    {isConnecting ? 'Connecting...' : 'Connect Device'}
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded-md flex justify-between items-center">
            <span>{error}</span>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => scanMode === 'camera' ? startCamera() : connectToBluetoothDevice()}
            >
              Retry
            </Button>
          </div>
        )}

        <div className="space-y-2">
          <Button 
            onClick={handleManualEntry}
            className="w-full"
            variant="outline"
          >
            Enter Barcode Manually
          </Button>
          
          <div className="grid grid-cols-2 gap-2">
            <Button 
              variant="outline"
              className="w-full flex items-center gap-2"
              onClick={toggleFacingMode}
            >
              <Settings className="h-4 w-4" />
              Camera Settings
            </Button>
            
            <Button 
              variant="outline"
              className="w-full flex items-center gap-2"
              onClick={onClose}
            >
              <X className="h-4 w-4" />
              Close Scanner
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}