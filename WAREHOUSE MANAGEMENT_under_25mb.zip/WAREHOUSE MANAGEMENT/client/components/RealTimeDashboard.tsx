import { useState, useEffect } from 'react';
import { useWebSocket } from '@/hooks/useWebSocket';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Activity, 
  Users, 
  Package, 
  ShoppingCart, 
  Truck, 
  Bell, 
  Wifi, 
  WifiOff,
  Send,
  Eye,
  Clock
} from 'lucide-react';
import { format } from 'date-fns';

export const RealTimeDashboard = () => {
  const {
    isConnected,
    connectionId,
    inventoryUpdates,
    orderUpdates,
    recentActivities,
    liveStats,
    activeUsers,
    sendInventoryUpdate,
    sendOrderUpdate,
    sendNotification,
    trackActivity
  } = useWebSocket('http://localhost:8080', 'Demo User');

  // Form states for testing real-time features
  const [newInventory, setNewInventory] = useState({
    name: '',
    oldStock: '',
    newStock: '',
    location: '',
    changeType: 'adjustment' as 'addition' | 'reduction' | 'adjustment'
  });

  const [newOrder, setNewOrder] = useState({
    customerName: '',
    status: 'pending' as 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled'
  });

  const [notification, setNotification] = useState({
    title: '',
    message: '',
    type: 'info' as 'info' | 'warning' | 'error' | 'success'
  });

  // Handle inventory update submission
  const handleInventorySubmit = () => {
    if (!newInventory.name || !newInventory.newStock) return;
    
    sendInventoryUpdate({
      name: newInventory.name,
      oldStock: parseInt(newInventory.oldStock) || 0,
      newStock: parseInt(newInventory.newStock),
      location: newInventory.location || 'Zone A-1',
      changeType: newInventory.changeType
    });

    // Reset form
    setNewInventory({
      name: '',
      oldStock: '',
      newStock: '',
      location: '',
      changeType: 'adjustment'
    });

    trackActivity('inventory_update_sent', 'realtime-dashboard');
  };

  // Handle order update submission
  const handleOrderSubmit = () => {
    if (!newOrder.customerName) return;
    
    sendOrderUpdate({
      customerName: newOrder.customerName,
      status: newOrder.status
    });

    // Reset form
    setNewOrder({
      customerName: '',
      status: 'pending'
    });

    trackActivity('order_update_sent', 'realtime-dashboard');
  };

  // Handle notification submission
  const handleNotificationSubmit = () => {
    if (!notification.title || !notification.message) return;
    
    sendNotification({
      title: notification.title,
      message: notification.message,
      type: notification.type
    });

    // Reset form
    setNotification({
      title: '',
      message: '',
      type: 'info'
    });

    trackActivity('notification_sent', 'realtime-dashboard');
  };

  const getChangeColor = (changeType: string) => {
    switch (changeType) {
      case 'addition': return 'text-green-600 bg-green-100';
      case 'reduction': return 'text-red-600 bg-red-100';
      case 'adjustment': return 'text-blue-600 bg-blue-100';
      default: return 'text-muted-foreground bg-secondary';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'processing': return 'text-blue-600 bg-blue-100';
      case 'shipped': return 'text-purple-600 bg-purple-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'cancelled': return 'text-red-600 bg-red-100';
      default: return 'text-muted-foreground bg-secondary';
    }
  };

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Real-time Dashboard</h1>
          <p className="text-muted-foreground">WebSocket Learning Demo</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${
            isConnected ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}>
            {isConnected ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />}
            <span className="text-sm font-medium">
              {isConnected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
          
          <Badge variant="secondary" className="flex items-center space-x-1">
            <Users className="h-3 w-3" />
            <span>{activeUsers} active</span>
          </Badge>
        </div>
      </div>

      {/* Live Stats */}
      {liveStats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Total Orders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{liveStats.totalOrders}</div>
              <p className="text-xs text-muted-foreground">
                Last updated: {format(new Date(liveStats.timestamp), 'HH:mm:ss')}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Truck className="h-4 w-4 mr-2" />
                Pending Shipments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{liveStats.pendingShipments}</div>
              <p className="text-xs text-muted-foreground">Real-time count</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Package className="h-4 w-4 mr-2" />
                Low Stock Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{liveStats.lowStockItems}</div>
              <p className="text-xs text-muted-foreground">Needs attention</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Users className="h-4 w-4 mr-2" />
                Active Users
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{liveStats.activeUsers}</div>
              <p className="text-xs text-muted-foreground">Currently online</p>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Testing Controls */}
        <div className="space-y-6">
          {/* Send Inventory Update */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="h-5 w-5 mr-2" />
                Send Inventory Update
              </CardTitle>
              <CardDescription>
                Test real-time inventory synchronization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="inv-name">Product Name</Label>
                  <Input
                    id="inv-name"
                    value={newInventory.name}
                    onChange={(e) => setNewInventory({...newInventory, name: e.target.value})}
                    placeholder="Cotton T-Shirts"
                  />
                </div>
                <div>
                  <Label htmlFor="inv-location">Location</Label>
                  <Input
                    id="inv-location"
                    value={newInventory.location}
                    onChange={(e) => setNewInventory({...newInventory, location: e.target.value})}
                    placeholder="Zone A-1"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="inv-old">Old Stock</Label>
                  <Input
                    id="inv-old"
                    type="number"
                    value={newInventory.oldStock}
                    onChange={(e) => setNewInventory({...newInventory, oldStock: e.target.value})}
                    placeholder="50"
                  />
                </div>
                <div>
                  <Label htmlFor="inv-new">New Stock</Label>
                  <Input
                    id="inv-new"
                    type="number"
                    value={newInventory.newStock}
                    onChange={(e) => setNewInventory({...newInventory, newStock: e.target.value})}
                    placeholder="75"
                  />
                </div>
                <div>
                  <Label htmlFor="inv-type">Change Type</Label>
                  <Select 
                    value={newInventory.changeType} 
                    onValueChange={(value: 'addition' | 'reduction' | 'adjustment') => 
                      setNewInventory({...newInventory, changeType: value})
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="addition">Addition</SelectItem>
                      <SelectItem value="reduction">Reduction</SelectItem>
                      <SelectItem value="adjustment">Adjustment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Button onClick={handleInventorySubmit} className="w-full">
                <Send className="h-4 w-4 mr-2" />
                Send Update
              </Button>
            </CardContent>
          </Card>

          {/* Send Order Update */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Send Order Update
              </CardTitle>
              <CardDescription>
                Test real-time order status changes
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="order-customer">Customer Name</Label>
                  <Input
                    id="order-customer"
                    value={newOrder.customerName}
                    onChange={(e) => setNewOrder({...newOrder, customerName: e.target.value})}
                    placeholder="Fashion Boutique"
                  />
                </div>
                <div>
                  <Label htmlFor="order-status">Status</Label>
                  <Select 
                    value={newOrder.status} 
                    onValueChange={(value: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled') => 
                      setNewOrder({...newOrder, status: value})
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="shipped">Shipped</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Button onClick={handleOrderSubmit} className="w-full">
                <Send className="h-4 w-4 mr-2" />
                Send Update
              </Button>
            </CardContent>
          </Card>

          {/* Send Notification */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="h-5 w-5 mr-2" />
                Send Notification
              </CardTitle>
              <CardDescription>
                Broadcast notifications to all users
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="notif-title">Title</Label>
                <Input
                  id="notif-title"
                  value={notification.title}
                  onChange={(e) => setNotification({...notification, title: e.target.value})}
                  placeholder="System Update"
                />
              </div>
              <div>
                <Label htmlFor="notif-message">Message</Label>
                <Input
                  id="notif-message"
                  value={notification.message}
                  onChange={(e) => setNotification({...notification, message: e.target.value})}
                  placeholder="New features available"
                />
              </div>
              <div>
                <Label htmlFor="notif-type">Type</Label>
                <Select 
                  value={notification.type} 
                  onValueChange={(value: 'info' | 'warning' | 'error' | 'success') => 
                    setNotification({...notification, type: value})
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button onClick={handleNotificationSubmit} className="w-full">
                <Send className="h-4 w-4 mr-2" />
                Broadcast
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Real-time Feeds */}
        <div className="space-y-6">
          {/* Live Inventory Updates */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="h-5 w-5 mr-2" />
                Live Inventory Updates
                <Badge className="ml-2">{inventoryUpdates.length}</Badge>
              </CardTitle>
              <CardDescription>
                Real-time inventory changes from all users
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {inventoryUpdates.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No inventory updates yet. Send one to test!
                  </p>
                ) : (
                  inventoryUpdates.map((update, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{update.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {update.location} • {update.oldStock} → {update.newStock}
                        </p>
                      </div>
                      <div className="flex flex-col items-end space-y-1">
                        <Badge className={`text-xs ${getChangeColor(update.changeType)}`}>
                          {update.changeType}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(update.timestamp), 'HH:mm')}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Live Order Updates */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Live Order Updates
                <Badge className="ml-2">{orderUpdates.length}</Badge>
              </CardTitle>
              <CardDescription>
                Real-time order status changes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {orderUpdates.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No order updates yet. Send one to test!
                  </p>
                ) : (
                  orderUpdates.map((update, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{update.orderId}</p>
                        <p className="text-xs text-muted-foreground">{update.customerName}</p>
                      </div>
                      <div className="flex flex-col items-end space-y-1">
                        <Badge className={`text-xs ${getStatusColor(update.status)}`}>
                          {update.status}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(update.timestamp), 'HH:mm')}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Live User Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2" />
                Live User Activities
                <Badge className="ml-2">{recentActivities.length}</Badge>
              </CardTitle>
              <CardDescription>
                Real-time user actions across the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {recentActivities.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No activities yet. Navigate around to generate activity!
                  </p>
                ) : (
                  recentActivities.map((activity, index) => (
                    <div key={index} className="flex items-center space-x-3 text-xs">
                      <Clock className="h-3 w-3 text-muted-foreground" />
                      <span className="font-medium">{activity.user}</span>
                      <span className="text-muted-foreground">{activity.activity}</span>
                      <span className="text-muted-foreground">on {activity.location}</span>
                      <span className="text-muted-foreground ml-auto">
                        {format(new Date(activity.timestamp), 'HH:mm:ss')}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Connection Info */}
      {connectionId && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Connection Info</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground font-mono">
              Connection ID: {connectionId}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};