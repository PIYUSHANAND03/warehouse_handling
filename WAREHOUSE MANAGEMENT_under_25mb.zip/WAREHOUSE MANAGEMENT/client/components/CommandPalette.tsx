import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/ui/command";
import {
  Home,
  Boxes,
  PackageOpen,
  Users,
  Truck,
  ClipboardList,
  FileBarChart2,
  Plus,
  Settings,
  Moon,
  Sun,
  Monitor,
  FlameKindling,
  Palette,
} from "lucide-react";

// Local helpers to sync theme/accent immediately with the DOM and persist to localStorage
function applyTheme(mode: string) {
  try {
    const root = document.documentElement;
    const w = window as any;
    // Clean system listener if switching away from system
    if (w.__themeMql && w.__themeListener) {
      w.__themeMql.removeEventListener?.("change", w.__themeListener);
      w.__themeMql = null;
      w.__themeListener = null;
    }

    root.classList.remove("dark", "midnight-ember");

    if (mode === "system") {
      const mql = window.matchMedia("(prefers-color-scheme: dark)");
      const set = () => {
        root.classList.remove("dark", "midnight-ember");
        if (mql.matches) root.classList.add("dark");
      };
      set();
      if (mql.addEventListener) mql.addEventListener("change", set);
      else (mql as any).addListener?.(set);
      (w.__themeMql = mql), (w.__themeListener = set);
    } else {
      if (mode === "dark") root.classList.add("dark");
      if (mode === "midnight-ember") root.classList.add("midnight-ember");
    }

    localStorage.setItem("theme", mode);
  } catch {}
}

function applyAccent(hex: string) {
  try {
    const root = document.documentElement as HTMLElement;
    root.style.setProperty("--primary", hex);
    localStorage.setItem("accent", hex);
  } catch {}
}

const ACCENTS: { name: string; hex: string }[] = [
  { name: "Blue", hex: "#3b82f6" },
  { name: "Emerald", hex: "#10b981" },
  { name: "Violet", hex: "#8b5cf6" },
  { name: "Amber", hex: "#f59e0b" },
  { name: "Rose", hex: "#f43f5e" },
];

export default function CommandPalette() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  // Keyboard shortcut: Ctrl/Cmd + K to toggle
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const go = useCallback(
    (path: string) => {
      navigate(path);
      setOpen(false);
    },
    [navigate],
  );

  const themeItems = useMemo(
    () => [
      { label: "Light", icon: Sun, action: () => applyTheme("light") },
      { label: "Dark", icon: Moon, action: () => applyTheme("dark") },
      { label: "System", icon: Monitor, action: () => applyTheme("system") },
      {
        label: "Midnight Ember",
        icon: FlameKindling,
        action: () => applyTheme("midnight-ember"),
      },
    ],
    [],
  );

  return (
    <>
      
      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Search pages, actions, or change theme…" />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>

          <CommandGroup heading="Navigation">
            <CommandItem onSelect={() => go("/")}> 
              <Home className="mr-2" /> Dashboard
              <CommandShortcut>G H</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/stock")}>
              <Boxes className="mr-2" /> Stock
              <CommandShortcut>G S</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/orders")}>
              <ClipboardList className="mr-2" /> Orders
              <CommandShortcut>G O</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/sellers")}>
              <Users className="mr-2" /> Sellers
              <CommandShortcut>G E</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/receiving")}>
              <PackageOpen className="mr-2" /> Receiving
              <CommandShortcut>G R</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/pending-shipments")}>
              <Truck className="mr-2" /> Pending shipments
              <CommandShortcut>G P</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/workers")}>
              <Users className="mr-2" /> Workers
              <CommandShortcut>G W</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/settings")}>
              <Settings className="mr-2" /> Settings
              <CommandShortcut>G ,</CommandShortcut>
            </CommandItem>
          </CommandGroup>

          <CommandSeparator />

          <CommandGroup heading="Actions">
            <CommandItem onSelect={() => go("/new-order")}>
              <Plus className="mr-2" /> New order
              <CommandShortcut>N O</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/add-product")}>
              <Plus className="mr-2" /> Add product
              <CommandShortcut>A P</CommandShortcut>
            </CommandItem>
            <CommandItem onSelect={() => go("/generate-report")}>
              <FileBarChart2 className="mr-2" /> Generate report
              <CommandShortcut>G R</CommandShortcut>
            </CommandItem>
          </CommandGroup>

          <CommandSeparator />

          <CommandGroup heading="Theme">
            {themeItems.map(({ label, icon: Icon, action }) => (
              <CommandItem
                key={label}
                onSelect={() => {
                  action();
                  setOpen(false);
                }}
              >
                <Icon className="mr-2" /> {label}
              </CommandItem>
            ))}
          </CommandGroup>

          <CommandGroup heading="Accent color">
            {ACCENTS.map((c) => (
              <CommandItem
                key={c.name}
                onSelect={() => {
                  applyAccent(c.hex);
                  setOpen(false);
                }}
              >
                <div
                  className="mr-2 size-4 rounded-full border"
                  style={{ backgroundColor: c.hex }}
                />
                <Palette className="mr-2 opacity-60" /> {c.name}
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  );
}
