// This file helps TypeScript understand your path aliases
declare module '@/components/ui/*' {
  import type { ComponentType, SVGProps } from 'react';
  const Component: ComponentType<SVGProps<SVGSVGElement>>;
  export = Component;
}
