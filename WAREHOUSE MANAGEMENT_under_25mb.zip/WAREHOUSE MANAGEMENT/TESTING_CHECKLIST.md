# 🧪 Inventory Page Testing Checklist

## Pre-Testing Setup
1. ✅ Start backend server: `npm run dev:server`
2. ✅ Start frontend: `npm run dev` 
3. ✅ Navigate to `http://localhost:5173/stock`

## Core Functionality Tests

### 🔍 Search & Filter Tests
- [ ] **Search functionality**: Type product name in search box (try "cotton", "wireless", "leather")
- [ ] **Category filter**: Use dropdown to filter by category (Clothes, Electronics, etc.)
- [ ] **Status filter**: Filter by stock status (In Stock, Low Stock, Out of Stock)
- [ ] **Combined filters**: Try search + category + status together
- [ ] **Clear filters**: Use clear button to reset all filters

### 📊 View Mode Tests
- [ ] **Grid view**: Default card-based layout displays properly
- [ ] **Table view**: Switch to table view using toggle button
- [ ] **Responsive design**: Test both views on different screen sizes
- [ ] **Statistics cards**: Verify stats update based on filtered data

### ✏️ Product Management Tests
- [ ] **Add new product**: Click "Add Item" button, navigates to `/add-product`
- [ ] **Create product**: Fill form with all required fields and save
- [ ] **Edit existing product**: Click edit button/dropdown menu
- [ ] **Update product details**: Modify name, category, price, etc.
- [ ] **Delete product**: Use delete button with confirmation dialog
- [ ] **Bulk selection**: Select multiple items using checkboxes

### 📦 Stock Management Tests
- [ ] **Stock adjustment**: Click "Adjust" button on any product
- [ ] **Add stock**: Choose "Add Stock" and specify quantity
- [ ] **Subtract stock**: Choose "Subtract Stock" and specify quantity
- [ ] **Set exact stock**: Choose "Set Exact Amount" option
- [ ] **Minimum stock levels**: Update minimum stock thresholds
- [ ] **Status updates**: Verify status changes (in-stock → low-stock → out-of-stock)

### 🔄 Bulk Operations Tests
- [ ] **Multi-selection**: Select 2-3 products using checkboxes
- [ ] **Select all**: Use "Select all" checkbox to select all items
- [ ] **Bulk delete**: Use bulk actions dropdown to delete selected items
- [ ] **Bulk category update**: Change category for multiple products at once
- [ ] **Clear selection**: Clear all selections using clear button

## API Integration Tests

### 📡 Backend Communication
- [ ] **Data loading**: Products load from `http://localhost:3000/api/products`
- [ ] **Error handling**: Disconnect backend and verify error messages
- [ ] **Loading states**: Check loading spinners/skeletons appear
- [ ] **Real-time updates**: Changes reflect immediately in the UI

### 🔄 CRUD Operations
- [ ] **Create**: POST new product via Add Product page
- [ ] **Read**: GET products with filtering parameters
- [ ] **Update**: PUT product changes via edit dialog
- [ ] **Delete**: DELETE individual products
- [ ] **Stock updates**: PATCH stock changes via adjust dialog
- [ ] **Bulk delete**: DELETE multiple products via bulk API
- [ ] **Bulk update**: PATCH multiple products via bulk API

## UI/UX Tests

### 🎨 Visual Elements
- [ ] **Status badges**: Color-coded status indicators display correctly
- [ ] **Category badges**: Different colored category badges
- [ ] **Loading skeletons**: Smooth loading animations
- [ ] **Toast notifications**: Success/error messages appear
- [ ] **Icons**: All FontAwesome icons display properly

### 📱 Responsive Design
- [ ] **Mobile view**: Test on mobile screen size (< 768px)
- [ ] **Tablet view**: Test on tablet screen size (768px - 1024px)
- [ ] **Desktop view**: Test on large screens (> 1024px)
- [ ] **Grid responsive**: Card layout adapts to screen size
- [ ] **Table responsive**: Table scrolls horizontally on small screens

## Sample Test Data Verification

### 📋 Pre-loaded Products
- [ ] **Total count**: Verify 15 products are loaded initially
- [ ] **Categories**: 6 different categories (Clothes, Electronics, Accessories, Sports, Beauty, Home Decor)
- [ ] **Stock statuses**: Mix of in-stock, low-stock, and out-of-stock items
- [ ] **Price range**: Various price points from ₹599 to ₹4999
- [ ] **Suppliers**: Multiple different suppliers

### 🎯 Specific Test Items
Try these specific operations:
- [ ] Search for "wireless" (should find earbuds and mouse)
- [ ] Filter by "Electronics" category (should show 4 items)
- [ ] Filter by "Low Stock" status (should show 3 items)
- [ ] Edit "Denim Jeans" (out of stock item)
- [ ] Adjust stock for "Running Shoes" (low stock item)
- [ ] Add new product in "Home Decor" category

## Performance Tests
- [ ] **Load time**: Initial page load under 2 seconds
- [ ] **Filter response**: Filtering responds instantly
- [ ] **Search response**: Search results appear immediately
- [ ] **API calls**: Network tab shows efficient API usage
- [ ] **Memory usage**: No memory leaks during extended use

## Error Handling Tests
- [ ] **Network errors**: Disconnect internet and test error states
- [ ] **Server errors**: Stop backend server and verify error handling
- [ ] **Validation errors**: Submit invalid data in forms
- [ ] **Empty states**: Test with no products/filtered results
- [ ] **Retry mechanisms**: Error messages include retry options

---

## ✅ Sign-off

**Frontend Functionality**: ☐ All tests passing  
**Backend Integration**: ☐ All APIs working  
**Error Handling**: ☐ Graceful error states  
**UI/UX**: ☐ Responsive and polished  
**Performance**: ☐ Fast and efficient  

**Tester**: ________________  
**Date**: ________________  
**Notes**: ________________

---

## 🐛 Known Issues
Document any bugs or limitations found during testing:

1. 
2. 
3. 

## 🚀 Future Enhancements
List potential improvements for future releases:

1. Add product image upload functionality
2. Implement barcode scanning
3. Add export to CSV/Excel
4. Implement advanced search with multiple criteria
5. Add product history/audit trail