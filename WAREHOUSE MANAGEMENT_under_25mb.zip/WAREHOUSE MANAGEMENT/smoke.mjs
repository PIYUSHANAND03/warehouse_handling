// Simple end-to-end API smoke test
// Requires server running at http://localhost:3000 and DB seeded

const API_BASE = process.env.API_BASE || 'http://localhost:3000/api';

async function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function request(method, path, body) {
  const url = `${API_BASE}${path}`;
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { raw: text }; }
  return { status: res.status, ok: res.ok, data: json };
}

async function waitForServer(maxRetries = 20) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      const res = await request('GET', '/ping');
      if (res.ok) return true;
    } catch {}
    await sleep(1000);
  }
  return false;
}

async function run() {
  let failures = 0;
  const step = async (name, fn) => {
    process.stdout.write(`- ${name} ... `);
    try {
      await fn();
      console.log('OK');
    } catch (e) {
      failures++;
      console.log('FAIL');
      console.error(e?.message || e);
    }
  };

  // Wait for server
  const ready = await waitForServer();
  if (!ready) {
    console.error('Server not responding at /api/ping');
    process.exit(1);
  }

  // Track created resource IDs for cleanup
  let createdProductId = null;
  let createdCustomerId = null;
  let createdOrderId = null;
  let createdShipmentId = null;
  let createdOrderProductId = null;
  let createdShipmentTracking = null;

  // ------------------
  // Core ping/products
  // ------------------
  await step('GET /api/ping', async () => {
    const res = await request('GET', '/ping');
    if (!res.ok || !res.data?.message) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('GET /api/products', async () => {
    const res = await request('GET', '/products');
    if (!res.ok || !res.data?.success) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('POST /api/products', async () => {
    const payload = {
      name: 'SmokeTest Item',
      category: 'Test',
      stock: 10,
      minStock: 2,
      price: 99,
      location: 'Smoke-1',
      supplier: 'Smoke Inc.'
    };
    const res = await request('POST', '/products', payload);
    if (!res.ok || !res.data?.success || !res.data?.data?.id) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
    createdProductId = res.data.data.id;
  });

  await step('GET /api/products/:id', async () => {
    const res = await request('GET', `/products/${createdProductId}`);
    if (!res.ok || !res.data?.success || res.data?.data?.id !== createdProductId) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('PATCH /api/products/:id/stock', async () => {
    const res = await request('PATCH', `/products/${createdProductId}/stock`, { stock: 5, operation: 'add' });
    if (!res.ok || !res.data?.success) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('GET /api/dashboard/stats', async () => {
    const res = await request('GET', '/dashboard/stats');
    if (!res.ok || !res.data?.success || typeof res.data?.data?.totalProducts !== 'number') throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('DELETE /api/products/:id', async () => {
    const res = await request('DELETE', `/products/${createdProductId}`);
    if (!res.ok || !res.data?.success) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  // ---------------------------------
  // Customers → Orders → Shipments E2E
  // ---------------------------------
  const today = new Date();
  const fmt = (d) => d.toISOString().split('T')[0];
  const inDays = (n) => { const x = new Date(today); x.setDate(x.getDate() + n); return fmt(x); };

  await step('POST /api/customers', async () => {
    const email = `smoke+${Date.now()}@example.com`;
    const payload = {
      name: 'SmokeTest Customer',
      email,
      phone: '9999999999',
      address: { street: '123 Test St', city: 'Testville', state: 'TS', pincode: '12345', country: 'IN' },
      type: 'individual',
    };
    const res = await request('POST', '/customers', payload);
    if (!res.ok || !res.data?.success || !res.data?.data?.id) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
    createdCustomerId = res.data.data.id;
  });

  await step('GET /api/customers/:id', async () => {
    const res = await request('GET', `/customers/${createdCustomerId}`);
    if (!res.ok || !res.data?.success || res.data?.data?.id !== createdCustomerId) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('GET /api/customers/stats/summary', async () => {
    const res = await request('GET', '/customers/stats/summary');
    if (!res.ok || !res.data?.success || typeof res.data?.data?.totalCustomers !== 'number') throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('POST /api/products (order item)', async () => {
    const payload = {
      name: 'SmokeTest Order Item',
      category: 'Test',
      stock: 20,
      minStock: 2,
      price: 50,
      location: 'Smoke-2',
      supplier: 'Smoke Inc.'
    };
    const res = await request('POST', '/products', payload);
    if (!res.ok || !res.data?.success || !res.data?.data?.id) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
    createdOrderProductId = res.data.data.id;
  });

  await step('POST /api/orders', async () => {
    const payload = {
      customerId: createdCustomerId,
      items: [{ productId: createdOrderProductId, quantity: 3 }],
      priority: 'high',
      deliveryDate: inDays(7),
      shippingAddress: { street: '123 Test St', city: 'Testville', state: 'TS', pincode: '12345', country: 'IN' },
      notes: 'Smoke order',
    };
    const res = await request('POST', '/orders', payload);
    if (!res.ok || !res.data?.success || !res.data?.data?.id) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
    createdOrderId = res.data.data.id;
  });

  await step('GET /api/orders/:id', async () => {
    const res = await request('GET', `/orders/${createdOrderId}`);
    if (!res.ok || !res.data?.success || res.data?.data?.id !== createdOrderId) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('GET /api/orders', async () => {
    const res = await request('GET', '/orders?status=pending&limit=5');
    if (!res.ok || !res.data?.success || !Array.isArray(res.data?.data)) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('GET /api/orders/stats/summary', async () => {
    const res = await request('GET', '/orders/stats/summary');
    if (!res.ok || !res.data?.success || typeof res.data?.data?.totalOrders !== 'number') throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('PATCH /api/orders/:id/status → processing', async () => {
    const res = await request('PATCH', `/orders/${createdOrderId}/status`, { status: 'processing' });
    if (!res.ok || !res.data?.success || res.data?.data?.status !== 'processing') throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('POST /api/shipments', async () => {
    const payload = {
      orderId: createdOrderId,
      carrier: 'DHL',
      estimatedDelivery: inDays(5),
      origin: { address: 'WH1', city: 'CityA', state: 'ST', pincode: '10001' },
      destination: { address: '123 Test St', city: 'Testville', state: 'TS', pincode: '12345' },
      weight: 2.5,
      dimensions: { length: 10, width: 5, height: 3 },
      cost: 120,
    };
    const res = await request('POST', '/shipments', payload);
    if (!res.ok || !res.data?.success || !res.data?.data?.id) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
    createdShipmentId = res.data.data.id;
    createdShipmentTracking = res.data.data.trackingNumber;
  });

  await step('GET /api/shipments/:id', async () => {
    const res = await request('GET', `/shipments/${createdShipmentId}`);
    if (!res.ok || !res.data?.success || res.data?.data?.id !== createdShipmentId) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('GET /api/shipments/track/:trackingNumber', async () => {
    const res = await request('GET', `/shipments/track/${createdShipmentTracking}`);
    if (!res.ok || !res.data?.success || res.data?.data?.trackingNumber !== createdShipmentTracking) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('GET /api/shipments/pending', async () => {
    const res = await request('GET', '/shipments/pending');
    if (!res.ok || !res.data?.success || !Array.isArray(res.data?.data)) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('PUT /api/shipments/:id → in-transit (order→shipped)', async () => {
    const res = await request('PUT', `/shipments/${createdShipmentId}`, { status: 'in-transit' });
    if (!res.ok || !res.data?.success || res.data?.data?.status !== 'in-transit') throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('PUT /api/shipments/:id → pending', async () => {
    const res = await request('PUT', `/shipments/${createdShipmentId}`, { status: 'pending' });
    if (!res.ok || !res.data?.success || res.data?.data?.status !== 'pending') throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('DELETE /api/shipments/:id', async () => {
    const res = await request('DELETE', `/shipments/${createdShipmentId}`);
    if (!res.ok || !res.data?.success) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('PATCH /api/orders/:id/status → pending', async () => {
    const res = await request('PATCH', `/orders/${createdOrderId}/status`, { status: 'pending' });
    if (!res.ok || !res.data?.success || res.data?.data?.status !== 'pending') throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('DELETE /api/orders/:id', async () => {
    const res = await request('DELETE', `/orders/${createdOrderId}`);
    if (!res.ok || !res.data?.success) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('DELETE /api/products/:id (order item)', async () => {
    const res = await request('DELETE', `/products/${createdOrderProductId}`);
    if (!res.ok || !res.data?.success) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  await step('DELETE /api/customers/:id', async () => {
    const res = await request('DELETE', `/customers/${createdCustomerId}`);
    if (!res.ok || !res.data?.success) throw new Error(`Unexpected response: ${JSON.stringify(res.data)}`);
  });

  if (failures > 0) {
    console.error(`\nSmoke test completed with ${failures} failure(s).`);
    process.exit(1);
  } else {
    console.log('\n✅ Smoke test passed.');
  }
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});