# Backend Warehouse Management System

## Overview
This is the backend API for the Warehouse Management System, built with Express.js, TypeScript, and Prisma.

## Tech Stack
- **Node.js** 22+
- **Express.js** - Web framework
- **TypeScript** - Type safety
- **Prisma** - Database ORM
- **Socket.io** - Real-time communication
- **Zod** - Schema validation

## Database
- **MySQL** - Primary database
- **Prisma** - Database ORM and migrations

## Environment Variables
Required environment variables for production:

```bash
DATABASE_URL=mysql://username:password@host:port/database
DB_HOST=your-mysql-host
DB_PORT=3306
DB_USER=your-db-user
DB_PASSWORD=your-db-password
DB_NAME=warehouse
PORT=8080
```

## Installation
```bash
pnpm install
```

## Database Setup
```bash
pnpm prisma:generate
pnpm prisma:migrate
```

## Development
```bash
pnpm dev:server
```

## Production
```bash
pnpm start
```

## API Endpoints
- `/api/products` - Product management
- `/api/orders` - Order management
- `/api/customers` - Customer management
- `/api/shipments` - Shipment tracking
- `/api/workers` - Worker management
- `/api/dashboard` - Dashboard analytics
- `/api/ping` - Health check

## Deployment
This backend is designed to be deployed on platforms like Render, Vercel, or any Node.js hosting service.

## Project Structure
```
backend-warehouse/
├── prisma/
│   ├── schema.prisma
│   └── migrations/
├── server/
│   ├── routes/
│   ├── types/
│   └── utils/
├── package.json
├── pnpm-lock.yaml
└── README.md
```
