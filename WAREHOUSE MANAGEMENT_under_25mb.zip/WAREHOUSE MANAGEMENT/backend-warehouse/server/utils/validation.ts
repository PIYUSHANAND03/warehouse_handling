import { z } from 'zod';

// Product validation schemas
export const createProductSchema = z.object({
  name: z.string().min(1, 'Product name is required'),
  category: z.string().min(1, 'Category is required'),
  stock: z.number().int().min(0, 'Stock must be non-negative'),
  minStock: z.number().int().min(0, 'Minimum stock must be non-negative'),
  price: z.number().min(0, 'Price must be non-negative'),
  location: z.string().min(1, 'Location is required'),
  supplier: z.string().min(1, 'Supplier is required'),
  description: z.string().optional(),
  sku: z.string().optional(),
  weight: z.number().optional(),
  dimensions: z.object({
    length: z.number(),
    width: z.number(),
    height: z.number(),
  }).optional(),
});

export const updateProductSchema = createProductSchema.partial();

export const updateStockSchema = z.object({
  stock: z.number().int().min(0),
  operation: z.enum(['add', 'subtract', 'set']).optional(),
});

// Order validation schemas
export const createOrderSchema = z.object({
  customerId: z.string().min(1, 'Customer ID is required'),
  items: z.array(z.object({
    productId: z.string().min(1),
    quantity: z.number().int().min(1),
  })).min(1, 'At least one item is required'),
  priority: z.enum(['low', 'medium', 'high']),
  deliveryDate: z.string(),
  shippingAddress: z.object({
    street: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
    country: z.string().min(1),
  }),
  notes: z.string().optional(),
});

export const updateOrderSchema = z.object({
  status: z.enum(['pending', 'processing', 'shipped', 'completed', 'cancelled']).optional(),
  priority: z.enum(['low', 'medium', 'high']).optional(),
  deliveryDate: z.string().optional(),
  trackingNumber: z.string().optional(),
  notes: z.string().optional(),
});

// Customer validation schemas
export const createCustomerSchema = z.object({
  name: z.string().min(1, 'Customer name is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Phone number must be at least 10 digits'),
  address: z.object({
    street: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
    country: z.string().min(1),
  }),
  type: z.enum(['business', 'individual']),
});

export const updateCustomerSchema = createCustomerSchema.partial();

// Worker validation schemas
export const createWorkerSchema = z.object({
  name: z.string().min(1, 'Worker name is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Phone number must be at least 10 digits'),
  role: z.enum(['manager', 'supervisor', 'worker', 'picker', 'packer', 'loader']),
  department: z.enum(['receiving', 'picking', 'packing', 'shipping', 'inventory', 'administration']),
  status: z.enum(['active', 'inactive', 'on-leave']),
  hireDate: z.string(),
  shift: z.enum(['morning', 'afternoon', 'night']),
  hourlyRate: z.number().min(0),
  address: z.object({
    street: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
    country: z.string().min(1),
  }),
  emergencyContact: z.object({
    name: z.string(),
    phone: z.string(),
    relationship: z.string(),
  }).optional(),
  skills: z.array(z.string()).optional(),
  performanceRating: z.number().min(0).max(5).optional(),
});

export const updateWorkerSchema = createWorkerSchema.partial();

// Shipment validation schemas
export const createShipmentSchema = z.object({
  orderId: z.string().min(1, 'Order ID is required'),
  trackingNumber: z.string().min(1, 'Tracking number is required'),
  carrier: z.string().min(1, 'Carrier is required'),
  shipDate: z.string(),
  estimatedDelivery: z.string(),
  originAddress: z.string().min(1),
  originCity: z.string().min(1),
  originState: z.string().min(1),
  originPincode: z.string().min(1),
  destinationAddress: z.string().min(1),
  destinationCity: z.string().min(1),
  destinationState: z.string().min(1),
  destinationPincode: z.string().min(1),
  weight: z.number().optional(),
  dimensions: z.object({
    length: z.number(),
    width: z.number(),
    height: z.number(),
  }).optional(),
  shippingCost: z.number().optional(),
  notes: z.string().optional(),
});

export const updateShipmentSchema = createShipmentSchema.partial();

// Helper function to validate request body
export function validateRequest<T>(schema: z.ZodSchema<T>, data: unknown): { success: true; data: T } | { success: false; errors: string[] } {
  try {
    const validated = schema.parse(data);
    return { success: true, data: validated };
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errors = error.errors.map(err => `${err.path.join('.')}: ${err.message}`);
      return { success: false, errors };
    }
    return { success: false, errors: ['Validation failed'] };
  }
}
