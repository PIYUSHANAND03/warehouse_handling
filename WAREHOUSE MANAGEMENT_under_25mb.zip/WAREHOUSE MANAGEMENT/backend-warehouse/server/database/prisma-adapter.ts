import { prisma } from '../db'

// Helper functions
function toDateString(date: Date): string {
  return date.toISOString()
}

function computeStatus(stock: number, minStock: number): 'in-stock' | 'low-stock' | 'out-of-stock' {
  if (stock === 0) return 'out-of-stock'
  if (stock <= minStock) return 'low-stock'
  return 'in-stock'
}

// Mapper functions
function mapProduct(p: any) {
  return {
    id: p.id,
    name: p.name,
    category: p.category,
    stock: p.stock,
    minStock: p.minStock,
    price: p.price,
    currency: p.currency,
    status: computeStatus(p.stock, p.minStock),
    location: p.location,
    supplier: p.supplier,
    lastUpdated: toDateString(p.updatedAt),
    description: p.description,
    sku: p.sku,
    weight: p.weight,
    dimensions: p.dimensions ? { 
      length: p.dimensions.length, 
      width: p.dimensions.width, 
      height: p.dimensions.height 
    } : undefined,
  }
}

function mapCustomer(c: any) {
  return {
    id: c.id,
    name: c.name,
    email: c.email,
    phone: c.phone,
    address: {
      street: c.street,
      city: c.city,
      state: c.state,
      pincode: c.pincode,
      country: c.country
    },
    totalOrders: c.totalOrders,
    totalSpent: c.totalSpent,
    lastOrderDate: c.lastOrderDate ? toDateString(c.lastOrderDate) : undefined,
    status: c.status,
    registeredAt: toDateString(c.createdAt)
  }
}

function mapOrder(o: any) {
  return {
    id: o.id,
    customerId: o.customerId,
    items: o.items,
    status: o.status,
    priority: o.priority,
    orderDate: toDateString(o.orderDate),
    deliveryDate: toDateString(o.deliveryDate),
    totalAmount: o.totalAmount,
    currency: o.currency,
    notes: o.notes
  }
}

function mapShipment(s: any) {
  return {
    id: s.id,
    orderId: s.orderId,
    trackingNumber: s.trackingNumber,
    carrier: s.carrier,
    status: s.status,
    estimatedDelivery: toDateString(s.estimatedDelivery),
    actualDelivery: s.actualDelivery ? toDateString(s.actualDelivery) : undefined,
    origin: s.origin,
    destination: s.destination,
    weight: s.weight,
    dimensions: s.dimensions,
    cost: s.cost,
    currency: s.currency,
    createdAt: toDateString(s.createdAt)
  }
}

function mapWorker(w: any) {
  return {
    id: w.id,
    name: w.name,
    email: w.email,
    phone: w.phone,
    role: w.role,
    department: w.department,
    status: w.status,
    hireDate: toDateString(w.hireDate),
    shift: w.shift,
    hourlyRate: w.hourlyRate,
    address: {
      street: w.street,
      city: w.city,
      state: w.state,
      pincode: w.pincode,
      country: w.country
    },
    emergencyContact: w.emergencyName ? {
      name: w.emergencyName,
      phone: w.emergencyPhone,
      relationship: w.emergencyRelation
    } : undefined,
    skills: w.skills,
    performanceRating: w.performanceRating,
    lastActive: w.lastActive ? toDateString(w.lastActive) : undefined
  }
}

// Database operations
export const db = {
  // Products
  async getProducts() {
    const products = await prisma.product.findMany()
    return products.map(mapProduct)
  },

  async getProduct(id: string) {
    const product = await prisma.product.findUnique({ where: { id } })
    return product ? mapProduct(product) : null
  },

  async createProduct(data: any) {
    const product = await prisma.product.create({ data })
    return mapProduct(product)
  },

  async updateProduct(id: string, data: any) {
    const product = await prisma.product.update({ where: { id }, data })
    return mapProduct(product)
  },

  async deleteProduct(id: string) {
    await prisma.product.delete({ where: { id } })
  },

  // Customers
  async getCustomers() {
    const customers = await prisma.customer.findMany()
    return customers.map(mapCustomer)
  },

  async getCustomer(id: string) {
    const customer = await prisma.customer.findUnique({ where: { id } })
    return customer ? mapCustomer(customer) : null
  },

  async createCustomer(data: any) {
    const customer = await prisma.customer.create({ data })
    return mapCustomer(customer)
  },

  async updateCustomer(id: string, data: any) {
    const customer = await prisma.customer.update({ where: { id }, data })
    return mapCustomer(customer)
  },

  async deleteCustomer(id: string) {
    await prisma.customer.delete({ where: { id } })
  },

  // Orders
  async getOrders() {
    const orders = await prisma.order.findMany()
    return orders.map(mapOrder)
  },

  async getOrder(id: string) {
    const order = await prisma.order.findUnique({ where: { id } })
    return order ? mapOrder(order) : null
  },

  async createOrder(data: any) {
    const order = await prisma.order.create({ data })
    return mapOrder(order)
  },

  async updateOrder(id: string, data: any) {
    const order = await prisma.order.update({ where: { id }, data })
    return mapOrder(order)
  },

  async deleteOrder(id: string) {
    await prisma.order.delete({ where: { id } })
  },

  // Shipments
  async getShipments() {
    const shipments = await prisma.shipment.findMany()
    return shipments.map(mapShipment)
  },

  async getShipment(id: string) {
    const shipment = await prisma.shipment.findUnique({ where: { id } })
    return shipment ? mapShipment(shipment) : null
  },

  async createShipment(data: any) {
    const shipment = await prisma.shipment.create({ data })
    return mapShipment(shipment)
  },

  async updateShipment(id: string, data: any) {
    const shipment = await prisma.shipment.update({ where: { id }, data })
    return mapShipment(shipment)
  },

  async deleteShipment(id: string) {
    await prisma.shipment.delete({ where: { id } })
  },

  // Workers
  async getWorkers() {
    const workers = await prisma.worker.findMany()
    return workers.map(mapWorker)
  },

  async getWorker(id: string) {
    const worker = await prisma.worker.findUnique({ where: { id } })
    return worker ? mapWorker(worker) : null
  },

  async createWorker(data: any) {
    const worker = await prisma.worker.create({ data })
    return mapWorker(worker)
  },

  async updateWorker(id: string, data: any) {
    const worker = await prisma.worker.update({ where: { id }, data })
    return mapWorker(worker)
  },

  async deleteWorker(id: string) {
    await prisma.worker.delete({ where: { id } })
  }
}
