export interface Product {
  id: string;
  name: string;
  category: string;
  stock: number;
  minStock: number;
  price: number;
  currency: string;
  status: 'in-stock' | 'low-stock' | 'out-of-stock';
  location: string;
  supplier: string;
  lastUpdated: string;
  description?: string;
  sku?: string;
  weight?: number;
  dimensions?: {
    length: number;
    width: number;
    height: number;
  };
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  type: 'business' | 'individual';
  registrationDate: string;
  lastOrderDate?: string;
  totalOrders: number;
  totalValue: number;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export interface InvoiceItem {
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string; // e.g., INV-001
  orderId: string;
  invoiceDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  status: 'unpaid' | 'paid' | 'void';
  subtotal: number;
  tax: number; // absolute value
  total: number;
  currency: string;
  items: InvoiceItem[];
}

export interface Order {
  id: string;
  customer: Customer;
  items: OrderItem[];
  totalItems: number;
  totalValue: number;
  status: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  orderDate: string;
  deliveryDate: string;
  shippingAddress: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  billingAddress?: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  trackingNumber?: string;
  notes?: string;
  specialInstructions?: string;
  paymentMethod?: string;
  paymentTerms?: string;
  shippingMethod?: string;
  orderSource?: string;
  gstNumber?: string;
  discount?: {
    type: 'percentage' | 'fixed';
    value: number;
  };
  assignedWorker?: string;
  expectedDeliveryTime?: string;
  shipments?: Shipment[];
}

export interface Shipment {
  id: string;
  orderId: string;
  trackingNumber: string;
  carrier: string;
  status: 'pending' | 'in-transit' | 'delivered' | 'returned';
  shipDate: string;
  estimatedDelivery: string;
  actualDelivery?: string;
  origin: {
    address: string;
    city: string;
    state: string;
    pincode: string;
  };
  destination: {
    address: string;
    city: string;
    state: string;
    pincode: string;
  };
  weight: number;
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
  cost: number;
}

export interface Report {
  id: string;
  type: 'inventory' | 'sales' | 'low-stock' | 'customer' | 'financial';
  title: string;
  data: any;
  generatedDate: string;
  generatedBy: string;
  period: {
    startDate: string;
    endDate: string;
  };
}

export interface DashboardStats {
  totalProducts: number;
  lowStockItems: number;
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  totalRevenue: number;
  recentActivities: RecentActivity[];
}


export interface RecentActivity {
  id: string;
  location: string;
  status: string;
  statusColor: string;
  timestamp: string;
  type: 'stock' | 'order' | 'shipment';
}

// API Response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

// Request types
export interface CreateProductRequest {
  name: string;
  category: string;
  stock: number;
  minStock: number;
  price: number;
  location: string;
  supplier: string;
  description?: string;
  sku?: string;
  weight?: number;
  dimensions?: {
    length: number;
    width: number;
    height: number;
  };
}

export interface CreateOrderRequest {
  customerId: string;
  items: {
    productId: string;
    quantity: number;
  }[];
  priority: 'low' | 'medium' | 'high';
  deliveryDate: string;
  shippingAddress: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  billingAddress?: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  notes?: string;
  specialInstructions?: string;
  paymentMethod?: string;
  paymentTerms?: string;
  shippingMethod?: string;
  orderSource?: string;
  gstNumber?: string;
  discount?: {
    type: 'percentage' | 'fixed';
    value: number;
  };
  assignedWorker?: string;
  expectedDeliveryTime?: string;
}

export interface CreateCustomerRequest {
  name: string;
  email: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  type: 'business' | 'individual';
}

export interface CreateWorkerRequest {
  name: string;
  email: string;
  phone: string;
  role: 'manager' | 'supervisor' | 'worker' | 'picker' | 'packer' | 'loader';
  department: 'receiving' | 'picking' | 'packing' | 'shipping' | 'inventory' | 'administration';
  shift: 'morning' | 'afternoon' | 'night';
  hourlyRate: number;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  emergencyContact?: {
    name: string;
    phone: string;
    relationship: string;
  };
  skills?: string[];
}

// Shared types from @shared/api
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  avatarUrl?: string;
}

export interface DemoResponse {
  message: string;
}