import "dotenv/config";
import { createServer } from "./index";

const { app, httpServer } = createServer();
const port = process.env.PORT || 3000;

httpServer.listen(port, () => {
  console.log(`🚀 Warehouse Management Server is running!`);
  console.log(`📱 Server: http://localhost:${port}`);
  console.log(`🔧 API: http://localhost:${port}/api`);
  console.log(`📊 Test endpoints:`);
  console.log(`   - GET http://localhost:${port}/api/ping - Health check`);
  console.log(`   - GET http://localhost:${port}/api/products - List products`);
  console.log(`   - POST http://localhost:${port}/api/products - Create product`);
  console.log(`   - PUT http://localhost:${port}/api/products/:id - Update product`);
  console.log(`   - DELETE http://localhost:${port}/api/products/:id - Delete product`);
  console.log(`   - PATCH http://localhost:${port}/api/products/:id/stock - Update stock`);
  console.log(`   - DELETE http://localhost:${port}/api/products/bulk/delete - Bulk delete`);
  console.log(`   - PATCH http://localhost:${port}/api/products/bulk/update - Bulk update`);
  console.log(`   - GET http://localhost:${port}/api/dashboard/stats - Dashboard stats`);
  console.log(`   - GET http://localhost:${port}/api/orders - List orders`);
  console.log(`   - GET http://localhost:${port}/api/customers - List customers`);
  console.log(`\n🎯 Now you can run the frontend with: npm run dev`);
  console.log(`   Frontend will be available at: http://localhost:5173`);
});