import { Router, Request, Response } from 'express'
import { db } from '../database/prisma-adapter'
import { ApiResponse, Report } from '../types'
import PDFDocument from 'pdfkit'

const router = Router()

// Utilities
function parseDateRange(req: Request) {
  const from = req.query.from ? new Date(String(req.query.from)) : undefined;
  const to = req.query.to ? new Date(String(req.query.to)) : undefined;
  return { from, to };
}

function jsonToCsv(obj: any): string {
  const data = typeof obj === 'object' ? obj : { data: obj };
  // Flatten objects for CSV; handle arrays specially
  const rows: any[] = [];
  if (Array.isArray(data)) {
    rows.push(...data);
  } else if (Array.isArray(data.products)) {
    rows.push(...data.products);
  } else if (Array.isArray(data.items)) {
    rows.push(...data.items);
  } else if (Array.isArray(data.monthlyBreakdown)) {
    rows.push(...data.monthlyBreakdown);
  } else if (Array.isArray(data.customers)) {
    rows.push(...data.customers);
  } else if (data.summary) {
    rows.push(data.summary);
  } else {
    rows.push(data);
  }
  if (rows.length === 0) return '';
  const headers = Array.from(new Set(rows.flatMap(r => Object.keys(r))));
  const lines = [headers.join(',')];
  for (const r of rows) {
    const line = headers.map(h => {
      const v = (r as any)[h];
      if (v == null) return '';
      const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
      return '"' + s.replace(/"/g, '""') + '"';
    }).join(',');
    lines.push(line);
  }
  return lines.join('\n');
}

function wrapHtml(title: string, pre: string) {
  return `<!doctype html><html><head><meta charset="utf-8"/><title>${title}</title>
  <style>body{font-family:Inter,system-ui,Arial;padding:16px;color:#0f172a} pre{white-space:pre-wrap;word-break:break-word;background:#f8fafc;border:1px solid #e2e8f0;padding:12px;border-radius:8px}</style>
  </head><body><h1>${title}</h1><pre>${pre}</pre></body></html>`;
}

function sendFile(res: Response, filename: string, contentType: string, buffer: Buffer | string) {
  res.setHeader('Content-Type', contentType);
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(buffer);
}

// GET /api/reports/inventory - Generate inventory report
router.get('/inventory', async (_req: Request, res: Response) => {
  try {
    const report = await db.generateInventoryReport()
    res.json({ success: true, data: report } as ApiResponse<Report>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to generate inventory report', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/reports/sales - Generate sales report
router.get('/sales', async (_req: Request, res: Response) => {
  try {
    const report = await db.generateSalesReport()
    res.json({ success: true, data: report } as ApiResponse<Report>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to generate sales report', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/reports/low-stock - Generate low stock report
router.get('/low-stock', async (_req: Request, res: Response) => {
  try {
    const products = await db.getAllProducts()
    const lowStockProducts = products.filter(p => p.status === 'low-stock' || p.status === 'out-of-stock')

    const report: Report = {
      id: `RPT-${Date.now()}`,
      type: 'low-stock',
      title: 'Low Stock Alert Report',
      data: {
        products: lowStockProducts,
        summary: {
          totalLowStockItems: lowStockProducts.length,
          outOfStockItems: lowStockProducts.filter(p => p.status === 'out-of-stock').length,
          lowStockItems: lowStockProducts.filter(p => p.status === 'low-stock').length,
          criticalItems: lowStockProducts.filter(p => p.stock === 0 || p.stock < (p.minStock * 0.5)),
          estimatedLostRevenue: lowStockProducts.reduce((sum, p) => {
            if (p.status === 'out-of-stock') {
              return sum + (p.price * p.minStock)
            }
            return sum + (p.price * Math.max(0, p.minStock - p.stock))
          }, 0),
        }
      },
      generatedDate: new Date().toISOString(),
      generatedBy: 'System',
      period: { startDate: new Date().toISOString(), endDate: new Date().toISOString() },
    }

    res.json({ success: true, data: report } as ApiResponse<Report>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to generate low stock report', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/reports/customer - Generate customer analytics report
router.get('/customer', async (_req: Request, res: Response) => {
  try {
    const customers = await db.getAllCustomers()
    const orders = await db.getAllOrders()

    const topCustomers = customers.slice().sort((a, b) => b.totalValue - a.totalValue).slice(0, 10)

    const newCustomers = customers.filter(c => {
      const registrationDate = new Date(c.registrationDate)
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
      return registrationDate >= thirtyDaysAgo
    })

    const activeCustomers = customers.filter(c => {
      if (!c.lastOrderDate) return false
      const lastOrderDate = new Date(c.lastOrderDate)
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
      return lastOrderDate >= thirtyDaysAgo
    })

    const report: Report = {
      id: `RPT-${Date.now()}`,
      type: 'customer',
      title: 'Customer Analytics Report',
      data: {
        customers,
        summary: {
          totalCustomers: customers.length,
          newCustomers: newCustomers.length,
          activeCustomers: activeCustomers.length,
          topCustomers: topCustomers.map(c => ({ id: c.id, name: c.name, totalValue: c.totalValue, totalOrders: c.totalOrders, type: c.type })),
          customerTypes: {
            business: customers.filter(c => c.type === 'business').length,
            individual: customers.filter(c => c.type === 'individual').length,
          },
          averageCustomerValue: customers.length > 0 ? customers.reduce((sum, c) => sum + c.totalValue, 0) / customers.length : 0,
          customerRetentionRate: customers.length > 0 ? (activeCustomers.length / customers.length) * 100 : 0,
        }
      },
      generatedDate: new Date().toISOString(),
      generatedBy: 'System',
      period: { startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), endDate: new Date().toISOString() },
    }

    res.json({ success: true, data: report } as ApiResponse<Report>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to generate customer report', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/reports/financial - Generate financial report
router.get('/financial', async (_req: Request, res: Response) => {
  try {
    const orders = await db.getAllOrders()
    const products = await db.getAllProducts()
    const shipments = await db.getAllShipments()

    const completedOrders = orders.filter(o => o.status === 'completed')
    const totalRevenue = completedOrders.reduce((sum, o) => sum + o.totalValue, 0)
    const totalShippingCosts = shipments.reduce((sum, s) => sum + s.cost, 0)
    const inventoryValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0)

    const monthlyData: { [key: string]: { revenue: number; orders: number } } = {}
    completedOrders.forEach(order => {
      const month = order.orderDate.substring(0, 7)
      if (!monthlyData[month]) monthlyData[month] = { revenue: 0, orders: 0 }
      monthlyData[month].revenue += order.totalValue
      monthlyData[month].orders += 1
    })

    const report: Report = {
      id: `RPT-${Date.now()}`,
      type: 'financial',
      title: 'Financial Performance Report',
      data: {
        summary: {
          totalRevenue,
          totalOrders: completedOrders.length,
          averageOrderValue: completedOrders.length > 0 ? totalRevenue / completedOrders.length : 0,
          totalShippingCosts,
          inventoryValue,
          grossMargin: totalRevenue - totalShippingCosts,
          profitMargin: totalRevenue > 0 ? ((totalRevenue - totalShippingCosts) / totalRevenue) * 100 : 0,
        },
        monthlyBreakdown: Object.entries(monthlyData)
          .sort(([a], [b]) => a.localeCompare(b))
          .map(([month, data]) => ({ month, revenue: data.revenue, orders: data.orders, averageOrderValue: data.orders > 0 ? data.revenue / data.orders : 0 })),
        revenueByCategory: calculateRevenueByCategory(completedOrders),
        topRevenueProducts: getTopRevenueProducts(completedOrders),
      },
      generatedDate: new Date().toISOString(),
      generatedBy: 'System',
      period: { startDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(), endDate: new Date().toISOString() },
    }

    res.json({ success: true, data: report } as ApiResponse<Report>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to generate financial report', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// Helper function to calculate revenue by category
function calculateRevenueByCategory(orders: any[]) {
  const categoryRevenue: { [key: string]: number } = {}

  orders.forEach(order => {
    order.items.forEach((item: any) => {
      // We already have productName on items; category lookup would require joining products
      // Keep logic aligned with previous: map by productId -> product category from products list if needed
      // For simplicity, sum by productName here (stable with current seed/data). In real-world, join products.
      const key = item.productName
      categoryRevenue[key] = (categoryRevenue[key] || 0) + item.totalPrice
    })
  })

  return Object.entries(categoryRevenue)
    .map(([category, revenue]) => ({ category, revenue }))
    .sort((a, b) => b.revenue - a.revenue)
}

// Helper function to get top revenue products
function getTopRevenueProducts(orders: any[]) {
  const productRevenue: { [key: string]: { name: string; revenue: number; quantity: number } } = {}

  orders.forEach(order => {
    order.items.forEach((item: any) => {
      if (!productRevenue[item.productId]) {
        productRevenue[item.productId] = { name: item.productName, revenue: 0, quantity: 0 }
      }
      productRevenue[item.productId].revenue += item.totalPrice
      productRevenue[item.productId].quantity += item.quantity
    })
  })

  return Object.entries(productRevenue)
    .map(([id, data]) => ({ id, ...data }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10)
}

// Export endpoints
// GET /api/reports/:type/export?format=csv|html|pdf|excel&from&to
router.get('/:type/export', async (req: Request, res: Response) => {
  try {
    const { type } = req.params;
    const format = String(req.query.format || 'csv').toLowerCase();
    const { from, to } = parseDateRange(req);

    // Fetch underlying data by reusing existing logic/endpoints
    let report: Report | undefined;
    if (type === 'inventory') {
      const r = await db.generateInventoryReport();
      report = r as any;
    } else if (type === 'sales' || type === 'performance') {
      const r = await db.generateSalesReport();
      report = r as any;
    } else if (type === 'low-stock') {
      const products = await db.getAllProducts();
      const lowStockProducts = products.filter((p: any) => p.status === 'low-stock' || p.status === 'out-of-stock');
      report = {
        id: `RPT-${Date.now()}`,
        type: 'low-stock',
        title: 'Low Stock Alert Report',
        data: { products: lowStockProducts },
        generatedDate: new Date().toISOString(),
        generatedBy: 'System',
        period: { startDate: from?.toISOString() || '', endDate: to?.toISOString() || '' },
      } as any;
    } else if (type === 'customer' || type === 'suppliers') {
      const customers = await db.getAllCustomers();
      report = {
        id: `RPT-${Date.now()}`,
        type: 'customer',
        title: 'Customer Analytics Report',
        data: { customers },
        generatedDate: new Date().toISOString(),
        generatedBy: 'System',
        period: { startDate: from?.toISOString() || '', endDate: to?.toISOString() || '' },
      } as any;
    } else if (type === 'financial') {
      const orders = await db.getAllOrders();
      const shipments = await db.getAllShipments();
      report = {
        id: `RPT-${Date.now()}`,
        type: 'financial',
        title: 'Financial Performance Report',
        data: { orders, shipments },
        generatedDate: new Date().toISOString(),
        generatedBy: 'System',
        period: { startDate: from?.toISOString() || '', endDate: to?.toISOString() || '' },
      } as any;
    } else if (type === 'orders') {
      const orders = await db.getAllOrders();
      report = {
        id: `RPT-${Date.now()}`,
        type: 'orders',
        title: 'Orders Report',
        data: { orders },
        generatedDate: new Date().toISOString(),
        generatedBy: 'System',
        period: { startDate: from?.toISOString() || '', endDate: to?.toISOString() || '' },
      } as any;
    } else {
      return res.status(400).json({ success: false, error: 'Unknown report type' });
    }

    // Very light date filter if possible on common shapes
    const payload = report?.data as any;
    const filterByDate = (arr: any[], dateKey: string) => {
      return arr.filter(x => {
        const d = new Date(x[dateKey]);
        if (from && d < from) return false;
        if (to && d > to) return false;
        return true;
      })
    }
    if (from || to) {
      if (Array.isArray(payload?.orders)) payload.orders = filterByDate(payload.orders, 'orderDate');
      if (Array.isArray(payload?.shipments)) payload.shipments = filterByDate(payload.shipments, 'eta');
      if (Array.isArray(payload?.customers)) payload.customers = filterByDate(payload.customers, 'registrationDate');
      if (Array.isArray(payload?.products)) payload.products = filterByDate(payload.products, 'lastUpdated');
    }

    const baseName = `${type}-report-${Date.now()}`;
    if (format === 'csv') {
      const csv = jsonToCsv(payload);
      return sendFile(res, `${baseName}.csv`, 'text/csv; charset=utf-8', csv);
    }
    if (format === 'html') {
      const html = wrapHtml(report?.title || 'Report', `<code>${escapeHtml(JSON.stringify(payload, null, 2))}</code>`);
      return sendFile(res, `${baseName}.html`, 'text/html; charset=utf-8', html);
    }
    if (format === 'excel') {
      const csv = jsonToCsv(payload);
      // simple stub: CSV with .xlsx content type/name
      return sendFile(res, `${baseName}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', csv);
    }
    if (format === 'pdf') {
      // Generate actual PDF using PDFKit
      const doc = new PDFDocument({ margin: 50, size: 'A4' });
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${baseName}.pdf"`);
      
      // Pipe PDF to response
      doc.pipe(res);
      
      // invenTREE Header with dark background
      doc.rect(0, 0, 612, 100).fill('#1a1d29');
      
      // Logo box (blue rounded rectangle)
      doc.roundedRect(50, 25, 50, 50, 8).fill('#3b82f6');
      
      // Icon lines (warehouse/inventory icon)
      doc.fillColor('#ffffff');
      doc.rect(58, 33, 34, 4).fill('#ffffff');
      doc.rect(58, 41, 34, 4).fill('#ffffff');
      doc.rect(58, 49, 34, 4).fill('#ffffff');
      doc.rect(58, 57, 34, 4).fill('#ffffff');
      
      // invenTREE text
      doc.fontSize(28).font('Helvetica-Bold');
      doc.fillColor('#ffffff').text('inven', 115, 35, { continued: true });
      doc.fillColor('#3b82f6').text('TREE');
      
      // Tagline
      doc.fontSize(11).font('Helvetica').fillColor('#9ca3af');
      doc.text('where inventory grows in order', 115, 60, { align: 'left' });
      
      // Reset color and position
      doc.fillColor('#000000');
      doc.moveDown(3);
      
      // Report Title
      doc.fontSize(24).font('Helvetica-Bold').text(report?.title || 'Report', { align: 'left' });
      doc.moveDown(0.3);
      
      // Report metadata
      doc.fontSize(10).font('Helvetica').fillColor('#555555');
      doc.text(`Report ID: ${report?.id || 'N/A'}`, { align: 'left' });
      doc.text(`Generated: ${new Date(report?.generatedDate || Date.now()).toLocaleString()}`, { align: 'left' });
      if (report?.period) {
        doc.text(`Period: ${new Date(report.period.startDate).toLocaleDateString()} - ${new Date(report.period.endDate).toLocaleDateString()}`, { align: 'left' });
      }
      doc.fillColor('#000000');
      doc.moveDown(1.5);
      
      // Report Data Section
      doc.fontSize(14).font('Helvetica-Bold').fillColor('#2563eb').text('Report Data', { align: 'left' });
      doc.moveDown(0.5);
      
      // Format the data for display
      doc.fontSize(9).font('Courier');
      const dataStr = JSON.stringify(payload, null, 2);
      const lines = dataStr.split('\n');
      
      // Add data with pagination support
      let y = doc.y;
      for (const line of lines) {
        // Check if we need a new page
        if (y > 700) {
          doc.addPage();
          y = 50;
        }
        doc.fillColor('#000000').text(line, 50, y, { width: 500 });
        y += 12;
      }
      
      // Footer
      doc.fontSize(9).font('Helvetica').fillColor('#999999');
      doc.text('Generated by invenTREE Warehouse Management System', 50, 750, { align: 'center', width: 500 });
      
      // Finalize PDF
      doc.end();
      return;
    }

    return res.status(400).json({ success: false, error: 'Unsupported format' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to export report', message: error instanceof Error ? error.message : 'Unknown error' })
  }
});

// GET /api/reports/sample/:type?format=csv|html|pdf|excel
router.get('/sample/:type', async (req: Request, res: Response) => {
  try {
    const { type } = req.params;
    const format = String(req.query.format || 'csv').toLowerCase();
    const example = { sample: true, type, generated: new Date().toISOString(), items: [{ id: 1, name: 'Example', value: 100 }] };

    const baseName = `sample-${type}-report`;
    if (format === 'csv') {
      const csv = jsonToCsv(example.items);
      return sendFile(res, `${baseName}.csv`, 'text/csv; charset=utf-8', csv);
    }
    if (format === 'html') {
      const html = wrapHtml('Sample Report', `<code>${escapeHtml(JSON.stringify(example, null, 2))}</code>`);
      return sendFile(res, `${baseName}.html`, 'text/html; charset=utf-8', html);
    }
    if (format === 'excel') {
      const csv = jsonToCsv(example.items);
      return sendFile(res, `${baseName}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', csv);
    }
    if (format === 'pdf') {
      // Generate actual PDF using PDFKit
      const doc = new PDFDocument({ margin: 50, size: 'A4' });
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${baseName}.pdf"`);
      
      // Pipe PDF to response
      doc.pipe(res);
      
      // invenTREE Header with dark background
      doc.rect(0, 0, 612, 100).fill('#1a1d29');
      
      // Logo box (blue rounded rectangle)
      doc.roundedRect(50, 25, 50, 50, 8).fill('#3b82f6');
      
      // Icon lines (warehouse/inventory icon)
      doc.fillColor('#ffffff');
      doc.rect(58, 33, 34, 4).fill('#ffffff');
      doc.rect(58, 41, 34, 4).fill('#ffffff');
      doc.rect(58, 49, 34, 4).fill('#ffffff');
      doc.rect(58, 57, 34, 4).fill('#ffffff');
      
      // invenTREE text
      doc.fontSize(28).font('Helvetica-Bold');
      doc.fillColor('#ffffff').text('inven', 115, 35, { continued: true });
      doc.fillColor('#3b82f6').text('TREE');
      
      // Tagline
      doc.fontSize(11).font('Helvetica').fillColor('#9ca3af');
      doc.text('where inventory grows in order', 115, 60, { align: 'left' });
      
      // Reset color and position
      doc.fillColor('#000000');
      doc.moveDown(3);
      
      // Report Title
      doc.fontSize(24).font('Helvetica-Bold').text('Sample Report', { align: 'left' });
      doc.moveDown(0.3);
      
      // Report metadata
      doc.fontSize(10).font('Helvetica').fillColor('#555555');
      doc.text(`Type: ${type}`, { align: 'left' });
      doc.text(`Generated: ${new Date().toLocaleString()}`, { align: 'left' });
      doc.fillColor('#000000');
      doc.moveDown(1.5);
      
      // Sample Data Section
      doc.fontSize(14).font('Helvetica-Bold').fillColor('#2563eb').text('Sample Data', { align: 'left' });
      doc.moveDown(0.5);
      
      // Format the data for display
      doc.fontSize(9).font('Courier');
      const dataStr = JSON.stringify(example, null, 2);
      doc.fillColor('#000000').text(dataStr, { width: 500 });
      
      // Footer
      doc.fontSize(9).font('Helvetica').fillColor('#999999');
      doc.text('Generated by invenTREE Warehouse Management System', 50, 750, { align: 'center', width: 500 });
      
      // Finalize PDF
      doc.end();
      return;
    }

    return res.status(400).json({ success: false, error: 'Unsupported format' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to export sample report', message: error instanceof Error ? error.message : 'Unknown error' })
  }
});

function escapeHtml(s: string) {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export { router as reportsRouter }