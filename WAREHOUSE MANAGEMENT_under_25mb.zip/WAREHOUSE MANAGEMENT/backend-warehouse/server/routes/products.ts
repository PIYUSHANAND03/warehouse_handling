import { Router, Request, Response } from 'express'
import { db } from '../database/prisma-adapter'
import { ApiResponse, Product } from '../types'
import { z } from 'zod'

const router = Router()

// Validation schemas
const createProductSchema = z.object({
  name: z.string().min(1),
  category: z.string().min(1),
  stock: z.number().min(0),
  minStock: z.number().min(0),
  price: z.number().min(0),
  location: z.string().min(1),
  supplier: z.string().min(1),
  description: z.string().optional(),
  sku: z.string().optional(),
  weight: z.number().optional(),
  dimensions: z.object({
    length: z.number(),
    width: z.number(),
    height: z.number(),
  }).optional(),
})

const updateProductSchema = createProductSchema.partial()

// GET /api/products/stats/summary - Get product statistics (must be before /:id route)
router.get('/stats/summary', async (_req: Request, res: Response) => {
  try {
    const products = await db.getAllProducts()

    const stats = {
      totalProducts: products.length,
      inStock: products.filter(p => p.status === 'in-stock').length,
      lowStock: products.filter(p => p.status === 'low-stock').length,
      outOfStock: products.filter(p => p.status === 'out-of-stock').length,
      totalValue: products.reduce((sum, p) => sum + (p.price * p.stock), 0),
      categories: [...new Set(products.map(p => p.category))],
      averagePrice: products.length > 0
        ? products.reduce((sum, p) => sum + p.price, 0) / products.length
        : 0,
    }

    res.json({ success: true, data: stats })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to generate statistics',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// GET /api/products - Get all products with optional filtering
router.get('/', async (req: Request, res: Response) => {
  try {
    let products = await db.getAllProducts()

    // Apply filters
    const { category, status, search, lowStock } = req.query

    if (category && typeof category === 'string') {
      products = products.filter(p => p.category.toLowerCase() === category.toLowerCase())
    }

    if (status && typeof status === 'string') {
      products = products.filter(p => p.status === status)
    }

    if (lowStock === 'true') {
      products = products.filter(p => p.status === 'low-stock' || p.status === 'out-of-stock')
    }

    if (search && typeof search === 'string') {
      const searchTerm = search.toLowerCase()
      products = products.filter(p =>
        p.name.toLowerCase().includes(searchTerm) ||
        p.category.toLowerCase().includes(searchTerm) ||
        p.id.toLowerCase().includes(searchTerm) ||
        (p.sku && p.sku.toLowerCase().includes(searchTerm))
      )
    }

    // Pagination
    const page = parseInt(req.query.page as string) || 1
    const limit = parseInt(req.query.limit as string) || 50
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit

    const paginatedProducts = products.slice(startIndex, endIndex)

    const response = {
      success: true,
      data: paginatedProducts,
      pagination: {
        page,
        limit,
        total: products.length,
        pages: Math.ceil(products.length / limit),
      },
    }

    res.json(response)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to fetch products',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// GET /api/products/:id - Get a specific product
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const product = await db.getProductById(req.params.id)

    if (!product) {
      return res.status(404).json({
        success: false,
        error: 'Product not found',
      } as ApiResponse<never>)
    }

    res.json({ success: true, data: product } as ApiResponse<Product>)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to fetch product',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// POST /api/products - Create a new product
router.post('/', async (req: Request, res: Response) => {
  try {
    const validatedData = createProductSchema.parse(req.body)

    const productData = {
      ...validatedData,
      currency: '₹' as const, // Default currency
      status: 'in-stock' as const, // Will be recomputed by DB based on stock
    }

    const product = await db.createProduct(productData)

    res.status(201).json({
      success: true,
      data: product,
      message: 'Product created successfully',
    } as ApiResponse<Product>)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        message: error.errors.map(e => e.message).join(', '),
      })
    }

    res.status(500).json({
      success: false,
      error: 'Failed to create product',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// PUT /api/products/:id - Update a product
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const validatedData = updateProductSchema.parse(req.body)

    const product = await db.updateProduct(req.params.id, validatedData)

    if (!product) {
      return res.status(404).json({
        success: false,
        error: 'Product not found',
      } as ApiResponse<never>)
    }

    res.json({
      success: true,
      data: product,
      message: 'Product updated successfully',
    } as ApiResponse<Product>)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        message: error.errors.map(e => e.message).join(', '),
      })
    }

    res.status(500).json({
      success: false,
      error: 'Failed to update product',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// DELETE /api/products/:id - Delete a product
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const success = await db.deleteProduct(req.params.id)

    if (!success) {
      return res.status(404).json({
        success: false,
        error: 'Product not found',
      } as ApiResponse<never>)
    }

    res.json({ success: true, message: 'Product deleted successfully' } as ApiResponse<never>)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to delete product',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// PATCH /api/products/:id/stock - Update product stock
router.patch('/:id/stock', async (req: Request, res: Response) => {
  try {
    const { stock, operation } = req.body as { stock: number; operation?: 'add' | 'subtract' }

    if (typeof stock !== 'number') {
      return res.status(400).json({ success: false, error: 'Stock must be a number' })
    }

    const product = await db.getProductById(req.params.id)
    if (!product) {
      return res.status(404).json({ success: false, error: 'Product not found' })
    }

    let newStock = stock
    if (operation === 'add') {
      newStock = product.stock + stock
    } else if (operation === 'subtract') {
      newStock = product.stock - stock
    }

    if (newStock < 0) {
      return res.status(400).json({ success: false, error: 'Stock cannot be negative' })
    }

    const updatedProduct = await db.updateProduct(req.params.id, { stock: newStock })

    res.json({ success: true, data: updatedProduct, message: 'Stock updated successfully' } as ApiResponse<Product>)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to update stock',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// POST /api/products/bulk/delete - Bulk delete products
router.delete('/bulk/delete', async (req: Request, res: Response) => {
  try {
    const { ids } = req.body as { ids: string[] }

    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ success: false, error: 'Invalid request: ids must be a non-empty array' })
    }

    let deletedCount = 0

    for (const id of ids) {
      if (await db.deleteProduct(id)) {
        deletedCount++
      }
    }

    res.json({ success: true, data: { deleted: deletedCount }, message: `${deletedCount} products deleted successfully` })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to bulk delete products',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// PATCH /api/products/bulk/update - Bulk update products
router.patch('/bulk/update', async (req: Request, res: Response) => {
  try {
    const { updates } = req.body as { updates: { id: string; changes: Partial<Product> }[] }

    if (!Array.isArray(updates) || updates.length === 0) {
      return res.status(400).json({ success: false, error: 'Invalid request: updates must be a non-empty array' })
    }

    let updatedCount = 0

    for (const update of updates) {
      const { id, changes } = update
      if (await db.updateProduct(id, changes)) {
        updatedCount++
      }
    }

    res.json({ success: true, data: { updated: updatedCount }, message: `${updatedCount} products updated successfully` })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to bulk update products',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

export { router as productsRouter }