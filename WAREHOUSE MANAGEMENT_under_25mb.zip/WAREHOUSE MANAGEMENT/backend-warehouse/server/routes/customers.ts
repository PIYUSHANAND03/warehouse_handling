import { Router, Request, Response } from 'express'
import { db } from '../database/prisma-adapter'
import { ApiResponse, Customer } from '../types'
import { z } from 'zod'

const router = Router()

// Validation schemas
const createCustomerSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().min(1),
  address: z.object({
    street: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
    country: z.string().min(1),
  }),
  type: z.enum(['business', 'individual']),
})

const updateCustomerSchema = createCustomerSchema.partial()

// GET /api/customers/stats/summary - Get customer statistics (must be before /:id route)
router.get('/stats/summary', async (_req: Request, res: Response) => {
  try {
    const customers = await db.getAllCustomers()
    const orders = await db.getAllOrders()

    const stats = {
      totalCustomers: customers.length,
      businessCustomers: customers.filter(c => c.type === 'business').length,
      individualCustomers: customers.filter(c => c.type === 'individual').length,
      activeCustomers: customers.filter(c => c.lastOrderDate).length,
      totalCustomerValue: customers.reduce((sum, c) => sum + c.totalValue, 0),
      averageCustomerValue: customers.length > 0
        ? customers.reduce((sum, c) => sum + c.totalValue, 0) / customers.length
        : 0,
      topCustomersByValue: customers
        .sort((a, b) => b.totalValue - a.totalValue)
        .slice(0, 5)
        .map(c => ({ id: c.id, name: c.name, totalValue: c.totalValue, totalOrders: c.totalOrders })),
      topCustomersByOrders: customers
        .sort((a, b) => b.totalOrders - a.totalOrders)
        .slice(0, 5)
        .map(c => ({ id: c.id, name: c.name, totalValue: c.totalValue, totalOrders: c.totalOrders })),
    }

    res.json({ success: true, data: stats })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to generate statistics', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/customers/search/:term - Search customers by various criteria (must be before /:id route)
router.get('/search/:term', async (req: Request, res: Response) => {
  try {
    const searchTerm = req.params.term.toLowerCase()

    const customers = (await db.getAllCustomers()).filter(c =>
      c.name.toLowerCase().includes(searchTerm) ||
      c.email.toLowerCase().includes(searchTerm) ||
      c.phone.includes(searchTerm) ||
      c.address.city.toLowerCase().includes(searchTerm) ||
      c.address.state.toLowerCase().includes(searchTerm)
    )

    res.json({ success: true, data: customers.slice(0, 10) })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to search customers', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/customers/:id/orders - Get customer's order history (must be before /:id route)
router.get('/:id/orders', async (req: Request, res: Response) => {
  try {
    const customer = await db.getCustomerById(req.params.id)
    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found' })
    }

    let orders = (await db.getAllOrders()).filter(o => o.customer.id === req.params.id)

    // Apply status filter
    const { status } = req.query
    if (status && typeof status === 'string') {
      orders = orders.filter(o => o.status === status)
    }

    // Sort by order date (newest first)
    orders.sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime())

    // Pagination
    const page = parseInt(req.query.page as string) || 1
    const limit = parseInt(req.query.limit as string) || 10
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit

    const paginatedOrders = orders.slice(startIndex, endIndex)

    res.json({ success: true, data: paginatedOrders, pagination: { page, limit, total: orders.length, pages: Math.ceil(orders.length / limit) } })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch customer orders', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/customers - Get all customers with optional filtering
router.get('/', async (req: Request, res: Response) => {
  try {
    let customers = await db.getAllCustomers()

    // Apply filters
    const { type, search, city, state } = req.query

    if (type && typeof type === 'string') {
      customers = customers.filter(c => c.type === type)
    }

    if (city && typeof city === 'string') {
      customers = customers.filter(c => c.address.city.toLowerCase() === city.toLowerCase())
    }

    if (state && typeof state === 'string') {
      customers = customers.filter(c => c.address.state.toLowerCase() === state.toLowerCase())
    }

    if (search && typeof search === 'string') {
      const searchTerm = search.toLowerCase()
      customers = customers.filter(c =>
        c.name.toLowerCase().includes(searchTerm) ||
        c.email.toLowerCase().includes(searchTerm) ||
        c.phone.includes(searchTerm) ||
        c.id.toLowerCase().includes(searchTerm)
      )
    }

    // Sorting
    const sortBy = (req.query.sortBy as string) || 'name'
    const sortOrder = (req.query.sortOrder as string) || 'asc'

    customers.sort((a, b) => {
      let aVal: any, bVal: any
      switch (sortBy) {
        case 'name':
          aVal = a.name.toLowerCase()
          bVal = b.name.toLowerCase()
          break
        case 'registrationDate':
          aVal = new Date(a.registrationDate)
          bVal = new Date(b.registrationDate)
          break
        case 'totalOrders':
          aVal = a.totalOrders
          bVal = b.totalOrders
          break
        case 'totalValue':
          aVal = a.totalValue
          bVal = b.totalValue
          break
        default:
          aVal = a.name.toLowerCase()
          bVal = b.name.toLowerCase()
      }
      if (sortOrder === 'desc') {
        return aVal > bVal ? -1 : 1
      } else {
        return aVal < bVal ? -1 : 1
      }
    })

    // Pagination
    const page = parseInt(req.query.page as string) || 1
    const limit = parseInt(req.query.limit as string) || 20
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit

    const paginatedCustomers = customers.slice(startIndex, endIndex)

    const response = {
      success: true,
      data: paginatedCustomers,
      pagination: { page, limit, total: customers.length, pages: Math.ceil(customers.length / limit) },
    }

    res.json(response)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch customers', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/customers/:id - Get a specific customer
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const customer = await db.getCustomerById(req.params.id)

    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found' } as ApiResponse<never>)
    }

    // Get customer's recent orders
    const recentOrders = (await db.getAllOrders())
      .filter(o => o.customer.id === req.params.id)
      .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime())
      .slice(0, 5)

    res.json({ success: true, data: { ...customer, recentOrders } } as ApiResponse<Customer & { recentOrders: any[] }>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch customer', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// POST /api/customers - Create a new customer
router.post('/', async (req: Request, res: Response) => {
  try {
    const validatedData = createCustomerSchema.parse(req.body)

    // Check if customer with email already exists
    const existing = (await db.getAllCustomers()).find(c => c.email === validatedData.email)
    if (existing) {
      return res.status(400).json({ success: false, error: 'Customer with this email already exists' })
    }

    const customer = await db.createCustomer(validatedData)

    res.status(201).json({ success: true, data: customer, message: 'Customer created successfully' } as ApiResponse<Customer>)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', message: error.errors.map(e => e.message).join(', ') })
    }
    res.status(500).json({ success: false, error: 'Failed to create customer', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// PUT /api/customers/:id - Update a customer
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const validatedData = updateCustomerSchema.parse(req.body)

    // Check if email is being updated and if it's unique
    if (validatedData.email) {
      const existing = (await db.getAllCustomers()).find(c => c.email === validatedData.email && c.id !== req.params.id)
      if (existing) {
        return res.status(400).json({ success: false, error: 'Customer with this email already exists' })
      }
    }

    const customer = await db.updateCustomer(req.params.id, validatedData)

    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found' } as ApiResponse<never>)
    }

    res.json({ success: true, data: customer, message: 'Customer updated successfully' } as ApiResponse<Customer>)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', message: error.errors.map(e => e.message).join(', ') })
    }
    res.status(500).json({ success: false, error: 'Failed to update customer', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// DELETE /api/customers/:id - Delete a customer
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    // Check if customer has any orders
    const customerOrders = (await db.getAllOrders()).filter(o => o.customer.id === req.params.id)
    if (customerOrders.length > 0) {
      return res.status(400).json({ success: false, error: 'Cannot delete customer with existing orders' })
    }

    const success = await db.deleteCustomer(req.params.id)

    if (!success) {
      return res.status(404).json({ success: false, error: 'Customer not found' } as ApiResponse<never>)
    }

    res.json({ success: true, message: 'Customer deleted successfully' } as ApiResponse<never>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete customer', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

export { router as customersRouter }