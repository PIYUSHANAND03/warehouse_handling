import { Router, Request, Response } from 'express'
import { db } from '../database/prisma-adapter'
import { ApiResponse, Worker, CreateWorkerRequest } from '../types'
import { z } from 'zod'

const router = Router()

// Validation schemas
const createWorkerSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().min(1),
  role: z.enum(['manager', 'supervisor', 'worker', 'picker', 'packer', 'loader']),
  department: z.enum(['receiving', 'picking', 'packing', 'shipping', 'inventory', 'administration']),
  status: z.enum(['active', 'inactive', 'on-leave']).default('active'),
  hireDate: z.string().min(1),
  shift: z.enum(['morning', 'afternoon', 'night']),
  hourlyRate: z.number().min(0),
  address: z.object({
    street: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
    country: z.string().min(1),
  }),
  emergencyContact: z.object({
    name: z.string().min(1),
    phone: z.string().min(1),
    relationship: z.string().min(1),
  }).optional(),
  skills: z.array(z.string()).optional(),
  performanceRating: z.number().min(0).max(5).optional(),
  lastActive: z.string().optional(),
})

const updateWorkerSchema = createWorkerSchema.partial()

// GET /api/workers - Get all workers with filtering and pagination
router.get('/', async (req: Request, res: Response) => {
  try {
    const {
      page = 1,
      limit = 10,
      department,
      role,
      status,
      shift,
      search,
      minHourlyRate,
      maxHourlyRate,
      sortBy = 'name',
      sortOrder = 'asc'
    } = req.query as Record<string, string>

    const where: any = {}

    if (department) where.department = department
    if (role) where.role = role
    if (status) where.status = status
    if (shift) where.shift = shift
    if (search) {
      where.OR = [
        { name: { contains: search as string, mode: 'insensitive' } },
        { email: { contains: search as string, mode: 'insensitive' } },
      ]
    }
    if (minHourlyRate || maxHourlyRate) {
      where.hourlyRate = {}
      if (minHourlyRate) where.hourlyRate.gte = Number(minHourlyRate)
      if (maxHourlyRate) where.hourlyRate.lte = Number(maxHourlyRate)
    }

    const orderBy: any = {}
    orderBy[sortBy] = sortOrder === 'desc' ? 'desc' : 'asc'

    const [workers, total] = await Promise.all([
      db.getAllWorkers({
        where,
        skip: (Number(page) - 1) * Number(limit),
        take: Number(limit),
        orderBy
      }),
      db.countWorkers(where)
    ])

    const response: ApiResponse<Worker[]> = {
      success: true,
      data: workers,
      message: `Found ${total} workers`
    }

    res.json(response)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to fetch workers',
      message: error instanceof Error ? error.message : 'Unknown error'
    })
  }
})

// GET /api/workers/stats/summary - Get worker statistics
router.get('/stats/summary', async (_req: Request, res: Response) => {
  try {
    const workers = await db.getAllWorkers()

    const total = workers.length
    const active = workers.filter(w => w.status === 'active').length
    const inactive = workers.filter(w => w.status === 'inactive').length
    const onLeave = workers.filter(w => w.status === 'on-leave').length

    const stats = {
      totalWorkers: total,
      activeWorkers: active,
      inactiveWorkers: inactive,
      onLeaveWorkers: onLeave,
      byDepartment: {
        receiving: workers.filter(w => w.department === 'receiving').length,
        picking: workers.filter(w => w.department === 'picking').length,
        packing: workers.filter(w => w.department === 'packing').length,
        shipping: workers.filter(w => w.department === 'shipping').length,
        inventory: workers.filter(w => w.department === 'inventory').length,
        administration: workers.filter(w => w.department === 'administration').length,
      },
      byRole: {
        manager: workers.filter(w => w.role === 'manager').length,
        supervisor: workers.filter(w => w.role === 'supervisor').length,
        worker: workers.filter(w => w.role === 'worker').length,
        picker: workers.filter(w => w.role === 'picker').length,
        packer: workers.filter(w => w.role === 'packer').length,
        loader: workers.filter(w => w.role === 'loader').length,
      },
      byShift: {
        morning: workers.filter(w => w.shift === 'morning').length,
        afternoon: workers.filter(w => w.shift === 'afternoon').length,
        night: workers.filter(w => w.shift === 'night').length,
      },
      averageHourlyRate: total > 0 ? workers.reduce((sum, w) => sum + w.hourlyRate, 0) / total : 0,
      averagePerformanceRating: total > 0 ? workers.reduce((sum, w) => sum + (w.performanceRating || 0), 0) / total : 0,
    }

    res.json({ success: true, data: stats })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to generate statistics',
      message: error instanceof Error ? error.message : 'Unknown error'
    })
  }
})

// GET /api/workers/:id - Get specific worker
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const worker = await db.getWorkerById(id)

    if (!worker) {
      return res.status(404).json({
        success: false,
        error: 'Worker not found'
      })
    }

    const response: ApiResponse<Worker> = {
      success: true,
      data: worker
    }

    res.json(response)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to fetch worker',
      message: error instanceof Error ? error.message : 'Unknown error'
    })
  }
})

// POST /api/workers - Create new worker
router.post('/', async (req: Request, res: Response) => {
  try {
    const validatedData = createWorkerSchema.parse(req.body)
    const worker = await db.createWorker(validatedData)

    const response: ApiResponse<Worker> = {
      success: true,
      data: worker,
      message: 'Worker created successfully'
    }

    res.status(201).json(response)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        error: 'Validation error',
        message: error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')
      })
    }

    res.status(500).json({
      success: false,
      error: 'Failed to create worker',
      message: error instanceof Error ? error.message : 'Unknown error'
    })
  }
})

// PUT /api/workers/:id - Update worker
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const validatedData = updateWorkerSchema.parse(req.body)

    const worker = await db.updateWorker(id, validatedData)

    if (!worker) {
      return res.status(404).json({
        success: false,
        error: 'Worker not found'
      })
    }

    const response: ApiResponse<Worker> = {
      success: true,
      data: worker,
      message: 'Worker updated successfully'
    }

    res.json(response)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        error: 'Validation error',
        message: error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')
      })
    }

    res.status(500).json({
      success: false,
      error: 'Failed to update worker',
      message: error instanceof Error ? error.message : 'Unknown error'
    })
  }
})

// DELETE /api/workers/:id - Delete worker
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const success = await db.deleteWorker(id)

    if (!success) {
      return res.status(404).json({
        success: false,
        error: 'Worker not found'
      })
    }

    res.json({
      success: true,
      message: 'Worker deleted successfully'
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to delete worker',
      message: error instanceof Error ? error.message : 'Unknown error'
    })
  }
})

// PATCH /api/workers/:id/status - Update worker status
router.patch('/:id/status', async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const { status } = req.body

    if (!['active', 'inactive', 'on-leave'].includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status'
      })
    }

    const worker = await db.updateWorker(id, { status })

    if (!worker) {
      return res.status(404).json({
        success: false,
        error: 'Worker not found'
      })
    }

    const response: ApiResponse<Worker> = {
      success: true,
      data: worker,
      message: 'Worker status updated successfully'
    }

    res.json(response)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to update worker status',
      message: error instanceof Error ? error.message : 'Unknown error'
    })
  }
})

export const workersRouter = router