import { Router, Request, Response } from 'express'

// Simple in-memory storage for inbound records to avoid DB migration
interface InboundItem {
  id: string
  vendor: string
  eta: string // YYYY-MM-DD HH:mm or date string
  location: string
  cartons: number
  items: number
  status: 'arrived' | 'in-progress' | 'qc-hold' | 'received'
  notes?: string
}

const router = Router()

// Seed with a few examples
const inboundStore: InboundItem[] = [
  {
    id: 'INB-001', vendor: 'Fashion Fabrics Ltd', eta: '2025-01-16 10:30', location: 'Dock A', cartons: 24, items: 320, status: 'arrived', notes: 'Priority unloading'
  },
  {
    id: 'INB-002', vendor: 'TechWorld Suppliers', eta: '2025-01-16 12:15', location: 'Dock B', cartons: 12, items: 140, status: 'in-progress', notes: 'Fragile electronics'
  },
  {
    id: 'INB-003', vendor: 'Beauty Essentials', eta: '2025-01-16 13:00', location: 'Dock C', cartons: 8, items: 96, status: 'qc-hold', notes: 'Leak detected in 1 carton'
  },
  {
    id: 'INB-004', vendor: 'Premium Logistics', eta: '2025-01-16 15:45', location: 'Dock A', cartons: 30, items: 420, status: 'received', notes: 'Putaway queued'
  }
]

function nextInboundId() {
  const nums = inboundStore
    .map(i => parseInt(i.id.replace(/\D+/g, ''), 10))
    .filter(n => !isNaN(n))
  const next = (nums.length ? Math.max(...nums) + 1 : 1)
  return `INB-${String(next).padStart(3, '0')}`
}

// GET /api/inbound/stats/summary
router.get('/stats/summary', (_req: Request, res: Response) => {
  const arrived = inboundStore.filter(i => i.status === 'arrived').length
  const inProgress = inboundStore.filter(i => i.status === 'in-progress').length
  const qcHold = inboundStore.filter(i => i.status === 'qc-hold').length
  const received = inboundStore.filter(i => i.status === 'received').length
  const incoming = inboundStore.length
  res.json({ success: true, data: { incoming, arrived, inProgress, qcHold, received } })
})

// GET /api/inbound
router.get('/', (req: Request, res: Response) => {
  let data = [...inboundStore]
  const { status, search } = req.query
  if (status && typeof status === 'string' && status !== 'all') {
    data = data.filter(i => i.status === status)
  }
  if (search && typeof search === 'string') {
    const s = search.toLowerCase()
    data = data.filter(i =>
      i.id.toLowerCase().includes(s) ||
      i.vendor.toLowerCase().includes(s) ||
      i.location.toLowerCase().includes(s)
    )
  }
  res.json({ success: true, data })
})

// POST /api/inbound
router.post('/', (req: Request, res: Response) => {
  const { vendor, eta, location, cartons, items, notes } = req.body || {}
  if (!vendor || !eta || !location || typeof cartons !== 'number' || typeof items !== 'number') {
    return res.status(400).json({ success: false, error: 'Validation failed' })
  }
  const item: InboundItem = {
    id: nextInboundId(), vendor, eta, location, cartons, items, status: 'arrived', notes
  }
  inboundStore.push(item)
  res.status(201).json({ success: true, data: item, message: 'Inbound created successfully' })
})

// PUT /api/inbound/:id
router.put('/:id', (req: Request, res: Response) => {
  const idx = inboundStore.findIndex(i => i.id === req.params.id)
  if (idx === -1) return res.status(404).json({ success: false, error: 'Inbound not found' })
  const { vendor, eta, location, cartons, items, status, notes } = req.body || {}
  const current = inboundStore[idx]
  inboundStore[idx] = {
    ...current,
    vendor: vendor ?? current.vendor,
    eta: eta ?? current.eta,
    location: location ?? current.location,
    cartons: typeof cartons === 'number' ? cartons : current.cartons,
    items: typeof items === 'number' ? items : current.items,
    status: status ?? current.status,
    notes: notes ?? current.notes,
  }
  res.json({ success: true, data: inboundStore[idx], message: 'Inbound updated successfully' })
})

// PATCH /api/inbound/:id/status
router.patch('/:id/status', (req: Request, res: Response) => {
  const idx = inboundStore.findIndex(i => i.id === req.params.id)
  if (idx === -1) return res.status(404).json({ success: false, error: 'Inbound not found' })
  const { status } = req.body as { status?: InboundItem['status'] }
  if (!status || !['arrived', 'in-progress', 'qc-hold', 'received'].includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid status' })
  }
  inboundStore[idx].status = status
  res.json({ success: true, data: inboundStore[idx], message: 'Inbound status updated successfully' })
})

// DELETE /api/inbound/:id
router.delete('/:id', (req: Request, res: Response) => {
  const idx = inboundStore.findIndex(i => i.id === req.params.id)
  if (idx === -1) return res.status(404).json({ success: false, error: 'Inbound not found' })
  inboundStore.splice(idx, 1)
  res.json({ success: true, message: 'Inbound deleted successfully' })
})

export { router as inboundRouter }