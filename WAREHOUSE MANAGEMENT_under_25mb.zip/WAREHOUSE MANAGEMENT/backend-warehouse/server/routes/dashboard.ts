import { Router, Request, Response } from 'express'
import { db } from '../database/prisma-adapter'
import { ApiResponse, DashboardStats } from '../types'

const router = Router()

// GET /api/dashboard/stats - Get dashboard statistics
router.get('/stats', async (_req: Request, res: Response) => {
  try {
    const stats = await db.getDashboardStats()
    res.json({ success: true, data: stats } as ApiResponse<DashboardStats>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch dashboard stats', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/dashboard/overview - Get comprehensive dashboard overview
router.get('/overview', async (_req: Request, res: Response) => {
  try {
    const products = await db.getAllProducts()
    const orders = await db.getAllOrders()
    const customers = await db.getAllCustomers()
    const shipments = await db.getAllShipments()

    const overview = {
      // Inventory metrics
      inventory: {
        totalProducts: products.length,
        inStock: products.filter(p => p.status === 'in-stock').length,
        lowStock: products.filter(p => p.status === 'low-stock').length,
        outOfStock: products.filter(p => p.status === 'out-of-stock').length,
        totalValue: products.reduce((sum, p) => sum + (p.price * p.stock), 0),
        categories: [...new Set(products.map(p => p.category))].length,
      },

      // Orders metrics
      orders: {
        total: orders.length,
        pending: orders.filter(o => o.status === 'pending').length,
        processing: orders.filter(o => o.status === 'processing').length,
        shipped: orders.filter(o => o.status === 'shipped').length,
        completed: orders.filter(o => o.status === 'completed').length,
        cancelled: orders.filter(o => o.status === 'cancelled').length,
        totalValue: orders.reduce((sum, o) => sum + o.totalValue, 0),
        averageOrderValue: orders.length > 0 ? orders.reduce((sum, o) => sum + o.totalValue, 0) / orders.length : 0,
        highPriorityOrders: orders.filter(o => o.priority === 'high' && ['pending', 'processing'].includes(o.status)).length,
      },

      // Customer metrics
      customers: {
        total: customers.length,
        business: customers.filter(c => c.type === 'business').length,
        individual: customers.filter(c => c.type === 'individual').length,
        totalValue: customers.reduce((sum, c) => sum + c.totalValue, 0),
        averageValue: customers.length > 0 ? customers.reduce((sum, c) => sum + c.totalValue, 0) / customers.length : 0,
        activeCustomers: customers.filter(c => {
          if (!c.lastOrderDate) return false
          const lastOrder = new Date(c.lastOrderDate)
          const thirtyDaysAgo = new Date()
          thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
          return lastOrder >= thirtyDaysAgo
        }).length,
      },

      // Shipping metrics
      shipments: {
        total: shipments.length,
        pending: shipments.filter(s => s.status === 'pending').length,
        inTransit: shipments.filter(s => s.status === 'in-transit').length,
        delivered: shipments.filter(s => s.status === 'delivered').length,
        returned: shipments.filter(s => s.status === 'returned').length,
        totalCost: shipments.reduce((sum, s) => sum + s.cost, 0),
        averageCost: shipments.length > 0 ? shipments.reduce((sum, s) => sum + s.cost, 0) / shipments.length : 0,
        onTimeDeliveries: shipments.filter(s => s.status === 'delivered' && s.actualDelivery && new Date(s.actualDelivery) <= new Date(s.estimatedDelivery)).length,
      },

      // Recent activities (enhanced)
      recentActivities: [
        ...orders.slice(-5).map(o => ({
          id: o.id,
          type: 'order' as const,
          title: `New Order ${o.id}`,
          description: `Order from ${o.customer.name} - ₹${o.totalValue}`,
          timestamp: new Date(o.orderDate).toISOString(),
          status: o.status,
          statusColor: getOrderStatusColor(o.status),
          priority: o.priority,
        })),
        ...shipments.slice(-3).map(s => ({
          id: s.id,
          type: 'shipment' as const,
          title: `Shipment ${s.trackingNumber}`,
          description: `${s.carrier} - ${s.status}`,
          timestamp: new Date(s.shipDate).toISOString(),
          status: s.status,
          statusColor: getShipmentStatusColor(s.status),
        })),
        ...products.filter(p => p.status === 'low-stock').slice(-3).map(p => ({
          id: p.id,
          type: 'inventory' as const,
          title: `Low Stock Alert`,
          description: `${p.name} - ${p.stock} remaining`,
          timestamp: new Date(p.lastUpdated).toISOString(),
          status: p.status,
          statusColor: '#f59e0b',
          location: p.location,
        })),
      ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10),
    }

    res.json({ success: true, data: overview })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch dashboard overview', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/dashboard/alerts - Get system alerts and notifications
router.get('/alerts', async (_req: Request, res: Response) => {
  try {
    const products = await db.getAllProducts()
    const orders = await db.getAllOrders()
    const shipments = await db.getAllShipments()

    const alerts: any[] = []

    // Low stock alerts
    const lowStockProducts = products.filter(p => p.status === 'low-stock')
    const outOfStockProducts = products.filter(p => p.status === 'out-of-stock')

    if (outOfStockProducts.length > 0) {
      alerts.push({
        id: `alert-outofstock-${Date.now()}`,
        type: 'critical',
        title: 'Out of Stock Items',
        message: `${outOfStockProducts.length} products are out of stock`,
        count: outOfStockProducts.length,
        action: 'View Inventory',
        actionUrl: '/stock?filter=out-of-stock',
        timestamp: new Date().toISOString(),
        items: outOfStockProducts.map(p => ({ id: p.id, name: p.name, location: p.location })),
      })
    }

    if (lowStockProducts.length > 0) {
      alerts.push({
        id: `alert-lowstock-${Date.now()}`,
        type: 'warning',
        title: 'Low Stock Items',
        message: `${lowStockProducts.length} products are running low`,
        count: lowStockProducts.length,
        action: 'Restock Items',
        actionUrl: '/stock?filter=low-stock',
        timestamp: new Date().toISOString(),
        items: lowStockProducts.map(p => ({ id: p.id, name: p.name, stock: p.stock, minStock: p.minStock })),
      })
    }

    // High priority pending orders
    const highPriorityPendingOrders = orders.filter(o => o.priority === 'high' && ['pending', 'processing'].includes(o.status))

    if (highPriorityPendingOrders.length > 0) {
      alerts.push({
        id: `alert-priority-orders-${Date.now()}`,
        type: 'warning',
        title: 'High Priority Orders',
        message: `${highPriorityPendingOrders.length} high priority orders need attention`,
        count: highPriorityPendingOrders.length,
        action: 'Process Orders',
        actionUrl: '/orders?priority=high&status=pending',
        timestamp: new Date().toISOString(),
        items: highPriorityPendingOrders.map(o => ({ id: o.id, customer: o.customer.name, value: o.totalValue, deliveryDate: o.deliveryDate })),
      })
    }

    // Overdue shipments
    const overdueShipments = shipments.filter(s => s.status === 'in-transit' && new Date(s.estimatedDelivery) < new Date())

    if (overdueShipments.length > 0) {
      alerts.push({
        id: `alert-overdue-shipments-${Date.now()}`,
        type: 'error',
        title: 'Overdue Shipments',
        message: `${overdueShipments.length} shipments are overdue`,
        count: overdueShipments.length,
        action: 'Check Shipments',
        actionUrl: '/pending-shipments',
        timestamp: new Date().toISOString(),
        items: overdueShipments.map(s => ({ id: s.id, trackingNumber: s.trackingNumber, carrier: s.carrier, estimatedDelivery: s.estimatedDelivery })),
      })
    }

    res.json({ success: true, data: { alerts, totalAlerts: alerts.length, criticalAlerts: alerts.filter(a => a.type === 'critical').length, warningAlerts: alerts.filter(a => a.type === 'warning').length, errorAlerts: alerts.filter(a => a.type === 'error').length } })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch alerts', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/dashboard/recent-activity - Get recent system activities
router.get('/recent-activity', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 20
    const type = req.query.type as string

    const orders = await db.getAllOrders()
    const shipments = await db.getAllShipments()
    const products = await db.getAllProducts()

    let activities: any[] = []

    if (!type || type === 'order') {
      activities.push(...orders.slice(-10).map(o => ({
        id: `order-${o.id}`,
        type: 'order' as const,
        title: `Order ${o.id}`,
        description: `${o.status.charAt(0).toUpperCase() + o.status.slice(1)} order from ${o.customer.name}`,
        timestamp: new Date(o.orderDate).toISOString(),
        status: o.status,
        statusColor: getOrderStatusColor(o.status),
        metadata: { orderId: o.id, customerName: o.customer.name, totalValue: o.totalValue, priority: o.priority },
      })))
    }

    if (!type || type === 'shipment') {
      activities.push(...shipments.slice(-10).map(s => ({
        id: `shipment-${s.id}`,
        type: 'shipment' as const,
        title: `Shipment ${s.trackingNumber}`,
        description: `${s.status.charAt(0).toUpperCase() + s.status.slice(1)} via ${s.carrier}`,
        timestamp: new Date(s.shipDate).toISOString(),
        status: s.status,
        statusColor: getShipmentStatusColor(s.status),
        metadata: { shipmentId: s.id, trackingNumber: s.trackingNumber, carrier: s.carrier, orderId: s.orderId },
      })))
    }

    if (!type || type === 'inventory') {
      activities.push(...products.filter(p => p.status !== 'in-stock').slice(-5).map(p => ({
        id: `inventory-${p.id}`,
        type: 'inventory' as const,
        title: `${p.status === 'low-stock' ? 'Low Stock' : 'Out of Stock'} Alert`,
        description: `${p.name} in ${p.location}`,
        timestamp: new Date(p.lastUpdated).toISOString(),
        status: p.status,
        statusColor: p.status === 'out-of-stock' ? '#ef4444' : '#f59e0b',
        metadata: { productId: p.id, productName: p.name, currentStock: p.stock, minStock: p.minStock, location: p.location },
      })))
    }

    activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

    res.json({ success: true, data: { activities: activities.slice(0, limit), total: activities.length, hasMore: activities.length > limit } })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch recent activities', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// Helper color functions (copied from original)
function getOrderStatusColor(status: string) {
  switch (status) {
    case 'pending':
      return '#f59e0b'
    case 'processing':
      return '#3b82f6'
    case 'shipped':
      return '#6366f1'
    case 'completed':
      return '#10b981'
    case 'cancelled':
      return '#ef4444'
    default:
      return '#6b7280'
  }
}

function getShipmentStatusColor(status: string) {
  switch (status) {
    case 'pending':
      return '#f59e0b'
    case 'in-transit':
      return '#3b82f6'
    case 'delivered':
      return '#10b981'
    case 'returned':
      return '#ef4444'
    default:
      return '#6b7280'
  }
}

export { router as dashboardRouter }