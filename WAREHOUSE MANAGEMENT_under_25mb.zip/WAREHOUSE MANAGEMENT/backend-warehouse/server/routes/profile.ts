import { Router, Request, Response } from 'express';
import { ApiResponse } from '../types';
import { UserProfile } from '../types';

const router = Router();

// GET /api/profile - return the current authenticated user's profile (mock for now)
router.get('/', (_req: Request, res: Response) => {
  const user: UserProfile = {
    id: 'u_001',
    name: 'Alex Johnson',
    email: 'alex.johnson@example.com',
    role: 'admin',
    avatarUrl: 'https://i.pravatar.cc/100?img=1',
  };

  res.json({ success: true, data: user } as ApiResponse<UserProfile>);
});

export { router as profileRouter };