import { Router, Request, Response } from 'express'
import { db } from '../database/prisma-adapter'
import { ApiResponse, Shipment } from '../types'
import { z } from 'zod'

const router = Router()

// Validation schemas
const createShipmentSchema = z.object({
  orderId: z.string().min(1),
  carrier: z.string().min(1),
  estimatedDelivery: z.string(),
  origin: z.object({
    address: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
  }),
  destination: z.object({
    address: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
  }),
  weight: z.number().min(0),
  dimensions: z.object({ length: z.number().min(0), width: z.number().min(0), height: z.number().min(0) }),
  cost: z.number().min(0),
})

const updateShipmentSchema = z.object({
  status: z.enum(['pending', 'in-transit', 'delivered', 'returned']).optional(),
  carrier: z.string().optional(),
  estimatedDelivery: z.string().optional(),
  actualDelivery: z.string().optional(),
  cost: z.number().min(0).optional(),
})

// GET /api/shipments/stats/summary - Get shipment statistics (must be before /:id route)
router.get('/stats/summary', async (_req: Request, res: Response) => {
  try {
    const shipments = await db.getAllShipments()

    const stats = {
      totalShipments: shipments.length,
      pending: shipments.filter(s => s.status === 'pending').length,
      inTransit: shipments.filter(s => s.status === 'in-transit').length,
      delivered: shipments.filter(s => s.status === 'delivered').length,
      returned: shipments.filter(s => s.status === 'returned').length,
      totalShippingCost: shipments.reduce((sum, s) => sum + s.cost, 0),
      averageShippingCost: shipments.length > 0 ? shipments.reduce((sum, s) => sum + s.cost, 0) / shipments.length : 0,
      carrierBreakdown: shipments.reduce((carriers: any, s) => { carriers[s.carrier] = (carriers[s.carrier] || 0) + 1; return carriers }, {} as Record<string, number>),
      onTimeDeliveries: shipments.filter(s => s.status === 'delivered' && s.actualDelivery && new Date(s.actualDelivery) <= new Date(s.estimatedDelivery)).length,
    }

    res.json({ success: true, data: stats })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to generate statistics', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/shipments/track/:trackingNumber - Track shipment by tracking number (must be before /:id route)
router.get('/track/:trackingNumber', async (req: Request, res: Response) => {
  try {
    const tn = req.params.trackingNumber.toLowerCase()
    const s = (await db.getAllShipments()).find(x => x.trackingNumber.toLowerCase() === tn)

    if (!s) return res.status(404).json({ success: false, error: 'Shipment not found' })

    const order = await db.getOrderById(s.orderId)

    res.json({ success: true, data: { ...s, order: order ? { id: order.id, customer: order.customer, items: order.items, totalValue: order.totalValue } : null } })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to track shipment', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/shipments/pending - Get all pending shipments (must be before /:id route)
router.get('/pending', async (_req: Request, res: Response) => {
  try {
    const pendingShipments = (await db.getAllShipments()).filter(s => s.status === 'pending' || s.status === 'in-transit')
    pendingShipments.sort((a, b) => new Date(a.estimatedDelivery).getTime() - new Date(b.estimatedDelivery).getTime())
    res.json({ success: true, data: pendingShipments })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch pending shipments', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/shipments - Get all shipments with optional filtering
router.get('/', async (req: Request, res: Response) => {
  try {
    let shipments = await db.getAllShipments()

    // Apply filters
    const { status, carrier, orderId, search } = req.query

    if (status && typeof status === 'string') shipments = shipments.filter(s => s.status === status)
    if (carrier && typeof carrier === 'string') shipments = shipments.filter(s => s.carrier.toLowerCase().includes(carrier.toLowerCase()))
    if (orderId && typeof orderId === 'string') shipments = shipments.filter(s => s.orderId === orderId)

    if (search && typeof search === 'string') {
      const searchTerm = search.toLowerCase()
      shipments = shipments.filter(s =>
        s.id.toLowerCase().includes(searchTerm) ||
        s.orderId.toLowerCase().includes(searchTerm) ||
        s.trackingNumber.toLowerCase().includes(searchTerm) ||
        s.carrier.toLowerCase().includes(searchTerm)
      )
    }

    // Sorting
    const sortBy = (req.query.sortBy as string) || 'shipDate'
    const sortOrder = (req.query.sortOrder as string) || 'desc'

    shipments.sort((a, b) => {
      let aVal: any, bVal: any
      switch (sortBy) {
        case 'shipDate':
          aVal = new Date(a.shipDate)
          bVal = new Date(b.shipDate)
          break
        case 'estimatedDelivery':
          aVal = new Date(a.estimatedDelivery)
          bVal = new Date(b.estimatedDelivery)
          break
        case 'carrier':
          aVal = a.carrier.toLowerCase()
          bVal = b.carrier.toLowerCase()
          break
        case 'cost':
          aVal = a.cost
          bVal = b.cost
          break
        default:
          aVal = new Date(a.shipDate)
          bVal = new Date(b.shipDate)
      }
      if (sortOrder === 'desc') return aVal > bVal ? -1 : 1
      else return aVal < bVal ? -1 : 1
    })

    // Pagination
    const page = parseInt(req.query.page as string) || 1
    const limit = parseInt(req.query.limit as string) || 20
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit

    const paginatedShipments = shipments.slice(startIndex, endIndex)

    const response = { success: true, data: paginatedShipments, pagination: { page, limit, total: shipments.length, pages: Math.ceil(shipments.length / limit) } }

    res.json(response)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch shipments', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/shipments/:id - Get a specific shipment
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const shipment = await db.getShipmentById(req.params.id)

    if (!shipment) return res.status(404).json({ success: false, error: 'Shipment not found' } as ApiResponse<never>)

    const order = await db.getOrderById(shipment.orderId)

    res.json({ success: true, data: { ...shipment, order } } as ApiResponse<Shipment & { order: any }>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch shipment', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// POST /api/shipments - Create a new shipment
router.post('/', async (req: Request, res: Response) => {
  try {
    const validatedData = createShipmentSchema.parse(req.body)

    // Validate order exists
    const order = await db.getOrderById(validatedData.orderId)
    if (!order) return res.status(400).json({ success: false, error: 'Order not found' })

    // Check if shipment already exists for this order
    const existing = (await db.getAllShipments()).find(s => s.orderId === validatedData.orderId)
    if (existing) return res.status(400).json({ success: false, error: 'Shipment already exists for this order' })

    // Generate tracking number (keep same format)
    const trackingNumber = `TRK-${Date.now()}-${Math.random().toString(36).substr(2, 4).toUpperCase()}`

    const shipmentData = {
      ...validatedData,
      trackingNumber,
      status: 'pending' as const,
      shipDate: new Date().toISOString().split('T')[0],
    }

    const shipment = await db.createShipment(shipmentData)

    // Update order with tracking number (do not force status change here; client sets separately)
    await db.updateOrder(validatedData.orderId, { trackingNumber, status: order.status === 'pending' ? 'processing' : order.status })

    res.status(201).json({ success: true, data: shipment, message: 'Shipment created successfully' } as ApiResponse<Shipment>)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', message: error.errors.map(e => e.message).join(', ') })
    }
    res.status(500).json({ success: false, error: 'Failed to create shipment', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// PUT /api/shipments/:id - Update a shipment
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const validatedData = updateShipmentSchema.parse(req.body)

    const shipment = await db.updateShipment(req.params.id, validatedData)

    if (!shipment) return res.status(404).json({ success: false, error: 'Shipment not found' } as ApiResponse<never>)

    // Update related order status if shipment status changed
    if (validatedData.status) {
      const order = await db.getOrderById(shipment.orderId)
      if (order) {
        let orderStatus = order.status
        switch (validatedData.status) {
          case 'in-transit':
            orderStatus = 'shipped'
            break
          case 'delivered':
            orderStatus = 'completed'
            break
          case 'returned':
            orderStatus = 'cancelled'
            break
        }
        if (orderStatus !== order.status) {
          await db.updateOrder(shipment.orderId, { status: orderStatus })
        }
      }
    }

    res.json({ success: true, data: shipment, message: 'Shipment updated successfully' } as ApiResponse<Shipment>)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', message: error.errors.map(e => e.message).join(', ') })
    }
    res.status(500).json({ success: false, error: 'Failed to update shipment', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// DELETE /api/shipments/:id - Delete a shipment
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const shipment = await db.getShipmentById(req.params.id)
    if (!shipment) return res.status(404).json({ success: false, error: 'Shipment not found' })

    // Only allow deletion of pending shipments
    if (shipment.status !== 'pending') {
      return res.status(400).json({ success: false, error: 'Only pending shipments can be deleted' })
    }

    await db.deleteShipment(req.params.id)

    // Remove tracking number from associated order
    await db.updateOrder(shipment.orderId, { trackingNumber: undefined })

    res.json({ success: true, message: 'Shipment deleted successfully' } as ApiResponse<never>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete shipment', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// PATCH /api/shipments/:id/status - Update shipment status
router.patch('/:id/status', async (req: Request, res: Response) => {
  try {
    const { status } = req.body as { status?: Shipment['status'] }

    if (!status || !['pending', 'in-transit', 'delivered', 'returned'].includes(status)) {
      return res.status(400).json({ success: false, error: 'Invalid status' })
    }

    const updates: Partial<Shipment> = { status }

    // Set actual delivery date if status is delivered
    if (status === 'delivered') {
      updates.actualDelivery = new Date().toISOString().split('T')[0]
    }

    const shipment = await db.updateShipment(req.params.id, updates)

    if (!shipment) return res.status(404).json({ success: false, error: 'Shipment not found' })

    res.json({ success: true, data: shipment, message: `Shipment status updated to ${status}` } as ApiResponse<Shipment>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update shipment status', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

export { router as shipmentsRouter }