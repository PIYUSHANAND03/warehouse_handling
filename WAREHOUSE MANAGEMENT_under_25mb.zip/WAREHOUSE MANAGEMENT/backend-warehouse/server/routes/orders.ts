import { Router, Request, Response } from 'express'
import { db } from '../database/prisma-adapter'
import { z } from 'zod'
import PDFDocument from 'pdfkit'
import { CreateOrderRequest, ApiResponse, Order } from '../types'

export const ordersRouter = Router()
// Validation schemas
const createOrderSchema = z.object({
  customerId: z.string().min(1),
  items: z.array(z.object({
    productId: z.string().min(1),
    quantity: z.number().min(1),
  })).min(1),
  priority: z.enum(['low', 'medium', 'high']),
  deliveryDate: z.string(),
  shippingAddress: z.object({
    street: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
    country: z.string().min(1),
  }),
  billingAddress: z.object({
    street: z.string().min(1),
    city: z.string().min(1),
    state: z.string().min(1),
    pincode: z.string().min(1),
    country: z.string().min(1),
  }).optional(),
  notes: z.string().optional(),
  specialInstructions: z.string().optional(),
  paymentMethod: z.string().optional(),
  paymentTerms: z.string().optional(),
  shippingMethod: z.string().optional(),
  orderSource: z.string().optional(),
  gstNumber: z.string().optional(),
  discount: z.object({
    type: z.enum(['percentage', 'fixed']),
    value: z.number().min(0),
  }).optional(),
  assignedWorker: z.string().optional(),
  expectedDeliveryTime: z.string().optional(),
})

const updateOrderSchema = z.object({
  status: z.enum(['pending', 'processing', 'shipped', 'completed', 'cancelled']).optional(),
  priority: z.enum(['low', 'medium', 'high']).optional(),
  deliveryDate: z.string().optional(),
  trackingNumber: z.string().optional(),
  notes: z.string().optional(),
})

// GET /api/orders/stats/summary - Get order statistics (must be before /:id route)
ordersRouter.get('/stats/summary', async (_req: Request, res: Response) => {
  try {
    const orders = await db.getAllOrders()

    const stats = {
      totalOrders: orders.length,
      pending: orders.filter(o => o.status === 'pending').length,
      processing: orders.filter(o => o.status === 'processing').length,
      shipped: orders.filter(o => o.status === 'shipped').length,
      completed: orders.filter(o => o.status === 'completed').length,
      cancelled: orders.filter(o => o.status === 'cancelled').length,
      totalValue: orders.reduce((sum, o) => sum + o.totalValue, 0),
      completedValue: orders
        .filter(o => o.status === 'completed')
        .reduce((sum, o) => sum + o.totalValue, 0),
      averageOrderValue: orders.length > 0
        ? orders.reduce((sum, o) => sum + o.totalValue, 0) / orders.length
        : 0,
      highPriorityOrders: orders.filter(o => o.priority === 'high' && o.status !== 'completed').length,
    }

    res.json({ success: true, data: stats })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to generate statistics',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// GET /api/orders/customer/:customerId - Get orders by customer (must be before /:id route)
ordersRouter.get('/customer/:customerId', async (req: Request, res: Response) => {
  try {
    const customer = await db.getCustomerById(req.params.customerId)
    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found' })
    }

    let orders = (await db.getAllOrders()).filter(o => o.customer.id === req.params.customerId)

    // Pagination
    const page = parseInt(req.query.page as string) || 1
    const limit = parseInt(req.query.limit as string) || 10
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit

    const paginatedOrders = orders.slice(startIndex, endIndex)

    res.json({
      success: true,
      data: paginatedOrders,
      pagination: { page, limit, total: orders.length, pages: Math.ceil(orders.length / limit) },
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to fetch customer orders',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// GET /api/orders - Get all orders with optional filtering
ordersRouter.get('/', async (req: Request, res: Response) => {
  try {
    let orders = await db.getAllOrders()

    // Apply filters
    const { status, priority, customerId, search } = req.query

    if (status && typeof status === 'string') {
      orders = orders.filter(o => o.status === status)
    }

    if (priority && typeof priority === 'string') {
      orders = orders.filter(o => o.priority === priority)
    }

    if (customerId && typeof customerId === 'string') {
      orders = orders.filter(o => o.customer.id === customerId)
    }

    if (search && typeof search === 'string') {
      const searchTerm = search.toLowerCase()
      orders = orders.filter(o =>
        o.id.toLowerCase().includes(searchTerm) ||
        o.customer.name.toLowerCase().includes(searchTerm) ||
        o.customer.email.toLowerCase().includes(searchTerm)
      )
    }

    // Sorting
    const sortBy = (req.query.sortBy as string) || 'orderDate'
    const sortOrder = (req.query.sortOrder as string) || 'desc'

    orders.sort((a, b) => {
      let aVal: any, bVal: any
      switch (sortBy) {
        case 'orderDate':
          aVal = new Date(a.orderDate)
          bVal = new Date(b.orderDate)
          break
        case 'totalValue':
          aVal = a.totalValue
          bVal = b.totalValue
          break
        case 'customer':
          aVal = a.customer.name.toLowerCase()
          bVal = b.customer.name.toLowerCase()
          break
        default:
          aVal = a.orderDate
          bVal = b.orderDate
      }
      if (sortOrder === 'desc') {
        return aVal > bVal ? -1 : 1
      } else {
        return aVal < bVal ? -1 : 1
      }
    })

    // Pagination
    const page = parseInt(req.query.page as string) || 1
    const limit = parseInt(req.query.limit as string) || 20
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit

    const paginatedOrders = orders.slice(startIndex, endIndex)

    const response = {
      success: true,
      data: paginatedOrders,
      pagination: { page, limit, total: orders.length, pages: Math.ceil(orders.length / limit) },
    }

    res.json(response)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to fetch orders',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// GET /api/orders/:id - Get a specific order
ordersRouter.get('/:id', async (req: Request, res: Response) => {
  try {
    const order = await db.getOrderById(req.params.id)

    if (!order) {
      return res.status(404).json({ success: false, error: 'Order not found' } as ApiResponse<never>)
    }

    res.json({ success: true, data: order } as ApiResponse<Order>)
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to fetch order',
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  }
})

// GET /api/orders/:id/invoice - Get invoice for an order (computed if not persisted)
ordersRouter.get('/:id/invoice', async (req: Request, res: Response) => {
  try {
    const order = await db.getOrderById(req.params.id)
    if (!order) return res.status(404).json({ success: false, error: 'Order not found' })

    // Best-effort: try to fetch persisted invoice via prisma if available
    let invoice: any = null
    try {
      const { prisma } = await import('../db')
      // @ts-ignore optional model
      invoice = await (prisma as any).invoice?.findFirst?.({ where: { orderId: order.id } })
    } catch {}

    if (!invoice) {
      // Compute transient invoice
      const subtotal = order.items.reduce((s, it) => s + it.totalPrice, 0)
      const tax = Math.round(subtotal * 0.18 * 100) / 100
      const total = subtotal + tax
      invoice = {
        id: `INV-TEMP-${order.id}`,
        orderId: order.id,
        invoiceDate: new Date(order.orderDate).toISOString(),
        dueDate: new Date(new Date(order.orderDate).getTime() + 14*24*60*60*1000).toISOString(),
        status: 'unpaid',
        subtotal,
        tax,
        total,
        currency: 'INR',
        items: order.items.map((it) => ({
          productId: it.productId,
          description: it.productName,
          quantity: it.quantity,
          unitPrice: it.unitPrice,
          total: it.totalPrice,
        }))
      }
    }

    res.json({ success: true, data: invoice })
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch invoice', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// GET /api/orders/:id/invoice/download - Download invoice (html|csv|excel|pdf)
ordersRouter.get('/:id/invoice/download', async (req: Request, res: Response) => {
  try {
    const order = await db.getOrderById(req.params.id)
    if (!order) return res.status(404).send('Order not found')

    // Reuse the invoice compute from endpoint above
    const subtotal = order.items.reduce((s, it) => s + it.totalPrice, 0)
    const tax = Math.round(subtotal * 0.18 * 100) / 100
    const total = subtotal + tax
    const invId = `INV-${order.id}`

    const fmt = String(req.query.format || 'html').toLowerCase()

    // CSV/Excel (Excel opens CSV)
    if (fmt === 'csv' || fmt === 'excel') {
      const rows = [
        ['Invoice ID', invId],
        ['Order ID', order.id],
        ['Invoice Date', new Date(order.orderDate).toISOString()],
        ['Due Date', new Date(new Date(order.orderDate).getTime()+14*24*60*60*1000).toISOString()],
        [],
        ['Item', 'Quantity', 'Unit Price', 'Total'],
        ...order.items.map(it => [it.productName, String(it.quantity), String(it.unitPrice), String(it.totalPrice)]),
        [],
        ['Subtotal', '', '', String(subtotal)],
        ['Tax (18% GST)', '', '', String(tax)],
        ['Grand Total', '', '', String(total)],
      ]
      const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\r\n')
      const filename = `invoice-${order.id}.csv`
      res.setHeader('Content-Type', 'text/csv; charset=utf-8')
      res.setHeader('Content-Disposition', `attachment; filename=${filename}`)
      return res.send(csv)
    }

    const html = `<!DOCTYPE html><html><head><meta charset="utf-8" /><title>Invoice ${invId}</title>
<style>body{font-family:Arial,Helvetica,sans-serif;color:#111;padding:24px}h1{margin:0 0 8px}table{width:100%;border-collapse:collapse;margin-top:16px}th,td{border:1px solid #ddd;padding:8px;text-align:left}tfoot td{font-weight:bold}small{color:#555}</style>
</head><body>
<h1>Invoice ${invId}</h1>
<small>Order ${order.id} • Date ${new Date(order.orderDate).toLocaleDateString()} • Due ${new Date(new Date(order.orderDate).getTime()+14*24*60*60*1000).toLocaleDateString()}</small>
<hr />
<p><strong>Bill To:</strong><br/>${order.customer.name}<br/>${order.customer.email}<br/>${order.shippingAddress.street}, ${order.shippingAddress.city}, ${order.shippingAddress.state} ${order.shippingAddress.pincode}, ${order.shippingAddress.country}</p>
<table><thead><tr><th>Item</th><th>Qty</th><th>Unit</th><th>Total</th></tr></thead><tbody>
${order.items.map(it => `<tr><td>${it.productName}</td><td>${it.quantity}</td><td>₹${it.unitPrice.toLocaleString('en-IN')}</td><td>₹${it.totalPrice.toLocaleString('en-IN')}</td></tr>`).join('')}
</tbody><tfoot><tr><td colspan="3">Subtotal</td><td>₹${subtotal.toLocaleString('en-IN')}</td></tr><tr><td colspan="3">Tax (18% GST)</td><td>₹${tax.toLocaleString('en-IN')}</td></tr><tr><td colspan="3">Grand Total</td><td>₹${total.toLocaleString('en-IN')}</td></tr></tfoot></table>
</body></html>`

    if (fmt === 'pdf') {
      // Generate actual PDF using PDFKit
      const doc = new PDFDocument({ margin: 50, size: 'A4' })
      
      res.setHeader('Content-Type', 'application/pdf')
      res.setHeader('Content-Disposition', `attachment; filename=invoice-${order.id}.pdf`)
      
      // Pipe PDF to response
      doc.pipe(res)
      
      // invenTREE Header with dark background
      doc.rect(0, 0, 612, 100).fill('#1a1d29')
      
      // Logo box (blue rounded rectangle)
      doc.roundedRect(50, 25, 50, 50, 8).fill('#3b82f6')
      
      // Icon lines (warehouse/inventory icon)
      doc.fillColor('#ffffff')
      doc.rect(58, 33, 34, 4).fill('#ffffff')
      doc.rect(58, 41, 34, 4).fill('#ffffff')
      doc.rect(58, 49, 34, 4).fill('#ffffff')
      doc.rect(58, 57, 34, 4).fill('#ffffff')
      
      // invenTREE text
      doc.fontSize(28).font('Helvetica-Bold')
      doc.fillColor('#ffffff').text('inven', 115, 35, { continued: true })
      doc.fillColor('#3b82f6').text('TREE')
      
      // Tagline
      doc.fontSize(11).font('Helvetica').fillColor('#9ca3af')
      doc.text('where inventory grows in order', 115, 60, { align: 'left' })
      
      // Reset color and position
      doc.fillColor('#000000')
      doc.moveDown(3)
      
      // Invoice Title
      doc.fontSize(26).font('Helvetica-Bold').text(`Invoice ${invId}`, { align: 'left' })
      doc.moveDown(0.3)
      
      // Order details
      doc.fontSize(11).font('Helvetica')
      doc.fillColor('#555555')
      doc.text(`Order ${order.id} • Date ${new Date(order.orderDate).toLocaleDateString()} • Due ${new Date(new Date(order.orderDate).getTime()+14*24*60*60*1000).toLocaleDateString()}`, { align: 'left' })
      doc.fillColor('#000000')
      doc.moveDown(1.5)
      
      // Bill To section with box
      const billToY = doc.y
      doc.roundedRect(50, billToY, 250, 90, 5).stroke('#cccccc')
      doc.fontSize(13).font('Helvetica-Bold').fillColor('#2563eb').text('Bill To:', 60, billToY + 10)
      doc.fontSize(11).font('Helvetica').fillColor('#000000')
      doc.text(order.customer.name, 60, billToY + 30)
      doc.fontSize(10).fillColor('#555555')
      doc.text(order.customer.email, 60, billToY + 45)
      doc.text(`${order.shippingAddress.street}, ${order.shippingAddress.city}, ${order.shippingAddress.state} ${order.shippingAddress.pincode}, ${order.shippingAddress.country}`, 60, billToY + 60, { width: 230 })
      doc.fillColor('#000000')
      
      doc.y = billToY + 100
      doc.moveDown(1)
      
      // Items table header with background
      const tableTop = doc.y
      const itemCol = 50
      const qtyCol = 280
      const unitCol = 360
      const totalCol = 470
      
      // Header background
      doc.rect(itemCol, tableTop - 5, 495, 25).fill('#f3f4f6')
      
      // Header text
      doc.fontSize(11).font('Helvetica-Bold').fillColor('#1f2937')
      doc.text('Item', itemCol + 5, tableTop + 3)
      doc.text('Qty', qtyCol, tableTop + 3)
      doc.text('Unit Price', unitCol, tableTop + 3)
      doc.text('Total', totalCol, tableTop + 3)
      
      // Draw header line
      doc.strokeColor('#d1d5db').lineWidth(1.5)
      doc.moveTo(itemCol, tableTop + 20).lineTo(545, tableTop + 20).stroke()
      
      // Items
      doc.font('Helvetica').fillColor('#000000')
      let y = tableTop + 30
      order.items.forEach((it, index) => {
        // Alternate row background
        if (index % 2 === 0) {
          doc.rect(itemCol, y - 5, 495, 25).fill('#fafafa')
        }
        
        doc.fillColor('#000000')
        doc.fontSize(10).text(it.productName, itemCol + 5, y, { width: 210 })
        doc.text(String(it.quantity), qtyCol, y, { width: 60, align: 'center' })
        doc.text(`Rs. ${it.unitPrice.toLocaleString('en-IN')}`, unitCol, y)
        doc.font('Helvetica-Bold').text(`Rs. ${it.totalPrice.toLocaleString('en-IN')}`, totalCol, y)
        doc.font('Helvetica')
        y += 30
      })
      
      // Draw line before totals
      doc.strokeColor('#d1d5db').lineWidth(1.5)
      doc.moveTo(itemCol, y).lineTo(545, y).stroke()
      y += 15
      
      // Totals section with background
      const totalsBoxY = y
      doc.rect(340, totalsBoxY - 5, 205, 85).fill('#f9fafb')
      
      // Totals text
      doc.fillColor('#000000')
      doc.fontSize(11).font('Helvetica')
      doc.text('Subtotal:', unitCol + 10, y)
      doc.text(`Rs. ${subtotal.toLocaleString('en-IN')}`, totalCol, y)
      y += 22
      
      doc.text('Tax (18% GST):', unitCol + 10, y)
      doc.text(`Rs. ${tax.toLocaleString('en-IN')}`, totalCol, y)
      y += 25
      
      // Grand total with highlight
      doc.rect(340, y - 5, 205, 25).fill('#2563eb')
      doc.fontSize(12).font('Helvetica-Bold').fillColor('#ffffff')
      doc.text('Grand Total:', unitCol + 10, y)
      doc.text(`Rs. ${total.toLocaleString('en-IN')}`, totalCol, y)
      
      // Footer
      doc.fillColor('#999999')
      doc.fontSize(9).font('Helvetica')
      doc.text('Thank you for your business!', 50, 750, { align: 'center', width: 500 })
      
      // Finalize PDF
      doc.end()
      return
    }

    res.setHeader('Content-Type', 'text/html; charset=utf-8')
    res.setHeader('Content-Disposition', `attachment; filename=invoice-${order.id}.html`)
    res.send(html)
  } catch (error) {
    res.status(500).send('Failed to generate invoice')
  }
})

// POST /api/orders - Create a new order
ordersRouter.post('/', async (req: Request, res: Response) => {
  try {
    const validatedData = createOrderSchema.parse(req.body) as CreateOrderRequest

    // Validate customer exists
    const customer = await db.getCustomerById(validatedData.customerId)
    if (!customer) {
      return res.status(400).json({ success: false, error: 'Customer not found' })
    }

    // Validate products exist and have sufficient stock
    const stockErrors: string[] = []
    // We'll fetch all products once by calling db.getAllProducts for simplicity
    const products = await db.getAllProducts()
    const productMap = new Map(products.map(p => [p.id, p]))

    for (const item of validatedData.items) {
      const product = productMap.get(item.productId)
      if (!product) {
        stockErrors.push(`Product ${item.productId} not found`)
        continue
      }
      if (product.stock < item.quantity) {
        stockErrors.push(`Insufficient stock for ${product.name}. Available: ${product.stock}, Required: ${item.quantity}`)
      }
    }

    if (stockErrors.length > 0) {
      return res.status(400).json({ success: false, error: 'Stock validation failed', message: stockErrors.join('; ') })
    }

    const order = await db.createOrder(validatedData)

    if (!order) {
      return res.status(400).json({ success: false, error: 'Failed to create order' })
    }

    res.status(201).json({ success: true, data: order, message: 'Order created successfully' } as ApiResponse<Order>)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', message: error.errors.map(e => e.message).join(', ') })
    }
    res.status(500).json({ success: false, error: 'Failed to create order', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// PUT /api/orders/:id - Update an order
ordersRouter.put('/:id', async (req: Request, res: Response) => {
  try {
    const validatedData = updateOrderSchema.parse(req.body)

    const order = await db.updateOrder(req.params.id, validatedData)

    if (!order) {
      return res.status(404).json({ success: false, error: 'Order not found' } as ApiResponse<never>)
    }

    res.json({ success: true, data: order, message: 'Order updated successfully' } as ApiResponse<Order>)
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: 'Validation failed', message: error.errors.map(e => e.message).join(', ') })
    }
    res.status(500).json({ success: false, error: 'Failed to update order', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// DELETE /api/orders/:id - Delete an order
ordersRouter.delete('/:id', async (req: Request, res: Response) => {
  try {
    const order = await db.getOrderById(req.params.id)
    if (!order) {
      return res.status(404).json({ success: false, error: 'Order not found' })
    }

    // Only allow deletion of pending orders
    if (order.status !== 'pending') {
      return res.status(400).json({ success: false, error: 'Only pending orders can be deleted' })
    }

    // Restore stock for order items
    // Note: This logic would ideally be in the adapter with transactions
    const products = await db.getAllProducts()
    const productMap = new Map(products.map(p => [p.id, p]))
    for (const item of order.items) {
      const product = productMap.get(item.productId)
      if (product) {
        await db.updateProduct(product.id, { stock: product.stock + item.quantity })
      }
    }

    await db.deleteOrder(req.params.id)

    res.json({ success: true, message: 'Order deleted successfully' } as ApiResponse<never>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete order', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})

// PATCH /api/orders/:id/status - Update order status
ordersRouter.patch('/:id/status', async (req: Request, res: Response) => {
  try {
    const { status } = req.body as { status?: Order['status'] }
    if (!status || !['pending', 'processing', 'shipped', 'completed', 'cancelled'].includes(status)) {
      return res.status(400).json({ success: false, error: 'Invalid status' })
    }

    const updatedOrder = await db.updateOrder(req.params.id, { status })

    if (!updatedOrder) {
      return res.status(404).json({ success: false, error: 'Order not found' })
    }

    // If status is 'shipped', create a shipment
    if (status === 'shipped') {
      const orderDetails = await db.getOrderById(req.params.id);
      if (orderDetails) {
        const shipment = await db.createShipment({
          orderId: orderDetails.id,
          trackingNumber: `TRK-${Date.now()}`,
          carrier: 'Auto-Carrier',
          status: 'pending',
          shipDate: new Date().toISOString(),
          estimatedDelivery: orderDetails.deliveryDate,
          origin: {
            address: 'Warehouse A',
            city: 'Default City',
            state: 'Default State',
            pincode: '000000',
          },
          destination: {
            address: orderDetails.shippingAddress.street,
            city: orderDetails.shippingAddress.city,
            state: orderDetails.shippingAddress.state,
            pincode: orderDetails.shippingAddress.pincode,
          },
          weight: orderDetails.items.reduce((acc, item) => acc + (item.quantity * 1), 0), // Assuming default weight 1
          dimensions: { length: 10, width: 10, height: 10 }, // Default dimensions
          cost: 500, // Default cost
        });
        if (!shipment) {
          return res.status(500).json({ success: false, error: 'Failed to create shipment' })
        }
      }
    }

    res.json({ success: true, data: updatedOrder, message: `Order status updated to ${status}` } as ApiResponse<Order>)
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update order status', message: error instanceof Error ? error.message : 'Unknown error' })
  }
})