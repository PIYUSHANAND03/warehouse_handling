import { Server as SocketServer } from 'socket.io';
import { Server as HttpServer } from 'http';

interface InventoryUpdate {
  productId: string;
  name: string;
  oldStock: number;
  newStock: number;
  location: string;
  timestamp: string;
  changeType: 'addition' | 'reduction' | 'adjustment';
}

interface OrderUpdate {
  orderId: string;
  customerId: string;
  customerName: string;
  status: 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled';
  previousStatus?: string;
  timestamp: string;
}

interface NotificationData {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: string;
  userId?: string;
}

export class WarehouseSocketServer {
  private io: SocketServer;
  private connectedUsers: Map<string, any> = new Map();

  constructor(server: HttpServer) {
    this.io = new SocketServer(server, {
      cors: {
        origin: ["http://localhost:5173", "http://localhost:3000", "http://localhost:8080"],
        methods: ["GET", "POST"],
        credentials: true
      }
    });

    this.setupSocketHandlers();
    this.startSimulatedUpdates(); // For learning purposes
  }

  private setupSocketHandlers() {
    this.io.on('connection', (socket) => {
      console.log(`User connected: ${socket.id}`);
      
      // Store user info
      socket.on('user:join', (userData) => {
        this.connectedUsers.set(socket.id, userData);
        socket.emit('connection:confirmed', {
          socketId: socket.id,
          timestamp: new Date().toISOString()
        });
      });

      // Handle inventory updates from clients
      socket.on('inventory:update', (data: InventoryUpdate) => {
        console.log('Inventory update received:', data);
        // Broadcast to all other clients
        socket.broadcast.emit('inventory:updated', data);
      });

      // Handle order status changes
      socket.on('order:status-change', (data: OrderUpdate) => {
        console.log('Order status change:', data);
        socket.broadcast.emit('order:status-changed', data);
      });

      // Handle user activity tracking
      socket.on('user:activity', (activity) => {
        const userData = this.connectedUsers.get(socket.id);
        this.io.emit('activity:update', {
          user: userData?.name || 'Anonymous',
          activity: activity.action,
          location: activity.page,
          timestamp: new Date().toISOString()
        });
      });

      // Handle notifications
      socket.on('notification:send', (notification: NotificationData) => {
        if (notification.userId) {
          // Send to specific user
          socket.to(notification.userId).emit('notification:received', notification);
        } else {
          // Broadcast to all
          this.io.emit('notification:received', notification);
        }
      });

      // Handle disconnection
      socket.on('disconnect', () => {
        console.log(`User disconnected: ${socket.id}`);
        this.connectedUsers.delete(socket.id);
        
        // Emit user count update
        this.io.emit('users:count', this.connectedUsers.size);
      });

      // Send initial data
      socket.emit('users:count', this.connectedUsers.size);
    });
  }

  // Simulate real-time updates for learning purposes
  private startSimulatedUpdates() {
    // Simulate inventory changes every 10-15 seconds
    setInterval(() => {
      if (this.connectedUsers.size > 0) {
        this.simulateInventoryUpdate();
      }
    }, Math.random() * 5000 + 10000);

    // Simulate order updates every 20-30 seconds
    setInterval(() => {
      if (this.connectedUsers.size > 0) {
        this.simulateOrderUpdate();
      }
    }, Math.random() * 10000 + 20000);

    // Send periodic stats updates
    setInterval(() => {
      if (this.connectedUsers.size > 0) {
        this.sendStatsUpdate();
      }
    }, 30000); // Every 30 seconds
  }

  private simulateInventoryUpdate() {
    const products = [
      'Cotton T-Shirts', 'Wireless Earbuds', 'Leather Wallets', 'Smart Watch', 
      'Yoga Mats', 'Face Serum', 'Ceramic Vases', 'Denim Jeans'
    ];
    
    const locations = ['Zone A-1', 'Zone A-2', 'Zone B-1', 'Zone B-2', 'Zone C-1'];
    const changeTypes: ('addition' | 'reduction' | 'adjustment')[] = ['addition', 'reduction', 'adjustment'];
    
    const update: InventoryUpdate = {
      productId: `PROD-${Math.floor(Math.random() * 1000)}`,
      name: products[Math.floor(Math.random() * products.length)],
      oldStock: Math.floor(Math.random() * 100),
      newStock: Math.floor(Math.random() * 100),
      location: locations[Math.floor(Math.random() * locations.length)],
      timestamp: new Date().toISOString(),
      changeType: changeTypes[Math.floor(Math.random() * changeTypes.length)]
    };

    this.io.emit('inventory:updated', update);
  }

  private simulateOrderUpdate() {
    const customers = ['Fashion Boutique', 'TechWorld Store', 'Style Accessories', 'Home & Garden'];
    const statuses: ('pending' | 'processing' | 'shipped' | 'completed' | 'cancelled')[] = 
      ['pending', 'processing', 'shipped', 'completed'];
    
    const update: OrderUpdate = {
      orderId: `ORD-${Math.floor(Math.random() * 10000)}`,
      customerId: `CUST-${Math.floor(Math.random() * 1000)}`,
      customerName: customers[Math.floor(Math.random() * customers.length)],
      status: statuses[Math.floor(Math.random() * statuses.length)],
      timestamp: new Date().toISOString()
    };

    this.io.emit('order:status-changed', update);
  }

  private sendStatsUpdate() {
    const stats = {
      activeUsers: this.connectedUsers.size,
      totalOrders: Math.floor(Math.random() * 1000) + 500,
      pendingShipments: Math.floor(Math.random() * 50) + 10,
      lowStockItems: Math.floor(Math.random() * 20) + 5,
      timestamp: new Date().toISOString()
    };

    this.io.emit('stats:updated', stats);
  }

  // Public methods for manual updates
  public broadcastInventoryUpdate(data: InventoryUpdate) {
    this.io.emit('inventory:updated', data);
  }

  public broadcastOrderUpdate(data: OrderUpdate) {
    this.io.emit('order:status-changed', data);
  }

  public sendNotification(notification: NotificationData) {
    this.io.emit('notification:received', notification);
  }

  public getConnectedUsersCount(): number {
    return this.connectedUsers.size;
  }
}