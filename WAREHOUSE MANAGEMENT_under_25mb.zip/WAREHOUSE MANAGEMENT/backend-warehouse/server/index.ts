import "dotenv/config";
import express from "express";
import cors from "cors";
import { createServer as createHttpServer } from "http";
import { WarehouseSocketServer } from "./socket";
import { handleDemo } from "./routes/demo";
import { productsRouter } from "./routes/products";
import { ordersRouter } from "./routes/orders";
import { customersRouter } from "./routes/customers";
import { shipmentsRouter } from "./routes/shipments";
import { reportsRouter } from "./routes/reports";
import { dashboardRouter } from "./routes/dashboard";
import { workersRouter } from "./routes/workers";
import { inboundRouter } from "./routes/inbound";
import { profileRouter } from "./routes/profile";

export function createServer() {
  const app = express();
  const httpServer = createHttpServer(app);
  
  // Initialize WebSocket server
  const socketServer = new WarehouseSocketServer(httpServer);

  // Middleware
  app.use(cors({
    origin: [
      'http://localhost:5173',
      'http://localhost:3000',
      /^https:\/\/.*\.netlify\.app$/,
      /^https:\/\/.*\.onrender\.com$/
    ],
    credentials: true
  }));
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Health check routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Main API routes
  app.use("/api/products", productsRouter);
  app.use("/api/orders", ordersRouter);
  app.use("/api/customers", customersRouter);
  app.use("/api/shipments", shipmentsRouter);
  app.use("/api/reports", reportsRouter);
  app.use("/api/dashboard", dashboardRouter);
  app.use("/api/workers", workersRouter);
  app.use("/api/inbound", inboundRouter);
  app.use("/api/profile", profileRouter);

  // API documentation endpoint
  app.get("/api", (_req, res) => {
    res.json({
      message: "Warehouse Management System API",
      version: "1.0.0",
      endpoints: {
        products: "/api/products",
        orders: "/api/orders",
        customers: "/api/customers",
        shipments: "/api/shipments",
        reports: "/api/reports",
        dashboard: "/api/dashboard",
        workers: "/api/workers",
        inbound: "/api/inbound",
        profile: "/api/profile"
      },
      documentation: {
        products: {
          "GET /api/products": "Get all products with filtering and pagination",
          "GET /api/products/:id": "Get specific product",
          "POST /api/products": "Create new product",
          "PUT /api/products/:id": "Update product",
          "DELETE /api/products/:id": "Delete product",
          "PATCH /api/products/:id/stock": "Update product stock",
          "GET /api/products/stats/summary": "Get product statistics"
        },
        orders: {
          "GET /api/orders": "Get all orders with filtering and pagination",
          "GET /api/orders/:id": "Get specific order",
          "POST /api/orders": "Create new order",
          "PUT /api/orders/:id": "Update order",
          "DELETE /api/orders/:id": "Delete order",
          "PATCH /api/orders/:id/status": "Update order status",
          "GET /api/orders/stats/summary": "Get order statistics",
          "GET /api/orders/customer/:customerId": "Get orders by customer"
        },
        customers: {
          "GET /api/customers": "Get all customers with filtering and pagination",
          "GET /api/customers/:id": "Get specific customer",
          "POST /api/customers": "Create new customer",
          "PUT /api/customers/:id": "Update customer",
          "DELETE /api/customers/:id": "Delete customer",
          "GET /api/customers/stats/summary": "Get customer statistics",
          "GET /api/customers/:id/orders": "Get customer order history",
          "GET /api/customers/search/:term": "Search customers"
        },
        shipments: {
          "GET /api/shipments": "Get all shipments with filtering and pagination",
          "GET /api/shipments/:id": "Get specific shipment",
          "POST /api/shipments": "Create new shipment",
          "PUT /api/shipments/:id": "Update shipment",
          "DELETE /api/shipments/:id": "Delete shipment",
          "PATCH /api/shipments/:id/status": "Update shipment status",
          "GET /api/shipments/stats/summary": "Get shipment statistics",
          "GET /api/shipments/track/:trackingNumber": "Track shipment",
          "GET /api/shipments/pending": "Get pending shipments"
        },
        reports: {
          "GET /api/reports/inventory": "Generate inventory report",
          "GET /api/reports/sales": "Generate sales report",
          "GET /api/reports/low-stock": "Generate low stock report",
          "GET /api/reports/customer": "Generate customer analytics report",
          "GET /api/reports/financial": "Generate financial report",
          "GET /api/reports/shipment-performance": "Generate shipment performance report",
          "GET /api/reports/summary": "Get available reports summary"
        },
        dashboard: {
          "GET /api/dashboard/stats": "Get dashboard statistics",
          "GET /api/dashboard/overview": "Get comprehensive dashboard overview",
          "GET /api/dashboard/alerts": "Get system alerts and notifications",
          "GET /api/dashboard/recent-activity": "Get recent system activities",
          "GET /api/dashboard/performance": "Get key performance indicators"
        },
        workers: {
          "GET /api/workers": "Get all workers with filtering and search",
          "GET /api/workers/:id": "Get specific worker",
          "POST /api/workers": "Create new worker",
          "PUT /api/workers/:id": "Update worker",
          "DELETE /api/workers/:id": "Delete worker",
          "PATCH /api/workers/:id/status": "Update worker status",
          "GET /api/workers/stats/summary": "Get worker statistics",
          "GET /api/workers/department/:department": "Get workers by department",
          "GET /api/workers/search/:term": "Search workers"
        },
        inbound: {
          "GET /api/inbound": "List inbound ASNs (optional search/status)",
          "GET /api/inbound/stats/summary": "Inbound summary stats",
          "POST /api/inbound": "Create inbound record",
          "PUT /api/inbound/:id": "Update inbound record",
          "PATCH /api/inbound/:id/status": "Update inbound status",
          "DELETE /api/inbound/:id": "Delete inbound record"
        },
        profile: {
          "GET /api/profile": "Get current user profile"
        }
      }
    });
  });

  // 404 handler for API routes
  app.use("/api/*", (_req, res) => {
    res.status(404).json({
      success: false,
      error: "API endpoint not found",
      message: "The requested API endpoint does not exist"
    });
  });

  return { app, httpServer, socketServer };
}
