# 🚀 Warehouse Management System - Quick Start Guide

## Prerequisites
Make sure you have Node.js installed (version 16 or higher).

## Getting Started

### 1. Install Dependencies
First, navigate to the project directory and install all dependencies:
```bash
cd "C:\Users\apiyu\OneDrive\Desktop\WAREHOUSE MANAGEMENT"
npm install
```

### 2. Start the Backend Server
Open your first terminal and start the backend API server:
```bash
npm run dev:server
```

This will start the server at `http://localhost:3000` with all API endpoints ready.

### 3. Start the Frontend (New Terminal)
Open a second terminal and start the frontend development server:
```bash
npm run dev
```

This will start the frontend at `http://localhost:5173`.

### 4. Access the Application
Open your browser and navigate to:
- **Frontend**: `http://localhost:5173`
- **API Documentation**: `http://localhost:3000/api`
- **Health Check**: `http://localhost:3000/api/ping`

## Inventory Page Features ✅

The inventory page is now fully functional with:

### Core Features:
- ✅ **Product Listing**: Grid and table view modes
- ✅ **Search & Filtering**: Search by name, filter by category and status
- ✅ **Product Management**: Add, edit, delete products
- ✅ **Stock Management**: Adjust stock levels with reason tracking
- ✅ **Bulk Operations**: Select multiple items for bulk delete or category updates
- ✅ **Real-time Stats**: Total items, low stock alerts, inventory value
- ✅ **Status Indicators**: Visual status badges (in-stock, low-stock, out-of-stock)

### Interactive Elements:
- ✅ **Add Product**: Click "Add Item" button (navigates to /add-product)
- ✅ **Edit Product**: Click edit icon or dropdown menu
- ✅ **Delete Product**: Click delete icon with confirmation dialog
- ✅ **Adjust Stock**: Click adjust button to modify stock quantities
- ✅ **Selection**: Checkbox selection for individual and bulk operations
- ✅ **Filtering**: Advanced filter dropdown with category and status options
- ✅ **View Toggle**: Switch between grid and table views

### Sample Data:
The system comes pre-loaded with 15 sample products across 6 categories:
- **Clothes**: Cotton T-Shirts, Denim Jeans
- **Electronics**: Wireless Earbuds, Smart Watch, Gaming Keyboard, Wireless Mouse
- **Accessories**: Leather Wallets, Canvas Tote Bags
- **Sports**: Yoga Mats, Running Shoes, Protein Powder
- **Beauty**: Face Serum, Moisturizing Cream
- **Home Decor**: Decorative Vase, Table Lamp

## API Endpoints Available

### Products:
- `GET /api/products` - List all products with filtering
- `GET /api/products/:id` - Get specific product
- `POST /api/products` - Create new product
- `PUT /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product
- `PATCH /api/products/:id/stock` - Update stock
- `DELETE /api/products/bulk/delete` - Bulk delete
- `PATCH /api/products/bulk/update` - Bulk update
- `GET /api/products/stats/summary` - Product statistics

### Other:
- `GET /api/dashboard/stats` - Dashboard statistics
- `GET /api/orders` - Orders list
- `GET /api/customers` - Customers list

## Troubleshooting

### Port Already in Use:
If port 3000 is busy, the server will try the next available port. Check the console output for the actual port.

### Dependencies Issues:
If you encounter dependency issues, try:
```bash
rm -rf node_modules package-lock.json
npm install
```

### Build Issues:
Make sure TypeScript is working correctly:
```bash
npm run typecheck
```

## Next Steps
- Explore the inventory management features
- Try adding new products through the "Add Item" button
- Test the filtering and search functionality
- Experiment with bulk operations by selecting multiple items

The system is now ready for full development and testing! 🎉