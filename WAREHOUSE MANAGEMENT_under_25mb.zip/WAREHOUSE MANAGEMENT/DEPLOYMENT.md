# 🚀 Deployment Guide

This guide covers deploying the invenTREE Warehouse Management System to various platforms.

## 📋 Pre-Deployment Checklist

- [ ] All tests passing (`pnpm test`)
- [ ] Type checking successful (`pnpm typecheck`)
- [ ] Environment variables configured
- [ ] Database migrations applied
- [ ] Production build tested locally
- [ ] Security review completed
- [ ] Backup strategy in place

## 🏗️ Build for Production

```bash
# Install dependencies
pnpm install

# Build the application
pnpm build

# Test production build locally
pnpm start
```

## 🌐 Deployment Options

### Option 1: Traditional VPS/Server

#### Requirements
- Ubuntu 20.04+ or similar Linux distribution
- Node.js 18+
- MySQL 8+
- Nginx (recommended)
- PM2 or similar process manager

#### Steps

1. **Set up the server**

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install pnpm
npm install -g pnpm

# Install MySQL
sudo apt install -y mysql-server
sudo mysql_secure_installation
```

2. **Clone and build**

```bash
# Clone repository
git clone <your-repo-url>
cd warehouse-management

# Install dependencies
pnpm install

# Configure environment
cp .env.example .env
nano .env  # Edit with your production values

# Build application
pnpm build
```

3. **Set up database**

```bash
# Create database
mysql -u root -p
CREATE DATABASE warehouse_db;
CREATE USER 'warehouse_user'@'localhost' IDENTIFIED BY 'strong_password';
GRANT ALL PRIVILEGES ON warehouse_db.* TO 'warehouse_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Run migrations
pnpm prisma:generate
pnpm prisma:migrate deploy

# Seed database (optional)
pnpm prisma:seed
```

4. **Set up PM2**

```bash
# Install PM2
npm install -g pm2

# Start application
pm2 start dist/server/node-build.mjs --name warehouse-app

# Configure PM2 to start on boot
pm2 startup
pm2 save
```

5. **Configure Nginx**

```nginx
# /etc/nginx/sites-available/warehouse
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # WebSocket support
    location /socket.io/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/warehouse /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

6. **Set up SSL with Let's Encrypt**

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### Option 2: Docker Deployment

#### Create Dockerfile

```dockerfile
# Dockerfile
FROM node:18-alpine AS builder

WORKDIR /app

# Install pnpm
RUN npm install -g pnpm

# Copy package files
COPY package.json pnpm-lock.yaml ./

# Install dependencies
RUN pnpm install --frozen-lockfile

# Copy source code
COPY . .

# Build application
RUN pnpm build

# Production stage
FROM node:18-alpine

WORKDIR /app

RUN npm install -g pnpm

# Copy built files
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./
COPY --from=builder /app/prisma ./prisma

# Expose port
EXPOSE 3000

# Start application
CMD ["node", "dist/server/node-build.mjs"]
```

#### Create docker-compose.yml

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=mysql://warehouse_user:password@db:3306/warehouse_db
    depends_on:
      - db
    restart: unless-stopped

  db:
    image: mysql:8
    environment:
      - MYSQL_ROOT_PASSWORD=rootpassword
      - MYSQL_DATABASE=warehouse_db
      - MYSQL_USER=warehouse_user
      - MYSQL_PASSWORD=password
    volumes:
      - mysql_data:/var/lib/mysql
    restart: unless-stopped

volumes:
  mysql_data:
```

#### Deploy with Docker

```bash
# Build and start
docker-compose up -d

# View logs
docker-compose logs -f

# Run migrations
docker-compose exec app npx prisma migrate deploy
```

### Option 3: Vercel/Netlify (Serverless)

The application includes serverless function support for platforms like Vercel and Netlify.

#### Vercel Deployment

1. Install Vercel CLI:
```bash
npm install -g vercel
```

2. Deploy:
```bash
vercel
```

3. Configure environment variables in Vercel dashboard

#### Netlify Deployment

1. Install Netlify CLI:
```bash
npm install -g netlify-cli
```

2. Deploy:
```bash
netlify deploy --prod
```

3. Configure environment variables in Netlify dashboard

**Note:** For serverless deployments, you'll need to use a managed MySQL service like PlanetScale, AWS RDS, or similar.

### Option 4: Cloud Platforms

#### AWS EC2

1. Launch EC2 instance (Ubuntu 20.04)
2. Follow VPS deployment steps above
3. Configure security groups for ports 80, 443, 3000
4. Set up RDS for MySQL (recommended)
5. Use Elastic Load Balancer for high availability

#### Google Cloud Platform

1. Create Compute Engine instance
2. Follow VPS deployment steps
3. Use Cloud SQL for MySQL
4. Set up Cloud Load Balancing

#### DigitalOcean

1. Create Droplet (Ubuntu 20.04)
2. Follow VPS deployment steps
3. Use Managed MySQL Database
4. Set up Load Balancer if needed

## 🔒 Security Best Practices

### 1. Environment Variables

Never commit sensitive data:
```bash
# Add to .gitignore
.env
.env.local
.env.production
```

### 2. Database Security

```sql
-- Use strong passwords
-- Limit user privileges
-- Enable SSL connections
-- Regular backups
```

### 3. Application Security

```bash
# Keep dependencies updated
pnpm update

# Run security audit
pnpm audit

# Use HTTPS only
# Implement rate limiting
# Add CORS restrictions
# Enable helmet.js for Express
```

### 4. Firewall Configuration

```bash
# UFW (Ubuntu)
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

## 📊 Monitoring

### PM2 Monitoring

```bash
# View status
pm2 status

# View logs
pm2 logs warehouse-app

# Monitor resources
pm2 monit
```

### Database Monitoring

```bash
# MySQL slow query log
sudo nano /etc/mysql/mysql.conf.d/mysqld.cnf
# Add:
# slow_query_log = 1
# slow_query_log_file = /var/log/mysql/slow.log
# long_query_time = 2
```

## 🔄 Continuous Deployment

### GitHub Actions Example

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install pnpm
        run: npm install -g pnpm
      
      - name: Install dependencies
        run: pnpm install
      
      - name: Build
        run: pnpm build
      
      - name: Deploy to server
        uses: appleboy/scp-action@master
        with:
          host: ${{ secrets.HOST }}
          username: ${{ secrets.USERNAME }}
          key: ${{ secrets.SSH_KEY }}
          source: "dist/*"
          target: "/var/www/warehouse"
      
      - name: Restart application
        uses: appleboy/ssh-action@master
        with:
          host: ${{ secrets.HOST }}
          username: ${{ secrets.USERNAME }}
          key: ${{ secrets.SSH_KEY }}
          script: |
            cd /var/www/warehouse
            pm2 restart warehouse-app
```

## 🔧 Troubleshooting

### Application won't start

```bash
# Check logs
pm2 logs warehouse-app

# Check port availability
sudo lsof -i :3000

# Check environment variables
printenv | grep DATABASE_URL
```

### Database connection issues

```bash
# Test MySQL connection
mysql -u warehouse_user -p -h localhost warehouse_db

# Check MySQL status
sudo systemctl status mysql

# View MySQL logs
sudo tail -f /var/log/mysql/error.log
```

### Performance issues

```bash
# Check server resources
htop

# Check database performance
mysql -u root -p
SHOW PROCESSLIST;
SHOW STATUS;

# Optimize tables
OPTIMIZE TABLE products, orders, customers;
```

## 📈 Scaling

### Horizontal Scaling

1. Set up load balancer
2. Deploy multiple application instances
3. Use shared database
4. Implement Redis for sessions
5. Use CDN for static assets

### Database Scaling

1. Enable MySQL replication
2. Use read replicas
3. Implement connection pooling
4. Add database indexes
5. Consider sharding for large datasets

## 🔄 Backup Strategy

### Database Backups

```bash
# Daily backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
mysqldump -u warehouse_user -p warehouse_db > /backups/warehouse_$DATE.sql
# Keep only last 7 days
find /backups -name "warehouse_*.sql" -mtime +7 -delete
```

### Application Backups

```bash
# Backup application files
tar -czf warehouse_backup_$DATE.tar.gz /var/www/warehouse
```

## 📞 Support

For deployment issues:
- Check logs first
- Review this guide
- Open an issue on GitHub
- Contact support team

---

**Remember:** Always test deployments in a staging environment first!
