/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

/**
 * Worker types shared between client and server
 */
export interface Worker {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'manager' | 'supervisor' | 'worker' | 'picker' | 'packer' | 'loader';
  department: 'receiving' | 'picking' | 'packing' | 'shipping' | 'inventory' | 'administration';
  status: 'active' | 'inactive' | 'on-leave';
  hireDate: string;
  shift: 'morning' | 'afternoon' | 'night';
  hourlyRate: number;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  emergencyContact?: {
    name: string;
    phone: string;
    relationship: string;
  };
  skills?: string[];
  performanceRating?: number;
  lastActive?: string;
}

export interface CreateWorkerRequest {
  name: string;
  email: string;
  phone: string;
  role: 'manager' | 'supervisor' | 'worker' | 'picker' | 'packer' | 'loader';
  department: 'receiving' | 'picking' | 'packing' | 'shipping' | 'inventory' | 'administration';
  shift: 'morning' | 'afternoon' | 'night';
  hourlyRate: number;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  emergencyContact?: {
    name: string;
    phone: string;
    relationship: string;
  };
  skills?: string[];
}

export interface InvoiceItem {
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string;
  orderId: string;
  invoiceDate: string;
  dueDate: string;
  status: 'unpaid' | 'paid' | 'void';
  subtotal: number;
  tax: number;
  total: number;
  currency: string;
  items: InvoiceItem[];
}

/**
 * User Profile type shared between client and server
 */
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  avatarUrl?: string;
}

export interface DemandForecastEntry {
  productId: string;
  productName: string;
  predictedWeeklyUnits: number;
  predictedDailyUnits: number;
  averageWeeklyUnits: number;
  lastWeekUnits: number;
  growthRate: number;
  confidence: number;
  volatility: number;
}

export interface DemandForecastReport {
  generatedAt: string;
  horizonDays: number;
  method: string;
  totalProductsEvaluated: number;
  topProducts: DemandForecastEntry[];
}

export interface StorageOptimizationRecommendation {
  productId: string;
  productName: string;
  currentLocation: string;
  suggestedLocation: string;
  movementScore: number;
  currentDistance: number;
  suggestedDistance: number;
  distanceImprovement: number;
  priority: 'high' | 'medium' | 'low';
}

export interface StorageOptimizationPlan {
  generatedAt: string;
  strategy: string;
  summary: {
    totalMoves: number;
    averageDistanceReduction: number;
    estimatedTravelReduction: number;
  };
  recommendations: StorageOptimizationRecommendation[];
}

export interface PickingPathStep {
  step: number;
  location: string;
  action: string;
  reward: number;
  cumulativeReward: number;
}

export interface PickingPathPlan {
  generatedAt: string;
  entryPoint: string;
  plannedStops: string[];
  totalSteps: number;
  totalReward: number;
  estimatedTravelTimeMinutes: number;
  policyConfidence: number;
  steps: PickingPathStep[];
}
